const appName = {
  message: "Automatische Tab-Gruppierung",
  description: "The title of the application, displayed in the web store."
};
const appDesc = {
  message: "Weise Tabs automatisiert bestimmten Gruppen zu, basierend auf ihrer Adresse.",
  description: "The description of the application, displayed in the web store."
};
const previewTitle = {
  message: "Vorschau",
  description: "The title of the preview tab in the edit dialog."
};
const headlineAdvanced = {
  message: "Erweiterte Einstellungen",
  description: "The headline of the advanced settings section in the edit dialog."
};
const checkboxStrict = {
  message: "Exakt",
  description: "The label of the strict checkbox in the edit dialog."
};
const checkboxStrictDescription = {
  message: "Entferne Tabs aus dieser Gruppe, wenn ihre URL nicht mehr übereinstimmt.",
  description: "The description of the strict checkbox in the edit dialog."
};
const checkboxMerge = {
  message: "Zusammenführen",
  description: "The label of the merge checkbox in the edit dialog."
};
const checkboxMergeDescription = {
  message: "Vermeide das Erstellen dieser Gruppe in mehreren Fenstern; verschiebe stattdessen Tabs zur bestehenden Gruppe in einem anderen Browserfenster.",
  description: "The description of the merge checkbox in the edit dialog."
};
const noGroupTitle = {
  message: "kein Titel",
  description: "A group with an empty title"
};
const editGroupTooltip = {
  message: "Gruppe bearbeiten",
  description: "The tooltip for the edit group button"
};
const newMatcherTooltip = {
  message: "Weiteres URL-Muster hinzufügen",
  description: "The tooltip for the new matcher button"
};
const invalidUrlPattern = {
  message: "Ungültiges URL-Muster",
  description: "Error message for invalid URL pattern"
};
const matchPatternInfo = {
  message: "Mehr über URL-Muster erfahren (englisch)",
  description: "Match pattern info link"
};
const buttonDeleteGroup = {
  message: "Gruppe löschen",
  description: "Delete group button label"
};
const groupDeletedNotice = {
  message: "Gruppe wurde gelöscht",
  description: "Snackbar message when group was deleted"
};
const undo = {
  message: "Rückgängig",
  description: "Undo button label"
};
const buttonSave = {
  message: "Speichern",
  description: "Save button label"
};
const buttonCancel = {
  message: "Abbrechen",
  description: "Cancel button label"
};
const headlineImport = {
  message: "Importieren",
  description: "The import headline of the import/export settings dialog."
};
const headlineExport = {
  message: "Exportieren",
  description: "The import headline of the import/export settings dialog."
};
const buttonExport = {
  message: "Gruppierungsregeln in Datei speichern",
  description: "Export button label"
};
const buttonImport = {
  message: "Gruppierungsregeln aus Datei laden...",
  description: "Import button label"
};
const importFormatError = {
  message: "Die zu importierende Datei enthält ungültige Einstellungen.",
  description: "Error message when imported file is not valid JSON or does not match the schema"
};
const importDiscardWarning = {
  message: "Existierende Regeln werden verworfen.",
  description: "Warning message when importing settings"
};
const importSuccess = {
  message: "Import erfolgreich abgeschlossen",
  description: "Snackbar message when importing succeeded"
};
const buttonSortMode = {
  message: "Sortiermodus aktivieren",
  description: "Sort mode"
};
const buttonSettings = {
  message: "Einstellungen",
  description: "General settings"
};
const buttonAddGroup = {
  message: "Neue Gruppe",
  description: "Add group button label"
};
const groupTitlePlaceholder = {
  message: "Gruppe benennen",
  description: "Placeholder of a group title input"
};
const urlInputPlaceholder = {
  message: "URL-Muster",
  description: "Placeholder of a URL input"
};
const furtherUrlInputPlaceholder = {
  message: "Weiteres URL-Muster",
  description: "Placeholder of URL input beyond the first one"
};
const newGroupTitle = {
  message: "Neue Gruppe",
  description: "Title of a newly created group"
};
const duplicateGroupError = {
  message: "Diese Kombination aus Gruppenname und Farbe existiert bereits.",
  description: "Error message when a group with the same name and color already exists"
};
const color = {
  message: "Farbe",
  description: "The word 'color'"
};
const colorGrey = {
  message: "grau",
  description: "The color grey"
};
const colorBlue = {
  message: "blau",
  description: "The color blue"
};
const colorRed = {
  message: "rot",
  description: "The color red"
};
const colorYellow = {
  message: "gelb",
  description: "The color yellow"
};
const colorGreen = {
  message: "grün",
  description: "The color green"
};
const colorPink = {
  message: "rosa",
  description: "The color pink"
};
const colorPurple = {
  message: "violett",
  description: "The color purple"
};
const colorCyan = {
  message: "cyan",
  description: "The color cyan"
};
const colorOrange = {
  message: "orange",
  description: "The color orange"
};
const sortHint = {
  message: "Die Sortierung der Gruppen bestimmt die Auswertungsreihenfolge der URL-Muster. Positioniere Gruppen mit spezifischeren URL-Mustern am Anfang, um auf Gruppen mit allgemeineren Mustern zurückzufallen.",
  description: "Hint to show when sort mode is enabled"
};
const settingsTitle = {
  message: "Einstellungen",
  description: "Name of the settings area"
};
const settingsTransferConfigurationTitle = {
  message: "Konfiguration übertragen",
  description: "Title of the transfer configuration section"
};
const settingsTransferConfigurationSubtitle = {
  message: "Gruppierungsregeln importieren und exportieren",
  description: "Subtitle of the transfer configuration section"
};
const settingsForceReloadTitle = {
  message: "Erweiterung neu starten",
  description: "Title of the force reload section"
};
const settingsForceReloadSubtitle = {
  message: "Die Erweiterung scheint nicht zu reagieren oder neue Regeln nicht anzuwenden? Klicke hier.",
  description: "Subtitle of the force reload section"
};
const suggestionTitle = {
  message: "Vorschläge",
  description: "Suggestions title for matcher patterns"
};
const derivedNameChromePage = {
  message: "Chrome-Seite",
  description: "Description of a generic Chrome-specific page"
};
const derivedNameChromeSettings = {
  message: "Chrome-Einstellungen",
  description: "Description of the Chrome Settings page"
};
const derivedNameChromeSettingsSection = {
  message: "Dieser Bereich der Chrome-Einstellungen",
  description: "Description of a Chrome Settings section page"
};
const derivedNameChromeExtensions = {
  message: "Chrome Erweiterungen",
  description: "Description of the Chrome Extensions page"
};
const derivedNameChromeDownloads = {
  message: "Chrome Downloads",
  description: "Description of the Chrome Downloads page"
};
const derivedNameChromeHistory = {
  message: "Chrome Verlauf",
  description: "Description of the Chrome History page"
};
const derivedNameChromeBookmarks = {
  message: "Chrome Lesezeichen",
  description: "Description of the Chrome Bookmarks page"
};
const derivedNameChromeApps = {
  message: "Chrome Apps",
  description: "Description of the Chrome Apps page"
};
const derivedNameChromeFlags = {
  message: "Chrome Flags",
  description: "Description of the Chrome Flags page"
};
const derivedNameChromeNewtab = {
  message: 'Chrome "Neuer Tab" Seite',
  description: "Description of the Chrome Newtab page"
};
const derivedNameChromeExactUrl = {
  message: "Nur diese URL",
  description: "Description of an exactly matching Chrome-specific page"
};
const derivedNameChromeAll = {
  message: "Alle Chrome-spezifischen Seiten",
  description: "Description of all Chrome-specific pages"
};
const derivedNameExtensionHost = {
  message: "Diese Erweiterung",
  description: "Description of a specific Chrome extension"
};
const derivedNameExtensionAll = {
  message: "Alle Erweiterungen",
  description: "Description of all Chrome-Extension-specific pages"
};
const derivedNameExtensionExactUrl = {
  message: "Nur diese Erweiterungs-URL",
  description: "Description of an exact Chrome extension URL"
};
const derivedNameFileAll = {
  message: "Alle Datei-URLs",
  description: "Description of all file:// URLs"
};
const derivedNameFileDirname = {
  message: 'Alle Dateien im "%s" Ordner',
  description: "Description of a file:// folder"
};
const derivedNameFileThisFolder = {
  message: "Alle Dateien in diesem Ordner",
  description: "Description of the current file:// folder"
};
const derivedNameFileExactUrl = {
  message: "Nur diese Datei",
  description: "Description of an exact file:// file URL"
};
const derivedNameFileExactFolderUrl = {
  message: "Nur dieser Ordner",
  description: "Description of an exact file:// folder URL"
};
const derivedNameHttpDomain = {
  message: "Diese Domain",
  description: "Description of an HTTP domain pattern"
};
const derivedNameHttpSubdomain = {
  message: "Diese Domain und ihre Subdomains",
  description: "Description of an HTTP domain and subdomain pattern"
};
const derivedNameGenericExactUrl = {
  message: "Genau diese URL",
  description: "Description of an exact URL"
};
const popupHeadline = {
  message: "URL-Muster anlegen",
  description: "Main headline in a popup"
};
const popupSelectLabel = {
  message: "Konfigurierte Gruppe auswählen",
  description: "Main headline in a popup"
};
const popupAddLink = {
  message: "Weiteres URL-Muster hinzufügen",
  description: "Add pattern button in a popup"
};
const popupCreateGroup = {
  message: "Neue Gruppe",
  description: "Create Group item in the popup menu select"
};
const popupSaveButton = {
  message: "Neue Muster speichern",
  description: "Save button for new URL patterns item in a popup"
};
const popupSavedMessage = {
  message: "URL-Muster wurden gespeichert",
  description: "Message when new patterns have been saved in a popup"
};
const popupMoreOptions = {
  message: "Weitere Optionen",
  description: "Button to go to options page from a popup"
};
const popupEditCurrentGroup = {
  message: "Alle Regeln für",
  description: "Edit existing tab group configuration button from a popup"
};
const popupAddCurrentGroup = {
  message: "Konfiguration erstellen für",
  description: "Add tab group configuration button from a popup"
};
const messages = {
  appName,
  appDesc,
  previewTitle,
  headlineAdvanced,
  checkboxStrict,
  checkboxStrictDescription,
  checkboxMerge,
  checkboxMergeDescription,
  noGroupTitle,
  editGroupTooltip,
  newMatcherTooltip,
  invalidUrlPattern,
  matchPatternInfo,
  buttonDeleteGroup,
  groupDeletedNotice,
  undo,
  buttonSave,
  buttonCancel,
  headlineImport,
  headlineExport,
  buttonExport,
  buttonImport,
  importFormatError,
  importDiscardWarning,
  importSuccess,
  buttonSortMode,
  buttonSettings,
  buttonAddGroup,
  groupTitlePlaceholder,
  urlInputPlaceholder,
  furtherUrlInputPlaceholder,
  newGroupTitle,
  duplicateGroupError,
  color,
  colorGrey,
  colorBlue,
  colorRed,
  colorYellow,
  colorGreen,
  colorPink,
  colorPurple,
  colorCyan,
  colorOrange,
  sortHint,
  settingsTitle,
  settingsTransferConfigurationTitle,
  settingsTransferConfigurationSubtitle,
  settingsForceReloadTitle,
  settingsForceReloadSubtitle,
  suggestionTitle,
  derivedNameChromePage,
  derivedNameChromeSettings,
  derivedNameChromeSettingsSection,
  derivedNameChromeExtensions,
  derivedNameChromeDownloads,
  derivedNameChromeHistory,
  derivedNameChromeBookmarks,
  derivedNameChromeApps,
  derivedNameChromeFlags,
  derivedNameChromeNewtab,
  derivedNameChromeExactUrl,
  derivedNameChromeAll,
  derivedNameExtensionHost,
  derivedNameExtensionAll,
  derivedNameExtensionExactUrl,
  derivedNameFileAll,
  derivedNameFileDirname,
  derivedNameFileThisFolder,
  derivedNameFileExactUrl,
  derivedNameFileExactFolderUrl,
  derivedNameHttpDomain,
  derivedNameHttpSubdomain,
  derivedNameGenericExactUrl,
  popupHeadline,
  popupSelectLabel,
  popupAddLink,
  popupCreateGroup,
  popupSaveButton,
  popupSavedMessage,
  popupMoreOptions,
  popupEditCurrentGroup,
  popupAddCurrentGroup
};
export {
  appDesc,
  appName,
  buttonAddGroup,
  buttonCancel,
  buttonDeleteGroup,
  buttonExport,
  buttonImport,
  buttonSave,
  buttonSettings,
  buttonSortMode,
  checkboxMerge,
  checkboxMergeDescription,
  checkboxStrict,
  checkboxStrictDescription,
  color,
  colorBlue,
  colorCyan,
  colorGreen,
  colorGrey,
  colorOrange,
  colorPink,
  colorPurple,
  colorRed,
  colorYellow,
  messages as default,
  derivedNameChromeAll,
  derivedNameChromeApps,
  derivedNameChromeBookmarks,
  derivedNameChromeDownloads,
  derivedNameChromeExactUrl,
  derivedNameChromeExtensions,
  derivedNameChromeFlags,
  derivedNameChromeHistory,
  derivedNameChromeNewtab,
  derivedNameChromePage,
  derivedNameChromeSettings,
  derivedNameChromeSettingsSection,
  derivedNameExtensionAll,
  derivedNameExtensionExactUrl,
  derivedNameExtensionHost,
  derivedNameFileAll,
  derivedNameFileDirname,
  derivedNameFileExactFolderUrl,
  derivedNameFileExactUrl,
  derivedNameFileThisFolder,
  derivedNameGenericExactUrl,
  derivedNameHttpDomain,
  derivedNameHttpSubdomain,
  duplicateGroupError,
  editGroupTooltip,
  furtherUrlInputPlaceholder,
  groupDeletedNotice,
  groupTitlePlaceholder,
  headlineAdvanced,
  headlineExport,
  headlineImport,
  importDiscardWarning,
  importFormatError,
  importSuccess,
  invalidUrlPattern,
  matchPatternInfo,
  newGroupTitle,
  newMatcherTooltip,
  noGroupTitle,
  popupAddCurrentGroup,
  popupAddLink,
  popupCreateGroup,
  popupEditCurrentGroup,
  popupHeadline,
  popupMoreOptions,
  popupSaveButton,
  popupSavedMessage,
  popupSelectLabel,
  previewTitle,
  settingsForceReloadSubtitle,
  settingsForceReloadTitle,
  settingsTitle,
  settingsTransferConfigurationSubtitle,
  settingsTransferConfigurationTitle,
  sortHint,
  suggestionTitle,
  undo,
  urlInputPlaceholder
};
//# sourceMappingURL=messages-2a0e404d.js.map
