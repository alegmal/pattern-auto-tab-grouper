const appName = {
  message: "Pattern Auto Tab Grouper",
  description: "The title of the application, displayed in the web store."
};
const appDesc = {
  message: "Automatically add tabs to your configured groups using advanced URL pattern matching with wildcard support.",
  description: "The description of the application, displayed in the web store."
};
const previewTitle = {
  message: "Preview",
  description: "The title of the preview tab in the edit dialog."
};
const headlineAdvanced = {
  message: "Advanced Settings",
  description: "The headline of the advanced settings section in the edit dialog."
};
const checkboxStrict = {
  message: "Strict",
  description: "The label of the strict checkbox in the edit dialog."
};
const checkboxStrictDescription = {
  message: "Remove tabs from this group if their URL no longer matches.",
  description: "The description of the strict checkbox in the edit dialog."
};
const checkboxMerge = {
  message: "Merge",
  description: "The label of the single window checkbox in the edit dialog."
};
const checkboxMergeDescription = {
  message: "Prevent creating instances of this group in different windows, move tabs into existing groups in other windows instead.",
  description: "The description of the single window checkbox in the edit dialog."
};
const noGroupTitle = {
  message: "no title",
  description: "A group with an empty title"
};
const editGroupTooltip = {
  message: "Edit group",
  description: "The tooltip for the edit group button"
};
const newMatcherTooltip = {
  message: "Add URL pattern",
  description: "The tooltip for the new matcher button"
};
const invalidUrlPattern = {
  message: "Invalid URL pattern",
  description: "Error message for invalid URL pattern"
};
const matchPatternInfo = {
  message: "Learn more about URL patterns",
  description: "Match pattern info link"
};
const buttonDeleteGroup = {
  message: "Delete group",
  description: "Delete group button label"
};
const groupDeletedNotice = {
  message: "Group was deleted",
  description: "Snackbar message when group was deleted"
};
const undo = {
  message: "Undo",
  description: "Undo button label"
};
const buttonSave = {
  message: "Save",
  description: "Save button label"
};
const buttonCancel = {
  message: "Cancel",
  description: "Cancel button label"
};
const headlineImport = {
  message: "Import",
  description: "The import headline of the import/export settings dialog."
};
const headlineExport = {
  message: "Export",
  description: "The import headline of the import/export settings dialog."
};
const buttonExport = {
  message: "Save grouping rules to file",
  description: "Export button label"
};
const buttonImport = {
  message: "Load grouping rules from file...",
  description: "Import button label"
};
const importFormatError = {
  message: "The file to be imported contains invalid grouping rules.",
  description: "Error message when imported file is not valid JSON or does not match the schema"
};
const importDiscardWarning = {
  message: "Preexisting grouping rules will be discarded.",
  description: "Warning message when importing settings"
};
const importSuccess = {
  message: "Import finished successfully",
  description: "Snackbar message when importing succeeded"
};
const buttonSortMode = {
  message: "Enable sort mode",
  description: "Sort mode"
};
const buttonSettings = {
  message: "Settings",
  description: "General settings"
};
const buttonAddGroup = {
  message: "Add group",
  description: "Add group button label"
};
const groupTitlePlaceholder = {
  message: "Group title",
  description: "Placeholder of a group title input"
};
const urlInputPlaceholder = {
  message: "URL pattern",
  description: "Placeholder of a URL input"
};
const furtherUrlInputPlaceholder = {
  message: "Another URL pattern",
  description: "Placeholder of URL input beyond the first one"
};
const newGroupTitle = {
  message: "New Group",
  description: "Title of a newly created group"
};
const duplicateGroupError = {
  message: "This combination of group name and color already exists.",
  description: "Error message when a group with the same name and color already exists"
};
const color = {
  message: "Color",
  description: "The word 'color'"
};
const colorGrey = {
  message: "grey",
  description: "The color grey"
};
const colorBlue = {
  message: "blue",
  description: "The color blue"
};
const colorRed = {
  message: "red",
  description: "The color red"
};
const colorYellow = {
  message: "yellow",
  description: "The color yellow"
};
const colorGreen = {
  message: "green",
  description: "The color green"
};
const colorPink = {
  message: "pink",
  description: "The color pink"
};
const colorPurple = {
  message: "purple",
  description: "The color purple"
};
const colorCyan = {
  message: "cyan",
  description: "The color cyan"
};
const colorOrange = {
  message: "orange",
  description: "The color orange"
};
const sortHint = {
  message: "The order of groups determines the order of pattern evaluation. Put groups with more specific patterns to the top to allow groups with more permissive patterns to serve as a fallback.",
  description: "Hint to show when sort mode is enabled"
};
const settingsTitle = {
  message: "Settings",
  description: "Name of the settings area"
};
const settingsTransferConfigurationTitle = {
  message: "Transfer Configuration",
  description: "Title of the transfer configuration section"
};
const settingsTransferConfigurationSubtitle = {
  message: "Import and export grouping rules",
  description: "Subtitle of the transfer configuration section"
};
const settingsForceReloadTitle = {
  message: "Force-Reload Extension",
  description: "Title of the force reload section"
};
const settingsForceReloadSubtitle = {
  message: "Feel like the extension is stuck or rule changes are not applied properly? Try this.",
  description: "Subtitle of the force reload section"
};
const settingsReassignTitle = {
  message: "Neuzuweisung",
  description: "Name of the reassign section"
};
const suggestionTitle = {
  message: "Suggestions",
  description: "Suggestions title for matcher patterns"
};
const derivedNameChromePage = {
  message: "Chrome Page",
  description: "Description of a generic Chrome-specific page"
};
const derivedNameChromeSettings = {
  message: "Chrome Settings",
  description: "Description of the Chrome Settings page"
};
const derivedNameChromeSettingsSection = {
  message: "This Chrome Settings section",
  description: "Description of a Chrome Settings section page"
};
const derivedNameChromeExtensions = {
  message: "Chrome Extensions",
  description: "Description of the Chrome Extensions page"
};
const derivedNameChromeDownloads = {
  message: "Chrome Downloads",
  description: "Description of the Chrome Downloads page"
};
const derivedNameChromeHistory = {
  message: "Chrome History",
  description: "Description of the Chrome History page"
};
const derivedNameChromeBookmarks = {
  message: "Chrome Bookmarks",
  description: "Description of the Chrome Bookmarks page"
};
const derivedNameChromeApps = {
  message: "Chrome Apps",
  description: "Description of the Chrome Apps page"
};
const derivedNameChromeFlags = {
  message: "Chrome Flags",
  description: "Description of the Chrome Flags page"
};
const derivedNameChromeNewtab = {
  message: "Chrome New Tab Page",
  description: "Description of the Chrome New Tab page"
};
const derivedNameChromeExactUrl = {
  message: "This exact URL",
  description: "Description of an exactly matching Chrome-specific page"
};
const derivedNameChromeAll = {
  message: "All Chrome-specific pages",
  description: "Description of all Chrome-specific pages"
};
const derivedNameExtensionHost = {
  message: "This extension",
  description: "Description of a specific Chrome extension"
};
const derivedNameExtensionAll = {
  message: "All extensions",
  description: "Description of all Chrome-Extension-specific pages"
};
const derivedNameExtensionExactUrl = {
  message: "This exact extension URL",
  description: "Description of an exact Chrome extension URL"
};
const derivedNameFileAll = {
  message: "All file URLs",
  description: "Description of all file:// URLs"
};
const derivedNameFileDirname = {
  message: 'All files in the "%s" folder',
  description: "Description of a file:// folder"
};
const derivedNameFileThisFolder = {
  message: "All files in this folder",
  description: "Description of the current file:// folder"
};
const derivedNameFileExactFileUrl = {
  message: "This exact file",
  description: "Description of an exact file:// file URL"
};
const derivedNameFileExactFolderUrl = {
  message: "This exact folder",
  description: "Description of an exact file:// folder URL"
};
const derivedNameHttpDomain = {
  message: "This domain",
  description: "Description of an HTTP domain pattern"
};
const derivedNameHttpSubdomain = {
  message: "This domain and its subdomains",
  description: "Description of an HTTP domain and subdomain pattern"
};
const derivedNameGenericExactUrl = {
  message: "This exact URL",
  description: "Description of an exact URL"
};
const popupHeadline = {
  message: "Add Grouping Patterns",
  description: "Main headline in a popup"
};
const popupSelectLabel = {
  message: "Select group configuration",
  description: "Main headline in a popup"
};
const popupAddLink = {
  message: "Add another pattern",
  description: "Add pattern button in a popup"
};
const popupCreateGroup = {
  message: "Create group",
  description: "Create Group item in the popup menu select"
};
const popupSaveButton = {
  message: "Save new patterns",
  description: "Save button for new URL patterns item in a popup"
};
const popupSavedMessage = {
  message: "Patterns have been saved",
  description: "Message when new patterns have been saved in a popup"
};
const popupMoreOptions = {
  message: "More options",
  description: "Button to go to options page from a popup"
};
const popupEditCurrentGroup = {
  message: "Show all rules for",
  description: "Edit existing tab group configuration button from a popup"
};
const popupAddCurrentGroup = {
  message: "Create configuration for",
  description: "Add tab group configuration button from a popup"
};
const messages = {
  appName,
  appDesc,
  previewTitle,
  headlineAdvanced,
  checkboxStrict,
  checkboxStrictDescription,
  checkboxMerge,
  checkboxMergeDescription,
  noGroupTitle,
  editGroupTooltip,
  newMatcherTooltip,
  invalidUrlPattern,
  matchPatternInfo,
  buttonDeleteGroup,
  groupDeletedNotice,
  undo,
  buttonSave,
  buttonCancel,
  headlineImport,
  headlineExport,
  buttonExport,
  buttonImport,
  importFormatError,
  importDiscardWarning,
  importSuccess,
  buttonSortMode,
  buttonSettings,
  buttonAddGroup,
  groupTitlePlaceholder,
  urlInputPlaceholder,
  furtherUrlInputPlaceholder,
  newGroupTitle,
  duplicateGroupError,
  color,
  colorGrey,
  colorBlue,
  colorRed,
  colorYellow,
  colorGreen,
  colorPink,
  colorPurple,
  colorCyan,
  colorOrange,
  sortHint,
  settingsTitle,
  settingsTransferConfigurationTitle,
  settingsTransferConfigurationSubtitle,
  settingsForceReloadTitle,
  settingsForceReloadSubtitle,
  settingsReassignTitle,
  suggestionTitle,
  derivedNameChromePage,
  derivedNameChromeSettings,
  derivedNameChromeSettingsSection,
  derivedNameChromeExtensions,
  derivedNameChromeDownloads,
  derivedNameChromeHistory,
  derivedNameChromeBookmarks,
  derivedNameChromeApps,
  derivedNameChromeFlags,
  derivedNameChromeNewtab,
  derivedNameChromeExactUrl,
  derivedNameChromeAll,
  derivedNameExtensionHost,
  derivedNameExtensionAll,
  derivedNameExtensionExactUrl,
  derivedNameFileAll,
  derivedNameFileDirname,
  derivedNameFileThisFolder,
  derivedNameFileExactFileUrl,
  derivedNameFileExactFolderUrl,
  derivedNameHttpDomain,
  derivedNameHttpSubdomain,
  derivedNameGenericExactUrl,
  popupHeadline,
  popupSelectLabel,
  popupAddLink,
  popupCreateGroup,
  popupSaveButton,
  popupSavedMessage,
  popupMoreOptions,
  popupEditCurrentGroup,
  popupAddCurrentGroup
};
export {
  appDesc,
  appName,
  buttonAddGroup,
  buttonCancel,
  buttonDeleteGroup,
  buttonExport,
  buttonImport,
  buttonSave,
  buttonSettings,
  buttonSortMode,
  checkboxMerge,
  checkboxMergeDescription,
  checkboxStrict,
  checkboxStrictDescription,
  color,
  colorBlue,
  colorCyan,
  colorGreen,
  colorGrey,
  colorOrange,
  colorPink,
  colorPurple,
  colorRed,
  colorYellow,
  messages as default,
  derivedNameChromeAll,
  derivedNameChromeApps,
  derivedNameChromeBookmarks,
  derivedNameChromeDownloads,
  derivedNameChromeExactUrl,
  derivedNameChromeExtensions,
  derivedNameChromeFlags,
  derivedNameChromeHistory,
  derivedNameChromeNewtab,
  derivedNameChromePage,
  derivedNameChromeSettings,
  derivedNameChromeSettingsSection,
  derivedNameExtensionAll,
  derivedNameExtensionExactUrl,
  derivedNameExtensionHost,
  derivedNameFileAll,
  derivedNameFileDirname,
  derivedNameFileExactFileUrl,
  derivedNameFileExactFolderUrl,
  derivedNameFileThisFolder,
  derivedNameGenericExactUrl,
  derivedNameHttpDomain,
  derivedNameHttpSubdomain,
  duplicateGroupError,
  editGroupTooltip,
  furtherUrlInputPlaceholder,
  groupDeletedNotice,
  groupTitlePlaceholder,
  headlineAdvanced,
  headlineExport,
  headlineImport,
  importDiscardWarning,
  importFormatError,
  importSuccess,
  invalidUrlPattern,
  matchPatternInfo,
  newGroupTitle,
  newMatcherTooltip,
  noGroupTitle,
  popupAddCurrentGroup,
  popupAddLink,
  popupCreateGroup,
  popupEditCurrentGroup,
  popupHeadline,
  popupMoreOptions,
  popupSaveButton,
  popupSavedMessage,
  popupSelectLabel,
  previewTitle,
  settingsForceReloadSubtitle,
  settingsForceReloadTitle,
  settingsReassignTitle,
  settingsTitle,
  settingsTransferConfigurationSubtitle,
  settingsTransferConfigurationTitle,
  sortHint,
  suggestionTitle,
  undo,
  urlInputPlaceholder
};
//# sourceMappingURL=messages-d8944572.js.map
