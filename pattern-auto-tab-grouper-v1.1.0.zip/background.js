"use strict";
(() => {
  // node_modules/@vue/shared/dist/shared.esm-bundler.js
  function makeMap(str, expectsLowerCase) {
    const map2 = /* @__PURE__ */ Object.create(null);
    const list = str.split(",");
    for (let i = 0; i < list.length; i++) {
      map2[list[i]] = true;
    }
    return expectsLowerCase ? (val) => !!map2[val.toLowerCase()] : (val) => !!map2[val];
  }
  var EMPTY_OBJ = true ? Object.freeze({}) : {};
  var EMPTY_ARR = true ? Object.freeze([]) : [];
  var NOOP = () => {
  };
  var NO = () => false;
  var extend = Object.assign;
  var remove = (arr, el) => {
    const i = arr.indexOf(el);
    if (i > -1) {
      arr.splice(i, 1);
    }
  };
  var hasOwnProperty = Object.prototype.hasOwnProperty;
  var hasOwn = (val, key) => hasOwnProperty.call(val, key);
  var isArray = Array.isArray;
  var isMap = (val) => toTypeString(val) === "[object Map]";
  var isSet = (val) => toTypeString(val) === "[object Set]";
  var isFunction = (val) => typeof val === "function";
  var isString = (val) => typeof val === "string";
  var isSymbol = (val) => typeof val === "symbol";
  var isObject = (val) => val !== null && typeof val === "object";
  var isPromise = (val) => {
    return isObject(val) && isFunction(val.then) && isFunction(val.catch);
  };
  var objectToString = Object.prototype.toString;
  var toTypeString = (value) => objectToString.call(value);
  var toRawType = (value) => {
    return toTypeString(value).slice(8, -1);
  };
  var isPlainObject = (val) => toTypeString(val) === "[object Object]";
  var isIntegerKey = (key) => isString(key) && key !== "NaN" && key[0] !== "-" && "" + parseInt(key, 10) === key;
  var cacheStringFunction = (fn) => {
    const cache = /* @__PURE__ */ Object.create(null);
    return (str) => {
      const hit = cache[str];
      return hit || (cache[str] = fn(str));
    };
  };
  var camelizeRE = /-(\w)/g;
  var camelize = cacheStringFunction((str) => {
    return str.replace(camelizeRE, (_, c) => c ? c.toUpperCase() : "");
  });
  var hyphenateRE = /\B([A-Z])/g;
  var hyphenate = cacheStringFunction(
    (str) => str.replace(hyphenateRE, "-$1").toLowerCase()
  );
  var capitalize = cacheStringFunction(
    (str) => str.charAt(0).toUpperCase() + str.slice(1)
  );
  var toHandlerKey = cacheStringFunction(
    (str) => str ? `on${capitalize(str)}` : ``
  );
  var hasChanged = (value, oldValue) => !Object.is(value, oldValue);
  var def = (obj, key, value) => {
    Object.defineProperty(obj, key, {
      configurable: true,
      enumerable: false,
      value
    });
  };
  var _globalThis;
  var getGlobalThis = () => {
    return _globalThis || (_globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
  };
  var specialBooleanAttrs = `itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly`;
  var isBooleanAttr = /* @__PURE__ */ makeMap(
    specialBooleanAttrs + `,async,autofocus,autoplay,controls,default,defer,disabled,hidden,inert,loop,open,required,reversed,scoped,seamless,checked,muted,multiple,selected`
  );

  // node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
  function warn(msg, ...args) {
    console.warn(`[Vue warn] ${msg}`, ...args);
  }
  var activeEffectScope;
  function recordEffectScope(effect2, scope = activeEffectScope) {
    if (scope && scope.active) {
      scope.effects.push(effect2);
    }
  }
  function getCurrentScope() {
    return activeEffectScope;
  }
  var createDep = (effects) => {
    const dep = new Set(effects);
    dep.w = 0;
    dep.n = 0;
    return dep;
  };
  var wasTracked = (dep) => (dep.w & trackOpBit) > 0;
  var newTracked = (dep) => (dep.n & trackOpBit) > 0;
  var initDepMarkers = ({ deps }) => {
    if (deps.length) {
      for (let i = 0; i < deps.length; i++) {
        deps[i].w |= trackOpBit;
      }
    }
  };
  var finalizeDepMarkers = (effect2) => {
    const { deps } = effect2;
    if (deps.length) {
      let ptr = 0;
      for (let i = 0; i < deps.length; i++) {
        const dep = deps[i];
        if (wasTracked(dep) && !newTracked(dep)) {
          dep.delete(effect2);
        } else {
          deps[ptr++] = dep;
        }
        dep.w &= ~trackOpBit;
        dep.n &= ~trackOpBit;
      }
      deps.length = ptr;
    }
  };
  var targetMap = /* @__PURE__ */ new WeakMap();
  var effectTrackDepth = 0;
  var trackOpBit = 1;
  var maxMarkerBits = 30;
  var activeEffect;
  var ITERATE_KEY = Symbol(true ? "iterate" : "");
  var MAP_KEY_ITERATE_KEY = Symbol(true ? "Map key iterate" : "");
  var ReactiveEffect = class {
    constructor(fn, scheduler = null, scope) {
      this.fn = fn;
      this.scheduler = scheduler;
      this.active = true;
      this.deps = [];
      this.parent = void 0;
      recordEffectScope(this, scope);
    }
    run() {
      if (!this.active) {
        return this.fn();
      }
      let parent = activeEffect;
      let lastShouldTrack = shouldTrack;
      while (parent) {
        if (parent === this) {
          return;
        }
        parent = parent.parent;
      }
      try {
        this.parent = activeEffect;
        activeEffect = this;
        shouldTrack = true;
        trackOpBit = 1 << ++effectTrackDepth;
        if (effectTrackDepth <= maxMarkerBits) {
          initDepMarkers(this);
        } else {
          cleanupEffect(this);
        }
        return this.fn();
      } finally {
        if (effectTrackDepth <= maxMarkerBits) {
          finalizeDepMarkers(this);
        }
        trackOpBit = 1 << --effectTrackDepth;
        activeEffect = this.parent;
        shouldTrack = lastShouldTrack;
        this.parent = void 0;
        if (this.deferStop) {
          this.stop();
        }
      }
    }
    stop() {
      if (activeEffect === this) {
        this.deferStop = true;
      } else if (this.active) {
        cleanupEffect(this);
        if (this.onStop) {
          this.onStop();
        }
        this.active = false;
      }
    }
  };
  function cleanupEffect(effect2) {
    const { deps } = effect2;
    if (deps.length) {
      for (let i = 0; i < deps.length; i++) {
        deps[i].delete(effect2);
      }
      deps.length = 0;
    }
  }
  var shouldTrack = true;
  var trackStack = [];
  function pauseTracking() {
    trackStack.push(shouldTrack);
    shouldTrack = false;
  }
  function resetTracking() {
    const last = trackStack.pop();
    shouldTrack = last === void 0 ? true : last;
  }
  function track(target, type, key) {
    if (shouldTrack && activeEffect) {
      let depsMap = targetMap.get(target);
      if (!depsMap) {
        targetMap.set(target, depsMap = /* @__PURE__ */ new Map());
      }
      let dep = depsMap.get(key);
      if (!dep) {
        depsMap.set(key, dep = createDep());
      }
      const eventInfo = true ? { effect: activeEffect, target, type, key } : void 0;
      trackEffects(dep, eventInfo);
    }
  }
  function trackEffects(dep, debuggerEventExtraInfo) {
    let shouldTrack2 = false;
    if (effectTrackDepth <= maxMarkerBits) {
      if (!newTracked(dep)) {
        dep.n |= trackOpBit;
        shouldTrack2 = !wasTracked(dep);
      }
    } else {
      shouldTrack2 = !dep.has(activeEffect);
    }
    if (shouldTrack2) {
      dep.add(activeEffect);
      activeEffect.deps.push(dep);
      if (activeEffect.onTrack) {
        activeEffect.onTrack(
          extend(
            {
              effect: activeEffect
            },
            debuggerEventExtraInfo
          )
        );
      }
    }
  }
  function trigger(target, type, key, newValue, oldValue, oldTarget) {
    const depsMap = targetMap.get(target);
    if (!depsMap) {
      return;
    }
    let deps = [];
    if (type === "clear") {
      deps = [...depsMap.values()];
    } else if (key === "length" && isArray(target)) {
      const newLength = Number(newValue);
      depsMap.forEach((dep, key2) => {
        if (key2 === "length" || key2 >= newLength) {
          deps.push(dep);
        }
      });
    } else {
      if (key !== void 0) {
        deps.push(depsMap.get(key));
      }
      switch (type) {
        case "add":
          if (!isArray(target)) {
            deps.push(depsMap.get(ITERATE_KEY));
            if (isMap(target)) {
              deps.push(depsMap.get(MAP_KEY_ITERATE_KEY));
            }
          } else if (isIntegerKey(key)) {
            deps.push(depsMap.get("length"));
          }
          break;
        case "delete":
          if (!isArray(target)) {
            deps.push(depsMap.get(ITERATE_KEY));
            if (isMap(target)) {
              deps.push(depsMap.get(MAP_KEY_ITERATE_KEY));
            }
          }
          break;
        case "set":
          if (isMap(target)) {
            deps.push(depsMap.get(ITERATE_KEY));
          }
          break;
      }
    }
    const eventInfo = true ? { target, type, key, newValue, oldValue, oldTarget } : void 0;
    if (deps.length === 1) {
      if (deps[0]) {
        if (true) {
          triggerEffects(deps[0], eventInfo);
        } else {
          triggerEffects(deps[0]);
        }
      }
    } else {
      const effects = [];
      for (const dep of deps) {
        if (dep) {
          effects.push(...dep);
        }
      }
      if (true) {
        triggerEffects(createDep(effects), eventInfo);
      } else {
        triggerEffects(createDep(effects));
      }
    }
  }
  function triggerEffects(dep, debuggerEventExtraInfo) {
    const effects = isArray(dep) ? dep : [...dep];
    for (const effect2 of effects) {
      if (effect2.computed) {
        triggerEffect(effect2, debuggerEventExtraInfo);
      }
    }
    for (const effect2 of effects) {
      if (!effect2.computed) {
        triggerEffect(effect2, debuggerEventExtraInfo);
      }
    }
  }
  function triggerEffect(effect2, debuggerEventExtraInfo) {
    if (effect2 !== activeEffect || effect2.allowRecurse) {
      if (effect2.onTrigger) {
        effect2.onTrigger(extend({ effect: effect2 }, debuggerEventExtraInfo));
      }
      if (effect2.scheduler) {
        effect2.scheduler();
      } else {
        effect2.run();
      }
    }
  }
  var isNonTrackableKeys = /* @__PURE__ */ makeMap(`__proto__,__v_isRef,__isVue`);
  var builtInSymbols = new Set(
    /* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((key) => key !== "arguments" && key !== "caller").map((key) => Symbol[key]).filter(isSymbol)
  );
  var get$1 = /* @__PURE__ */ createGetter();
  var readonlyGet = /* @__PURE__ */ createGetter(true);
  var shallowReadonlyGet = /* @__PURE__ */ createGetter(true, true);
  var arrayInstrumentations = /* @__PURE__ */ createArrayInstrumentations();
  function createArrayInstrumentations() {
    const instrumentations = {};
    ["includes", "indexOf", "lastIndexOf"].forEach((key) => {
      instrumentations[key] = function(...args) {
        const arr = toRaw(this);
        for (let i = 0, l = this.length; i < l; i++) {
          track(arr, "get", i + "");
        }
        const res = arr[key](...args);
        if (res === -1 || res === false) {
          return arr[key](...args.map(toRaw));
        } else {
          return res;
        }
      };
    });
    ["push", "pop", "shift", "unshift", "splice"].forEach((key) => {
      instrumentations[key] = function(...args) {
        pauseTracking();
        const res = toRaw(this)[key].apply(this, args);
        resetTracking();
        return res;
      };
    });
    return instrumentations;
  }
  function hasOwnProperty2(key) {
    const obj = toRaw(this);
    track(obj, "has", key);
    return obj.hasOwnProperty(key);
  }
  function createGetter(isReadonly2 = false, shallow = false) {
    return function get2(target, key, receiver) {
      if (key === "__v_isReactive") {
        return !isReadonly2;
      } else if (key === "__v_isReadonly") {
        return isReadonly2;
      } else if (key === "__v_isShallow") {
        return shallow;
      } else if (key === "__v_raw" && receiver === (isReadonly2 ? shallow ? shallowReadonlyMap : readonlyMap : shallow ? shallowReactiveMap : reactiveMap).get(target)) {
        return target;
      }
      const targetIsArray = isArray(target);
      if (!isReadonly2) {
        if (targetIsArray && hasOwn(arrayInstrumentations, key)) {
          return Reflect.get(arrayInstrumentations, key, receiver);
        }
        if (key === "hasOwnProperty") {
          return hasOwnProperty2;
        }
      }
      const res = Reflect.get(target, key, receiver);
      if (isSymbol(key) ? builtInSymbols.has(key) : isNonTrackableKeys(key)) {
        return res;
      }
      if (!isReadonly2) {
        track(target, "get", key);
      }
      if (shallow) {
        return res;
      }
      if (isRef(res)) {
        return targetIsArray && isIntegerKey(key) ? res : res.value;
      }
      if (isObject(res)) {
        return isReadonly2 ? readonly(res) : reactive(res);
      }
      return res;
    };
  }
  var set$1 = /* @__PURE__ */ createSetter();
  function createSetter(shallow = false) {
    return function set22(target, key, value, receiver) {
      let oldValue = target[key];
      if (isReadonly(oldValue) && isRef(oldValue) && !isRef(value)) {
        return false;
      }
      if (!shallow) {
        if (!isShallow(value) && !isReadonly(value)) {
          oldValue = toRaw(oldValue);
          value = toRaw(value);
        }
        if (!isArray(target) && isRef(oldValue) && !isRef(value)) {
          oldValue.value = value;
          return true;
        }
      }
      const hadKey = isArray(target) && isIntegerKey(key) ? Number(key) < target.length : hasOwn(target, key);
      const result = Reflect.set(target, key, value, receiver);
      if (target === toRaw(receiver)) {
        if (!hadKey) {
          trigger(target, "add", key, value);
        } else if (hasChanged(value, oldValue)) {
          trigger(target, "set", key, value, oldValue);
        }
      }
      return result;
    };
  }
  function deleteProperty(target, key) {
    const hadKey = hasOwn(target, key);
    const oldValue = target[key];
    const result = Reflect.deleteProperty(target, key);
    if (result && hadKey) {
      trigger(target, "delete", key, void 0, oldValue);
    }
    return result;
  }
  function has$1(target, key) {
    const result = Reflect.has(target, key);
    if (!isSymbol(key) || !builtInSymbols.has(key)) {
      track(target, "has", key);
    }
    return result;
  }
  function ownKeys(target) {
    track(target, "iterate", isArray(target) ? "length" : ITERATE_KEY);
    return Reflect.ownKeys(target);
  }
  var mutableHandlers = {
    get: get$1,
    set: set$1,
    deleteProperty,
    has: has$1,
    ownKeys
  };
  var readonlyHandlers = {
    get: readonlyGet,
    set(target, key) {
      if (true) {
        warn(
          `Set operation on key "${String(key)}" failed: target is readonly.`,
          target
        );
      }
      return true;
    },
    deleteProperty(target, key) {
      if (true) {
        warn(
          `Delete operation on key "${String(key)}" failed: target is readonly.`,
          target
        );
      }
      return true;
    }
  };
  var shallowReadonlyHandlers = /* @__PURE__ */ extend(
    {},
    readonlyHandlers,
    {
      get: shallowReadonlyGet
    }
  );
  var toShallow = (value) => value;
  var getProto = (v) => Reflect.getPrototypeOf(v);
  function get(target, key, isReadonly2 = false, isShallow3 = false) {
    target = target["__v_raw"];
    const rawTarget = toRaw(target);
    const rawKey = toRaw(key);
    if (!isReadonly2) {
      if (key !== rawKey) {
        track(rawTarget, "get", key);
      }
      track(rawTarget, "get", rawKey);
    }
    const { has: has2 } = getProto(rawTarget);
    const wrap = isShallow3 ? toShallow : isReadonly2 ? toReadonly : toReactive;
    if (has2.call(rawTarget, key)) {
      return wrap(target.get(key));
    } else if (has2.call(rawTarget, rawKey)) {
      return wrap(target.get(rawKey));
    } else if (target !== rawTarget) {
      target.get(key);
    }
  }
  function has(key, isReadonly2 = false) {
    const target = this["__v_raw"];
    const rawTarget = toRaw(target);
    const rawKey = toRaw(key);
    if (!isReadonly2) {
      if (key !== rawKey) {
        track(rawTarget, "has", key);
      }
      track(rawTarget, "has", rawKey);
    }
    return key === rawKey ? target.has(key) : target.has(key) || target.has(rawKey);
  }
  function size(target, isReadonly2 = false) {
    target = target["__v_raw"];
    !isReadonly2 && track(toRaw(target), "iterate", ITERATE_KEY);
    return Reflect.get(target, "size", target);
  }
  function add(value) {
    value = toRaw(value);
    const target = toRaw(this);
    const proto = getProto(target);
    const hadKey = proto.has.call(target, value);
    if (!hadKey) {
      target.add(value);
      trigger(target, "add", value, value);
    }
    return this;
  }
  function set(key, value) {
    value = toRaw(value);
    const target = toRaw(this);
    const { has: has2, get: get2 } = getProto(target);
    let hadKey = has2.call(target, key);
    if (!hadKey) {
      key = toRaw(key);
      hadKey = has2.call(target, key);
    } else if (true) {
      checkIdentityKeys(target, has2, key);
    }
    const oldValue = get2.call(target, key);
    target.set(key, value);
    if (!hadKey) {
      trigger(target, "add", key, value);
    } else if (hasChanged(value, oldValue)) {
      trigger(target, "set", key, value, oldValue);
    }
    return this;
  }
  function deleteEntry(key) {
    const target = toRaw(this);
    const { has: has2, get: get2 } = getProto(target);
    let hadKey = has2.call(target, key);
    if (!hadKey) {
      key = toRaw(key);
      hadKey = has2.call(target, key);
    } else if (true) {
      checkIdentityKeys(target, has2, key);
    }
    const oldValue = get2 ? get2.call(target, key) : void 0;
    const result = target.delete(key);
    if (hadKey) {
      trigger(target, "delete", key, void 0, oldValue);
    }
    return result;
  }
  function clear() {
    const target = toRaw(this);
    const hadItems = target.size !== 0;
    const oldTarget = true ? isMap(target) ? new Map(target) : new Set(target) : void 0;
    const result = target.clear();
    if (hadItems) {
      trigger(target, "clear", void 0, void 0, oldTarget);
    }
    return result;
  }
  function createForEach(isReadonly2, isShallow3) {
    return function forEach(callback, thisArg) {
      const observed = this;
      const target = observed["__v_raw"];
      const rawTarget = toRaw(target);
      const wrap = isShallow3 ? toShallow : isReadonly2 ? toReadonly : toReactive;
      !isReadonly2 && track(rawTarget, "iterate", ITERATE_KEY);
      return target.forEach((value, key) => {
        return callback.call(thisArg, wrap(value), wrap(key), observed);
      });
    };
  }
  function createIterableMethod(method, isReadonly2, isShallow3) {
    return function(...args) {
      const target = this["__v_raw"];
      const rawTarget = toRaw(target);
      const targetIsMap = isMap(rawTarget);
      const isPair = method === "entries" || method === Symbol.iterator && targetIsMap;
      const isKeyOnly = method === "keys" && targetIsMap;
      const innerIterator = target[method](...args);
      const wrap = isShallow3 ? toShallow : isReadonly2 ? toReadonly : toReactive;
      !isReadonly2 && track(
        rawTarget,
        "iterate",
        isKeyOnly ? MAP_KEY_ITERATE_KEY : ITERATE_KEY
      );
      return {
        // iterator protocol
        next() {
          const { value, done } = innerIterator.next();
          return done ? { value, done } : {
            value: isPair ? [wrap(value[0]), wrap(value[1])] : wrap(value),
            done
          };
        },
        // iterable protocol
        [Symbol.iterator]() {
          return this;
        }
      };
    };
  }
  function createReadonlyMethod(type) {
    return function(...args) {
      if (true) {
        const key = args[0] ? `on key "${args[0]}" ` : ``;
        console.warn(
          `${capitalize(type)} operation ${key}failed: target is readonly.`,
          toRaw(this)
        );
      }
      return type === "delete" ? false : this;
    };
  }
  function createInstrumentations() {
    const mutableInstrumentations2 = {
      get(key) {
        return get(this, key);
      },
      get size() {
        return size(this);
      },
      has,
      add,
      set,
      delete: deleteEntry,
      clear,
      forEach: createForEach(false, false)
    };
    const shallowInstrumentations2 = {
      get(key) {
        return get(this, key, false, true);
      },
      get size() {
        return size(this);
      },
      has,
      add,
      set,
      delete: deleteEntry,
      clear,
      forEach: createForEach(false, true)
    };
    const readonlyInstrumentations2 = {
      get(key) {
        return get(this, key, true);
      },
      get size() {
        return size(this, true);
      },
      has(key) {
        return has.call(this, key, true);
      },
      add: createReadonlyMethod("add"),
      set: createReadonlyMethod("set"),
      delete: createReadonlyMethod("delete"),
      clear: createReadonlyMethod("clear"),
      forEach: createForEach(true, false)
    };
    const shallowReadonlyInstrumentations2 = {
      get(key) {
        return get(this, key, true, true);
      },
      get size() {
        return size(this, true);
      },
      has(key) {
        return has.call(this, key, true);
      },
      add: createReadonlyMethod("add"),
      set: createReadonlyMethod("set"),
      delete: createReadonlyMethod("delete"),
      clear: createReadonlyMethod("clear"),
      forEach: createForEach(true, true)
    };
    const iteratorMethods = ["keys", "values", "entries", Symbol.iterator];
    iteratorMethods.forEach((method) => {
      mutableInstrumentations2[method] = createIterableMethod(
        method,
        false,
        false
      );
      readonlyInstrumentations2[method] = createIterableMethod(
        method,
        true,
        false
      );
      shallowInstrumentations2[method] = createIterableMethod(
        method,
        false,
        true
      );
      shallowReadonlyInstrumentations2[method] = createIterableMethod(
        method,
        true,
        true
      );
    });
    return [
      mutableInstrumentations2,
      readonlyInstrumentations2,
      shallowInstrumentations2,
      shallowReadonlyInstrumentations2
    ];
  }
  var [
    mutableInstrumentations,
    readonlyInstrumentations,
    shallowInstrumentations,
    shallowReadonlyInstrumentations
  ] = /* @__PURE__ */ createInstrumentations();
  function createInstrumentationGetter(isReadonly2, shallow) {
    const instrumentations = shallow ? isReadonly2 ? shallowReadonlyInstrumentations : shallowInstrumentations : isReadonly2 ? readonlyInstrumentations : mutableInstrumentations;
    return (target, key, receiver) => {
      if (key === "__v_isReactive") {
        return !isReadonly2;
      } else if (key === "__v_isReadonly") {
        return isReadonly2;
      } else if (key === "__v_raw") {
        return target;
      }
      return Reflect.get(
        hasOwn(instrumentations, key) && key in target ? instrumentations : target,
        key,
        receiver
      );
    };
  }
  var mutableCollectionHandlers = {
    get: /* @__PURE__ */ createInstrumentationGetter(false, false)
  };
  var readonlyCollectionHandlers = {
    get: /* @__PURE__ */ createInstrumentationGetter(true, false)
  };
  var shallowReadonlyCollectionHandlers = {
    get: /* @__PURE__ */ createInstrumentationGetter(true, true)
  };
  function checkIdentityKeys(target, has2, key) {
    const rawKey = toRaw(key);
    if (rawKey !== key && has2.call(target, rawKey)) {
      const type = toRawType(target);
      console.warn(
        `Reactive ${type} contains both the raw and reactive versions of the same object${type === `Map` ? ` as keys` : ``}, which can lead to inconsistencies. Avoid differentiating between the raw and reactive versions of an object and only use the reactive version if possible.`
      );
    }
  }
  var reactiveMap = /* @__PURE__ */ new WeakMap();
  var shallowReactiveMap = /* @__PURE__ */ new WeakMap();
  var readonlyMap = /* @__PURE__ */ new WeakMap();
  var shallowReadonlyMap = /* @__PURE__ */ new WeakMap();
  function targetTypeMap(rawType) {
    switch (rawType) {
      case "Object":
      case "Array":
        return 1;
      case "Map":
      case "Set":
      case "WeakMap":
      case "WeakSet":
        return 2;
      default:
        return 0;
    }
  }
  function getTargetType(value) {
    return value["__v_skip"] || !Object.isExtensible(value) ? 0 : targetTypeMap(toRawType(value));
  }
  function reactive(target) {
    if (isReadonly(target)) {
      return target;
    }
    return createReactiveObject(
      target,
      false,
      mutableHandlers,
      mutableCollectionHandlers,
      reactiveMap
    );
  }
  function readonly(target) {
    return createReactiveObject(
      target,
      true,
      readonlyHandlers,
      readonlyCollectionHandlers,
      readonlyMap
    );
  }
  function shallowReadonly(target) {
    return createReactiveObject(
      target,
      true,
      shallowReadonlyHandlers,
      shallowReadonlyCollectionHandlers,
      shallowReadonlyMap
    );
  }
  function createReactiveObject(target, isReadonly2, baseHandlers, collectionHandlers, proxyMap) {
    if (!isObject(target)) {
      if (true) {
        console.warn(`value cannot be made reactive: ${String(target)}`);
      }
      return target;
    }
    if (target["__v_raw"] && !(isReadonly2 && target["__v_isReactive"])) {
      return target;
    }
    const existingProxy = proxyMap.get(target);
    if (existingProxy) {
      return existingProxy;
    }
    const targetType = getTargetType(target);
    if (targetType === 0) {
      return target;
    }
    const proxy = new Proxy(
      target,
      targetType === 2 ? collectionHandlers : baseHandlers
    );
    proxyMap.set(target, proxy);
    return proxy;
  }
  function isReactive(value) {
    if (isReadonly(value)) {
      return isReactive(value["__v_raw"]);
    }
    return !!(value && value["__v_isReactive"]);
  }
  function isReadonly(value) {
    return !!(value && value["__v_isReadonly"]);
  }
  function isShallow(value) {
    return !!(value && value["__v_isShallow"]);
  }
  function toRaw(observed) {
    const raw = observed && observed["__v_raw"];
    return raw ? toRaw(raw) : observed;
  }
  function markRaw(value) {
    def(value, "__v_skip", true);
    return value;
  }
  var toReactive = (value) => isObject(value) ? reactive(value) : value;
  var toReadonly = (value) => isObject(value) ? readonly(value) : value;
  function trackRefValue(ref2) {
    if (shouldTrack && activeEffect) {
      ref2 = toRaw(ref2);
      if (true) {
        trackEffects(ref2.dep || (ref2.dep = createDep()), {
          target: ref2,
          type: "get",
          key: "value"
        });
      } else {
        trackEffects(ref2.dep || (ref2.dep = createDep()));
      }
    }
  }
  function triggerRefValue(ref2, newVal) {
    ref2 = toRaw(ref2);
    const dep = ref2.dep;
    if (dep) {
      if (true) {
        triggerEffects(dep, {
          target: ref2,
          type: "set",
          key: "value",
          newValue: newVal
        });
      } else {
        triggerEffects(dep);
      }
    }
  }
  function isRef(r) {
    return !!(r && r.__v_isRef === true);
  }
  function ref(value) {
    return createRef(value, false);
  }
  function createRef(rawValue, shallow) {
    if (isRef(rawValue)) {
      return rawValue;
    }
    return new RefImpl(rawValue, shallow);
  }
  var RefImpl = class {
    constructor(value, __v_isShallow) {
      this.__v_isShallow = __v_isShallow;
      this.dep = void 0;
      this.__v_isRef = true;
      this._rawValue = __v_isShallow ? value : toRaw(value);
      this._value = __v_isShallow ? value : toReactive(value);
    }
    get value() {
      trackRefValue(this);
      return this._value;
    }
    set value(newVal) {
      const useDirectValue = this.__v_isShallow || isShallow(newVal) || isReadonly(newVal);
      newVal = useDirectValue ? newVal : toRaw(newVal);
      if (hasChanged(newVal, this._rawValue)) {
        this._rawValue = newVal;
        this._value = useDirectValue ? newVal : toReactive(newVal);
        triggerRefValue(this, newVal);
      }
    }
  };
  function unref(ref2) {
    return isRef(ref2) ? ref2.value : ref2;
  }
  var shallowUnwrapHandlers = {
    get: (target, key, receiver) => unref(Reflect.get(target, key, receiver)),
    set: (target, key, value, receiver) => {
      const oldValue = target[key];
      if (isRef(oldValue) && !isRef(value)) {
        oldValue.value = value;
        return true;
      } else {
        return Reflect.set(target, key, value, receiver);
      }
    }
  };
  function proxyRefs(objectWithRefs) {
    return isReactive(objectWithRefs) ? objectWithRefs : new Proxy(objectWithRefs, shallowUnwrapHandlers);
  }
  var ComputedRefImpl = class {
    constructor(getter, _setter, isReadonly2, isSSR) {
      this._setter = _setter;
      this.dep = void 0;
      this.__v_isRef = true;
      this["__v_isReadonly"] = false;
      this._dirty = true;
      this.effect = new ReactiveEffect(getter, () => {
        if (!this._dirty) {
          this._dirty = true;
          triggerRefValue(this);
        }
      });
      this.effect.computed = this;
      this.effect.active = this._cacheable = !isSSR;
      this["__v_isReadonly"] = isReadonly2;
    }
    get value() {
      const self2 = toRaw(this);
      trackRefValue(self2);
      if (self2._dirty || !self2._cacheable) {
        self2._dirty = false;
        self2._value = self2.effect.run();
      }
      return self2._value;
    }
    set value(newValue) {
      this._setter(newValue);
    }
  };
  function computed(getterOrOptions, debugOptions, isSSR = false) {
    let getter;
    let setter;
    const onlyGetter = isFunction(getterOrOptions);
    if (onlyGetter) {
      getter = getterOrOptions;
      setter = true ? () => {
        console.warn("Write operation failed: computed value is readonly");
      } : NOOP;
    } else {
      getter = getterOrOptions.get;
      setter = getterOrOptions.set;
    }
    const cRef = new ComputedRefImpl(getter, setter, onlyGetter || !setter, isSSR);
    if (debugOptions && !isSSR) {
      cRef.effect.onTrack = debugOptions.onTrack;
      cRef.effect.onTrigger = debugOptions.onTrigger;
    }
    return cRef;
  }

  // node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
  var stack = [];
  function pushWarningContext(vnode) {
    stack.push(vnode);
  }
  function popWarningContext() {
    stack.pop();
  }
  function warn2(msg, ...args) {
    if (false)
      return;
    pauseTracking();
    const instance = stack.length ? stack[stack.length - 1].component : null;
    const appWarnHandler = instance && instance.appContext.config.warnHandler;
    const trace = getComponentTrace();
    if (appWarnHandler) {
      callWithErrorHandling(
        appWarnHandler,
        instance,
        11,
        [
          msg + args.join(""),
          instance && instance.proxy,
          trace.map(
            ({ vnode }) => `at <${formatComponentName(instance, vnode.type)}>`
          ).join("\n"),
          trace
        ]
      );
    } else {
      const warnArgs = [`[Vue warn]: ${msg}`, ...args];
      if (trace.length && // avoid spamming console during tests
      true) {
        warnArgs.push(`
`, ...formatTrace(trace));
      }
      console.warn(...warnArgs);
    }
    resetTracking();
  }
  function getComponentTrace() {
    let currentVNode = stack[stack.length - 1];
    if (!currentVNode) {
      return [];
    }
    const normalizedStack = [];
    while (currentVNode) {
      const last = normalizedStack[0];
      if (last && last.vnode === currentVNode) {
        last.recurseCount++;
      } else {
        normalizedStack.push({
          vnode: currentVNode,
          recurseCount: 0
        });
      }
      const parentInstance = currentVNode.component && currentVNode.component.parent;
      currentVNode = parentInstance && parentInstance.vnode;
    }
    return normalizedStack;
  }
  function formatTrace(trace) {
    const logs = [];
    trace.forEach((entry, i) => {
      logs.push(...i === 0 ? [] : [`
`], ...formatTraceEntry(entry));
    });
    return logs;
  }
  function formatTraceEntry({ vnode, recurseCount }) {
    const postfix = recurseCount > 0 ? `... (${recurseCount} recursive calls)` : ``;
    const isRoot = vnode.component ? vnode.component.parent == null : false;
    const open = ` at <${formatComponentName(
      vnode.component,
      vnode.type,
      isRoot
    )}`;
    const close = `>` + postfix;
    return vnode.props ? [open, ...formatProps(vnode.props), close] : [open + close];
  }
  function formatProps(props) {
    const res = [];
    const keys = Object.keys(props);
    keys.slice(0, 3).forEach((key) => {
      res.push(...formatProp(key, props[key]));
    });
    if (keys.length > 3) {
      res.push(` ...`);
    }
    return res;
  }
  function formatProp(key, value, raw) {
    if (isString(value)) {
      value = JSON.stringify(value);
      return raw ? value : [`${key}=${value}`];
    } else if (typeof value === "number" || typeof value === "boolean" || value == null) {
      return raw ? value : [`${key}=${value}`];
    } else if (isRef(value)) {
      value = formatProp(key, toRaw(value.value), true);
      return raw ? value : [`${key}=Ref<`, value, `>`];
    } else if (isFunction(value)) {
      return [`${key}=fn${value.name ? `<${value.name}>` : ``}`];
    } else {
      value = toRaw(value);
      return raw ? value : [`${key}=`, value];
    }
  }
  var ErrorTypeStrings = {
    ["sp"]: "serverPrefetch hook",
    ["bc"]: "beforeCreate hook",
    ["c"]: "created hook",
    ["bm"]: "beforeMount hook",
    ["m"]: "mounted hook",
    ["bu"]: "beforeUpdate hook",
    ["u"]: "updated",
    ["bum"]: "beforeUnmount hook",
    ["um"]: "unmounted hook",
    ["a"]: "activated hook",
    ["da"]: "deactivated hook",
    ["ec"]: "errorCaptured hook",
    ["rtc"]: "renderTracked hook",
    ["rtg"]: "renderTriggered hook",
    [0]: "setup function",
    [1]: "render function",
    [2]: "watcher getter",
    [3]: "watcher callback",
    [4]: "watcher cleanup function",
    [5]: "native event handler",
    [6]: "component event handler",
    [7]: "vnode hook",
    [8]: "directive hook",
    [9]: "transition hook",
    [10]: "app errorHandler",
    [11]: "app warnHandler",
    [12]: "ref function",
    [13]: "async component loader",
    [14]: "scheduler flush. This is likely a Vue internals bug. Please open an issue at https://new-issue.vuejs.org/?repo=vuejs/core"
  };
  function callWithErrorHandling(fn, instance, type, args) {
    let res;
    try {
      res = args ? fn(...args) : fn();
    } catch (err) {
      handleError(err, instance, type);
    }
    return res;
  }
  function callWithAsyncErrorHandling(fn, instance, type, args) {
    if (isFunction(fn)) {
      const res = callWithErrorHandling(fn, instance, type, args);
      if (res && isPromise(res)) {
        res.catch((err) => {
          handleError(err, instance, type);
        });
      }
      return res;
    }
    const values = [];
    for (let i = 0; i < fn.length; i++) {
      values.push(callWithAsyncErrorHandling(fn[i], instance, type, args));
    }
    return values;
  }
  function handleError(err, instance, type, throwInDev = true) {
    const contextVNode = instance ? instance.vnode : null;
    if (instance) {
      let cur = instance.parent;
      const exposedInstance = instance.proxy;
      const errorInfo = true ? ErrorTypeStrings[type] : type;
      while (cur) {
        const errorCapturedHooks = cur.ec;
        if (errorCapturedHooks) {
          for (let i = 0; i < errorCapturedHooks.length; i++) {
            if (errorCapturedHooks[i](err, exposedInstance, errorInfo) === false) {
              return;
            }
          }
        }
        cur = cur.parent;
      }
      const appErrorHandler = instance.appContext.config.errorHandler;
      if (appErrorHandler) {
        callWithErrorHandling(
          appErrorHandler,
          null,
          10,
          [err, exposedInstance, errorInfo]
        );
        return;
      }
    }
    logError(err, type, contextVNode, throwInDev);
  }
  function logError(err, type, contextVNode, throwInDev = true) {
    if (true) {
      const info = ErrorTypeStrings[type];
      if (contextVNode) {
        pushWarningContext(contextVNode);
      }
      warn2(`Unhandled error${info ? ` during execution of ${info}` : ``}`);
      if (contextVNode) {
        popWarningContext();
      }
      if (throwInDev) {
        throw err;
      } else {
        console.error(err);
      }
    } else {
      console.error(err);
    }
  }
  var isFlushing = false;
  var isFlushPending = false;
  var queue = [];
  var flushIndex = 0;
  var pendingPostFlushCbs = [];
  var activePostFlushCbs = null;
  var postFlushIndex = 0;
  var resolvedPromise = /* @__PURE__ */ Promise.resolve();
  var currentFlushPromise = null;
  var RECURSION_LIMIT = 100;
  function nextTick(fn) {
    const p = currentFlushPromise || resolvedPromise;
    return fn ? p.then(this ? fn.bind(this) : fn) : p;
  }
  function findInsertionIndex(id) {
    let start = flushIndex + 1;
    let end = queue.length;
    while (start < end) {
      const middle = start + end >>> 1;
      const middleJobId = getId(queue[middle]);
      middleJobId < id ? start = middle + 1 : end = middle;
    }
    return start;
  }
  function queueJob(job) {
    if (!queue.length || !queue.includes(
      job,
      isFlushing && job.allowRecurse ? flushIndex + 1 : flushIndex
    )) {
      if (job.id == null) {
        queue.push(job);
      } else {
        queue.splice(findInsertionIndex(job.id), 0, job);
      }
      queueFlush();
    }
  }
  function queueFlush() {
    if (!isFlushing && !isFlushPending) {
      isFlushPending = true;
      currentFlushPromise = resolvedPromise.then(flushJobs);
    }
  }
  function queuePostFlushCb(cb) {
    if (!isArray(cb)) {
      if (!activePostFlushCbs || !activePostFlushCbs.includes(
        cb,
        cb.allowRecurse ? postFlushIndex + 1 : postFlushIndex
      )) {
        pendingPostFlushCbs.push(cb);
      }
    } else {
      pendingPostFlushCbs.push(...cb);
    }
    queueFlush();
  }
  function flushPostFlushCbs(seen) {
    if (pendingPostFlushCbs.length) {
      const deduped = [...new Set(pendingPostFlushCbs)];
      pendingPostFlushCbs.length = 0;
      if (activePostFlushCbs) {
        activePostFlushCbs.push(...deduped);
        return;
      }
      activePostFlushCbs = deduped;
      if (true) {
        seen = seen || /* @__PURE__ */ new Map();
      }
      activePostFlushCbs.sort((a, b) => getId(a) - getId(b));
      for (postFlushIndex = 0; postFlushIndex < activePostFlushCbs.length; postFlushIndex++) {
        if (checkRecursiveUpdates(seen, activePostFlushCbs[postFlushIndex])) {
          continue;
        }
        activePostFlushCbs[postFlushIndex]();
      }
      activePostFlushCbs = null;
      postFlushIndex = 0;
    }
  }
  var getId = (job) => job.id == null ? Infinity : job.id;
  var comparator = (a, b) => {
    const diff = getId(a) - getId(b);
    if (diff === 0) {
      if (a.pre && !b.pre)
        return -1;
      if (b.pre && !a.pre)
        return 1;
    }
    return diff;
  };
  function flushJobs(seen) {
    isFlushPending = false;
    isFlushing = true;
    if (true) {
      seen = seen || /* @__PURE__ */ new Map();
    }
    queue.sort(comparator);
    const check = true ? (job) => checkRecursiveUpdates(seen, job) : NOOP;
    try {
      for (flushIndex = 0; flushIndex < queue.length; flushIndex++) {
        const job = queue[flushIndex];
        if (job && job.active !== false) {
          if (check(job)) {
            continue;
          }
          callWithErrorHandling(job, null, 14);
        }
      }
    } finally {
      flushIndex = 0;
      queue.length = 0;
      flushPostFlushCbs(seen);
      isFlushing = false;
      currentFlushPromise = null;
      if (queue.length || pendingPostFlushCbs.length) {
        flushJobs(seen);
      }
    }
  }
  function checkRecursiveUpdates(seen, fn) {
    if (!seen.has(fn)) {
      seen.set(fn, 1);
    } else {
      const count = seen.get(fn);
      if (count > RECURSION_LIMIT) {
        const instance = fn.ownerInstance;
        const componentName = instance && getComponentName(instance.type);
        warn2(
          `Maximum recursive updates exceeded${componentName ? ` in component <${componentName}>` : ``}. This means you have a reactive effect that is mutating its own dependencies and thus recursively triggering itself. Possible sources include component template, render function, updated hook or watcher source function.`
        );
        return true;
      } else {
        seen.set(fn, count + 1);
      }
    }
  }
  var isHmrUpdating = false;
  var hmrDirtyComponents = /* @__PURE__ */ new Set();
  if (true) {
    getGlobalThis().__VUE_HMR_RUNTIME__ = {
      createRecord: tryWrap(createRecord),
      rerender: tryWrap(rerender),
      reload: tryWrap(reload)
    };
  }
  var map = /* @__PURE__ */ new Map();
  function createRecord(id, initialDef) {
    if (map.has(id)) {
      return false;
    }
    map.set(id, {
      initialDef: normalizeClassComponent(initialDef),
      instances: /* @__PURE__ */ new Set()
    });
    return true;
  }
  function normalizeClassComponent(component) {
    return isClassComponent(component) ? component.__vccOpts : component;
  }
  function rerender(id, newRender) {
    const record = map.get(id);
    if (!record) {
      return;
    }
    record.initialDef.render = newRender;
    [...record.instances].forEach((instance) => {
      if (newRender) {
        instance.render = newRender;
        normalizeClassComponent(instance.type).render = newRender;
      }
      instance.renderCache = [];
      isHmrUpdating = true;
      instance.update();
      isHmrUpdating = false;
    });
  }
  function reload(id, newComp) {
    const record = map.get(id);
    if (!record)
      return;
    newComp = normalizeClassComponent(newComp);
    updateComponentDef(record.initialDef, newComp);
    const instances = [...record.instances];
    for (const instance of instances) {
      const oldComp = normalizeClassComponent(instance.type);
      if (!hmrDirtyComponents.has(oldComp)) {
        if (oldComp !== record.initialDef) {
          updateComponentDef(oldComp, newComp);
        }
        hmrDirtyComponents.add(oldComp);
      }
      instance.appContext.propsCache.delete(instance.type);
      instance.appContext.emitsCache.delete(instance.type);
      instance.appContext.optionsCache.delete(instance.type);
      if (instance.ceReload) {
        hmrDirtyComponents.add(oldComp);
        instance.ceReload(newComp.styles);
        hmrDirtyComponents.delete(oldComp);
      } else if (instance.parent) {
        queueJob(instance.parent.update);
      } else if (instance.appContext.reload) {
        instance.appContext.reload();
      } else if (typeof window !== "undefined") {
        window.location.reload();
      } else {
        console.warn(
          "[HMR] Root or manually mounted instance modified. Full reload required."
        );
      }
    }
    queuePostFlushCb(() => {
      for (const instance of instances) {
        hmrDirtyComponents.delete(
          normalizeClassComponent(instance.type)
        );
      }
    });
  }
  function updateComponentDef(oldComp, newComp) {
    extend(oldComp, newComp);
    for (const key in oldComp) {
      if (key !== "__file" && !(key in newComp)) {
        delete oldComp[key];
      }
    }
  }
  function tryWrap(fn) {
    return (id, arg) => {
      try {
        return fn(id, arg);
      } catch (e) {
        console.error(e);
        console.warn(
          `[HMR] Something went wrong during Vue component hot-reload. Full reload required.`
        );
      }
    };
  }
  var currentRenderingInstance = null;
  var accessedAttrs = false;
  function markAttrsAccessed() {
    accessedAttrs = true;
  }
  function queueEffectWithSuspense(fn, suspense) {
    if (suspense && suspense.pendingBranch) {
      if (isArray(fn)) {
        suspense.effects.push(...fn);
      } else {
        suspense.effects.push(fn);
      }
    } else {
      queuePostFlushCb(fn);
    }
  }
  var INITIAL_WATCHER_VALUE = {};
  function watch(source, cb, options) {
    if (!isFunction(cb)) {
      warn2(
        `\`watch(fn, options?)\` signature has been moved to a separate API. Use \`watchEffect(fn, options?)\` instead. \`watch\` now only supports \`watch(source, cb, options?) signature.`
      );
    }
    return doWatch(source, cb, options);
  }
  function doWatch(source, cb, { immediate, deep, flush, onTrack, onTrigger } = EMPTY_OBJ) {
    var _a;
    if (!cb) {
      if (immediate !== void 0) {
        warn2(
          `watch() "immediate" option is only respected when using the watch(source, callback, options?) signature.`
        );
      }
      if (deep !== void 0) {
        warn2(
          `watch() "deep" option is only respected when using the watch(source, callback, options?) signature.`
        );
      }
    }
    const warnInvalidSource = (s) => {
      warn2(
        `Invalid watch source: `,
        s,
        `A watch source can only be a getter/effect function, a ref, a reactive object, or an array of these types.`
      );
    };
    const instance = getCurrentScope() === ((_a = currentInstance) == null ? void 0 : _a.scope) ? currentInstance : null;
    let getter;
    let forceTrigger = false;
    let isMultiSource = false;
    if (isRef(source)) {
      getter = () => source.value;
      forceTrigger = isShallow(source);
    } else if (isReactive(source)) {
      getter = () => source;
      deep = true;
    } else if (isArray(source)) {
      isMultiSource = true;
      forceTrigger = source.some((s) => isReactive(s) || isShallow(s));
      getter = () => source.map((s) => {
        if (isRef(s)) {
          return s.value;
        } else if (isReactive(s)) {
          return traverse(s);
        } else if (isFunction(s)) {
          return callWithErrorHandling(s, instance, 2);
        } else {
          warnInvalidSource(s);
        }
      });
    } else if (isFunction(source)) {
      if (cb) {
        getter = () => callWithErrorHandling(source, instance, 2);
      } else {
        getter = () => {
          if (instance && instance.isUnmounted) {
            return;
          }
          if (cleanup) {
            cleanup();
          }
          return callWithAsyncErrorHandling(
            source,
            instance,
            3,
            [onCleanup]
          );
        };
      }
    } else {
      getter = NOOP;
      warnInvalidSource(source);
    }
    if (cb && deep) {
      const baseGetter = getter;
      getter = () => traverse(baseGetter());
    }
    let cleanup;
    let onCleanup = (fn) => {
      cleanup = effect2.onStop = () => {
        callWithErrorHandling(fn, instance, 4);
      };
    };
    let ssrCleanup;
    if (isInSSRComponentSetup) {
      onCleanup = NOOP;
      if (!cb) {
        getter();
      } else if (immediate) {
        callWithAsyncErrorHandling(cb, instance, 3, [
          getter(),
          isMultiSource ? [] : void 0,
          onCleanup
        ]);
      }
      if (flush === "sync") {
        const ctx = useSSRContext();
        ssrCleanup = ctx.__watcherHandles || (ctx.__watcherHandles = []);
      } else {
        return NOOP;
      }
    }
    let oldValue = isMultiSource ? new Array(source.length).fill(INITIAL_WATCHER_VALUE) : INITIAL_WATCHER_VALUE;
    const job = () => {
      if (!effect2.active) {
        return;
      }
      if (cb) {
        const newValue = effect2.run();
        if (deep || forceTrigger || (isMultiSource ? newValue.some(
          (v, i) => hasChanged(v, oldValue[i])
        ) : hasChanged(newValue, oldValue)) || false) {
          if (cleanup) {
            cleanup();
          }
          callWithAsyncErrorHandling(cb, instance, 3, [
            newValue,
            // pass undefined as the old value when it's changed for the first time
            oldValue === INITIAL_WATCHER_VALUE ? void 0 : isMultiSource && oldValue[0] === INITIAL_WATCHER_VALUE ? [] : oldValue,
            onCleanup
          ]);
          oldValue = newValue;
        }
      } else {
        effect2.run();
      }
    };
    job.allowRecurse = !!cb;
    let scheduler;
    if (flush === "sync") {
      scheduler = job;
    } else if (flush === "post") {
      scheduler = () => queuePostRenderEffect(job, instance && instance.suspense);
    } else {
      job.pre = true;
      if (instance)
        job.id = instance.uid;
      scheduler = () => queueJob(job);
    }
    const effect2 = new ReactiveEffect(getter, scheduler);
    if (true) {
      effect2.onTrack = onTrack;
      effect2.onTrigger = onTrigger;
    }
    if (cb) {
      if (immediate) {
        job();
      } else {
        oldValue = effect2.run();
      }
    } else if (flush === "post") {
      queuePostRenderEffect(
        effect2.run.bind(effect2),
        instance && instance.suspense
      );
    } else {
      effect2.run();
    }
    const unwatch = () => {
      effect2.stop();
      if (instance && instance.scope) {
        remove(instance.scope.effects, effect2);
      }
    };
    if (ssrCleanup)
      ssrCleanup.push(unwatch);
    return unwatch;
  }
  function instanceWatch(source, value, options) {
    const publicThis = this.proxy;
    const getter = isString(source) ? source.includes(".") ? createPathGetter(publicThis, source) : () => publicThis[source] : source.bind(publicThis, publicThis);
    let cb;
    if (isFunction(value)) {
      cb = value;
    } else {
      cb = value.handler;
      options = value;
    }
    const cur = currentInstance;
    setCurrentInstance(this);
    const res = doWatch(getter, cb.bind(publicThis), options);
    if (cur) {
      setCurrentInstance(cur);
    } else {
      unsetCurrentInstance();
    }
    return res;
  }
  function createPathGetter(ctx, path) {
    const segments = path.split(".");
    return () => {
      let cur = ctx;
      for (let i = 0; i < segments.length && cur; i++) {
        cur = cur[segments[i]];
      }
      return cur;
    };
  }
  function traverse(value, seen) {
    if (!isObject(value) || value["__v_skip"]) {
      return value;
    }
    seen = seen || /* @__PURE__ */ new Set();
    if (seen.has(value)) {
      return value;
    }
    seen.add(value);
    if (isRef(value)) {
      traverse(value.value, seen);
    } else if (isArray(value)) {
      for (let i = 0; i < value.length; i++) {
        traverse(value[i], seen);
      }
    } else if (isSet(value) || isMap(value)) {
      value.forEach((v) => {
        traverse(v, seen);
      });
    } else if (isPlainObject(value)) {
      for (const key in value) {
        traverse(value[key], seen);
      }
    }
    return value;
  }
  function injectHook(type, hook, target = currentInstance, prepend = false) {
    if (target) {
      const hooks = target[type] || (target[type] = []);
      const wrappedHook = hook.__weh || (hook.__weh = (...args) => {
        if (target.isUnmounted) {
          return;
        }
        pauseTracking();
        setCurrentInstance(target);
        const res = callWithAsyncErrorHandling(hook, target, type, args);
        unsetCurrentInstance();
        resetTracking();
        return res;
      });
      if (prepend) {
        hooks.unshift(wrappedHook);
      } else {
        hooks.push(wrappedHook);
      }
      return wrappedHook;
    } else if (true) {
      const apiName = toHandlerKey(ErrorTypeStrings[type].replace(/ hook$/, ""));
      warn2(
        `${apiName} is called when there is no active component instance to be associated with. Lifecycle injection APIs can only be used during execution of setup(). If you are using async setup(), make sure to register lifecycle hooks before the first await statement.`
      );
    }
  }
  var createHook = (lifecycle) => (hook, target = currentInstance) => (
    // post-create lifecycle registrations are noops during SSR (except for serverPrefetch)
    (!isInSSRComponentSetup || lifecycle === "sp") && injectHook(lifecycle, (...args) => hook(...args), target)
  );
  var onBeforeMount = createHook("bm");
  var onMounted = createHook("m");
  var onBeforeUpdate = createHook("bu");
  var onUpdated = createHook("u");
  var onBeforeUnmount = createHook("bum");
  var onUnmounted = createHook("um");
  var onServerPrefetch = createHook("sp");
  var onRenderTriggered = createHook(
    "rtg"
  );
  var onRenderTracked = createHook(
    "rtc"
  );
  var NULL_DYNAMIC_COMPONENT = Symbol.for("v-ndc");
  var getPublicInstance = (i) => {
    if (!i)
      return null;
    if (isStatefulComponent(i))
      return getExposeProxy(i) || i.proxy;
    return getPublicInstance(i.parent);
  };
  var publicPropertiesMap = (
    // Move PURE marker to new line to workaround compiler discarding it
    // due to type annotation
    /* @__PURE__ */ extend(/* @__PURE__ */ Object.create(null), {
      $: (i) => i,
      $el: (i) => i.vnode.el,
      $data: (i) => i.data,
      $props: (i) => true ? shallowReadonly(i.props) : i.props,
      $attrs: (i) => true ? shallowReadonly(i.attrs) : i.attrs,
      $slots: (i) => true ? shallowReadonly(i.slots) : i.slots,
      $refs: (i) => true ? shallowReadonly(i.refs) : i.refs,
      $parent: (i) => getPublicInstance(i.parent),
      $root: (i) => getPublicInstance(i.root),
      $emit: (i) => i.emit,
      $options: (i) => __VUE_OPTIONS_API__ ? resolveMergedOptions(i) : i.type,
      $forceUpdate: (i) => i.f || (i.f = () => queueJob(i.update)),
      $nextTick: (i) => i.n || (i.n = nextTick.bind(i.proxy)),
      $watch: (i) => __VUE_OPTIONS_API__ ? instanceWatch.bind(i) : NOOP
    })
  );
  var isReservedPrefix = (key) => key === "_" || key === "$";
  var hasSetupBinding = (state, key) => state !== EMPTY_OBJ && !state.__isScriptSetup && hasOwn(state, key);
  var PublicInstanceProxyHandlers = {
    get({ _: instance }, key) {
      const { ctx, setupState, data, props, accessCache, type, appContext } = instance;
      if (key === "__isVue") {
        return true;
      }
      let normalizedProps;
      if (key[0] !== "$") {
        const n = accessCache[key];
        if (n !== void 0) {
          switch (n) {
            case 1:
              return setupState[key];
            case 2:
              return data[key];
            case 4:
              return ctx[key];
            case 3:
              return props[key];
          }
        } else if (hasSetupBinding(setupState, key)) {
          accessCache[key] = 1;
          return setupState[key];
        } else if (data !== EMPTY_OBJ && hasOwn(data, key)) {
          accessCache[key] = 2;
          return data[key];
        } else if (
          // only cache other properties when instance has declared (thus stable)
          // props
          (normalizedProps = instance.propsOptions[0]) && hasOwn(normalizedProps, key)
        ) {
          accessCache[key] = 3;
          return props[key];
        } else if (ctx !== EMPTY_OBJ && hasOwn(ctx, key)) {
          accessCache[key] = 4;
          return ctx[key];
        } else if (!__VUE_OPTIONS_API__ || shouldCacheAccess) {
          accessCache[key] = 0;
        }
      }
      const publicGetter = publicPropertiesMap[key];
      let cssModule, globalProperties;
      if (publicGetter) {
        if (key === "$attrs") {
          track(instance, "get", key);
          markAttrsAccessed();
        } else if (key === "$slots") {
          track(instance, "get", key);
        }
        return publicGetter(instance);
      } else if (
        // css module (injected by vue-loader)
        (cssModule = type.__cssModules) && (cssModule = cssModule[key])
      ) {
        return cssModule;
      } else if (ctx !== EMPTY_OBJ && hasOwn(ctx, key)) {
        accessCache[key] = 4;
        return ctx[key];
      } else if (
        // global properties
        globalProperties = appContext.config.globalProperties, hasOwn(globalProperties, key)
      ) {
        {
          return globalProperties[key];
        }
      } else if (currentRenderingInstance && (!isString(key) || // #1091 avoid internal isRef/isVNode checks on component instance leading
      // to infinite warning loop
      key.indexOf("__v") !== 0)) {
        if (data !== EMPTY_OBJ && isReservedPrefix(key[0]) && hasOwn(data, key)) {
          warn2(
            `Property ${JSON.stringify(
              key
            )} must be accessed via $data because it starts with a reserved character ("$" or "_") and is not proxied on the render context.`
          );
        } else if (instance === currentRenderingInstance) {
          warn2(
            `Property ${JSON.stringify(key)} was accessed during render but is not defined on instance.`
          );
        }
      }
    },
    set({ _: instance }, key, value) {
      const { data, setupState, ctx } = instance;
      if (hasSetupBinding(setupState, key)) {
        setupState[key] = value;
        return true;
      } else if (setupState.__isScriptSetup && hasOwn(setupState, key)) {
        warn2(`Cannot mutate <script setup> binding "${key}" from Options API.`);
        return false;
      } else if (data !== EMPTY_OBJ && hasOwn(data, key)) {
        data[key] = value;
        return true;
      } else if (hasOwn(instance.props, key)) {
        warn2(`Attempting to mutate prop "${key}". Props are readonly.`);
        return false;
      }
      if (key[0] === "$" && key.slice(1) in instance) {
        warn2(
          `Attempting to mutate public property "${key}". Properties starting with $ are reserved and readonly.`
        );
        return false;
      } else {
        if (key in instance.appContext.config.globalProperties) {
          Object.defineProperty(ctx, key, {
            enumerable: true,
            configurable: true,
            value
          });
        } else {
          ctx[key] = value;
        }
      }
      return true;
    },
    has({
      _: { data, setupState, accessCache, ctx, appContext, propsOptions }
    }, key) {
      let normalizedProps;
      return !!accessCache[key] || data !== EMPTY_OBJ && hasOwn(data, key) || hasSetupBinding(setupState, key) || (normalizedProps = propsOptions[0]) && hasOwn(normalizedProps, key) || hasOwn(ctx, key) || hasOwn(publicPropertiesMap, key) || hasOwn(appContext.config.globalProperties, key);
    },
    defineProperty(target, key, descriptor) {
      if (descriptor.get != null) {
        target._.accessCache[key] = 0;
      } else if (hasOwn(descriptor, "value")) {
        this.set(target, key, descriptor.value, null);
      }
      return Reflect.defineProperty(target, key, descriptor);
    }
  };
  if (true) {
    PublicInstanceProxyHandlers.ownKeys = (target) => {
      warn2(
        `Avoid app logic that relies on enumerating keys on a component instance. The keys will be empty in production mode to avoid performance overhead.`
      );
      return Reflect.ownKeys(target);
    };
  }
  function normalizePropsOrEmits(props) {
    return isArray(props) ? props.reduce(
      (normalized, p) => (normalized[p] = null, normalized),
      {}
    ) : props;
  }
  var shouldCacheAccess = true;
  function resolveMergedOptions(instance) {
    const base = instance.type;
    const { mixins, extends: extendsOptions } = base;
    const {
      mixins: globalMixins,
      optionsCache: cache,
      config: { optionMergeStrategies }
    } = instance.appContext;
    const cached = cache.get(base);
    let resolved;
    if (cached) {
      resolved = cached;
    } else if (!globalMixins.length && !mixins && !extendsOptions) {
      {
        resolved = base;
      }
    } else {
      resolved = {};
      if (globalMixins.length) {
        globalMixins.forEach(
          (m) => mergeOptions(resolved, m, optionMergeStrategies, true)
        );
      }
      mergeOptions(resolved, base, optionMergeStrategies);
    }
    if (isObject(base)) {
      cache.set(base, resolved);
    }
    return resolved;
  }
  function mergeOptions(to, from, strats, asMixin = false) {
    const { mixins, extends: extendsOptions } = from;
    if (extendsOptions) {
      mergeOptions(to, extendsOptions, strats, true);
    }
    if (mixins) {
      mixins.forEach(
        (m) => mergeOptions(to, m, strats, true)
      );
    }
    for (const key in from) {
      if (asMixin && key === "expose") {
        warn2(
          `"expose" option is ignored when declared in mixins or extends. It should only be declared in the base component itself.`
        );
      } else {
        const strat = internalOptionMergeStrats[key] || strats && strats[key];
        to[key] = strat ? strat(to[key], from[key]) : from[key];
      }
    }
    return to;
  }
  var internalOptionMergeStrats = {
    data: mergeDataFn,
    props: mergeEmitsOrPropsOptions,
    emits: mergeEmitsOrPropsOptions,
    // objects
    methods: mergeObjectOptions,
    computed: mergeObjectOptions,
    // lifecycle
    beforeCreate: mergeAsArray,
    created: mergeAsArray,
    beforeMount: mergeAsArray,
    mounted: mergeAsArray,
    beforeUpdate: mergeAsArray,
    updated: mergeAsArray,
    beforeDestroy: mergeAsArray,
    beforeUnmount: mergeAsArray,
    destroyed: mergeAsArray,
    unmounted: mergeAsArray,
    activated: mergeAsArray,
    deactivated: mergeAsArray,
    errorCaptured: mergeAsArray,
    serverPrefetch: mergeAsArray,
    // assets
    components: mergeObjectOptions,
    directives: mergeObjectOptions,
    // watch
    watch: mergeWatchOptions,
    // provide / inject
    provide: mergeDataFn,
    inject: mergeInject
  };
  function mergeDataFn(to, from) {
    if (!from) {
      return to;
    }
    if (!to) {
      return from;
    }
    return function mergedDataFn() {
      return extend(
        isFunction(to) ? to.call(this, this) : to,
        isFunction(from) ? from.call(this, this) : from
      );
    };
  }
  function mergeInject(to, from) {
    return mergeObjectOptions(normalizeInject(to), normalizeInject(from));
  }
  function normalizeInject(raw) {
    if (isArray(raw)) {
      const res = {};
      for (let i = 0; i < raw.length; i++) {
        res[raw[i]] = raw[i];
      }
      return res;
    }
    return raw;
  }
  function mergeAsArray(to, from) {
    return to ? [...new Set([].concat(to, from))] : from;
  }
  function mergeObjectOptions(to, from) {
    return to ? extend(/* @__PURE__ */ Object.create(null), to, from) : from;
  }
  function mergeEmitsOrPropsOptions(to, from) {
    if (to) {
      if (isArray(to) && isArray(from)) {
        return [.../* @__PURE__ */ new Set([...to, ...from])];
      }
      return extend(
        /* @__PURE__ */ Object.create(null),
        normalizePropsOrEmits(to),
        normalizePropsOrEmits(from != null ? from : {})
      );
    } else {
      return from;
    }
  }
  function mergeWatchOptions(to, from) {
    if (!to)
      return from;
    if (!from)
      return to;
    const merged = extend(/* @__PURE__ */ Object.create(null), to);
    for (const key in from) {
      merged[key] = mergeAsArray(to[key], from[key]);
    }
    return merged;
  }
  function createAppContext() {
    return {
      app: null,
      config: {
        isNativeTag: NO,
        performance: false,
        globalProperties: {},
        optionMergeStrategies: {},
        errorHandler: void 0,
        warnHandler: void 0,
        compilerOptions: {}
      },
      mixins: [],
      components: {},
      directives: {},
      provides: /* @__PURE__ */ Object.create(null),
      optionsCache: /* @__PURE__ */ new WeakMap(),
      propsCache: /* @__PURE__ */ new WeakMap(),
      emitsCache: /* @__PURE__ */ new WeakMap()
    };
  }
  var currentApp = null;
  function inject(key, defaultValue, treatDefaultAsFactory = false) {
    const instance = currentInstance || currentRenderingInstance;
    if (instance || currentApp) {
      const provides = instance ? instance.parent == null ? instance.vnode.appContext && instance.vnode.appContext.provides : instance.parent.provides : currentApp._context.provides;
      if (provides && key in provides) {
        return provides[key];
      } else if (arguments.length > 1) {
        return treatDefaultAsFactory && isFunction(defaultValue) ? defaultValue.call(instance && instance.proxy) : defaultValue;
      } else if (true) {
        warn2(`injection "${String(key)}" not found.`);
      }
    } else if (true) {
      warn2(`inject() can only be used inside setup() or functional components.`);
    }
  }
  var queuePostRenderEffect = queueEffectWithSuspense;
  var Fragment = Symbol.for("v-fgt");
  var Text = Symbol.for("v-txt");
  var Comment = Symbol.for("v-cmt");
  var Static = Symbol.for("v-stc");
  var emptyAppContext = createAppContext();
  var currentInstance = null;
  var internalSetCurrentInstance;
  var globalCurrentInstanceSetters;
  var settersKey = "__VUE_INSTANCE_SETTERS__";
  {
    if (!(globalCurrentInstanceSetters = getGlobalThis()[settersKey])) {
      globalCurrentInstanceSetters = getGlobalThis()[settersKey] = [];
    }
    globalCurrentInstanceSetters.push((i) => currentInstance = i);
    internalSetCurrentInstance = (instance) => {
      if (globalCurrentInstanceSetters.length > 1) {
        globalCurrentInstanceSetters.forEach((s) => s(instance));
      } else {
        globalCurrentInstanceSetters[0](instance);
      }
    };
  }
  var setCurrentInstance = (instance) => {
    internalSetCurrentInstance(instance);
    instance.scope.on();
  };
  var unsetCurrentInstance = () => {
    currentInstance && currentInstance.scope.off();
    internalSetCurrentInstance(null);
  };
  function isStatefulComponent(instance) {
    return instance.vnode.shapeFlag & 4;
  }
  var isInSSRComponentSetup = false;
  function getExposeProxy(instance) {
    if (instance.exposed) {
      return instance.exposeProxy || (instance.exposeProxy = new Proxy(proxyRefs(markRaw(instance.exposed)), {
        get(target, key) {
          if (key in target) {
            return target[key];
          } else if (key in publicPropertiesMap) {
            return publicPropertiesMap[key](instance);
          }
        },
        has(target, key) {
          return key in target || key in publicPropertiesMap;
        }
      }));
    }
  }
  var classifyRE = /(?:^|[-_])(\w)/g;
  var classify = (str) => str.replace(classifyRE, (c) => c.toUpperCase()).replace(/[-_]/g, "");
  function getComponentName(Component, includeInferred = true) {
    return isFunction(Component) ? Component.displayName || Component.name : Component.name || includeInferred && Component.__name;
  }
  function formatComponentName(instance, Component, isRoot = false) {
    let name = getComponentName(Component);
    if (!name && Component.__file) {
      const match = Component.__file.match(/([^/\\]+)\.\w+$/);
      if (match) {
        name = match[1];
      }
    }
    if (!name && instance && instance.parent) {
      const inferFromRegistry = (registry) => {
        for (const key in registry) {
          if (registry[key] === Component) {
            return key;
          }
        }
      };
      name = inferFromRegistry(
        instance.components || instance.parent.type.components
      ) || inferFromRegistry(instance.appContext.components);
    }
    return name ? classify(name) : isRoot ? `App` : `Anonymous`;
  }
  function isClassComponent(value) {
    return isFunction(value) && "__vccOpts" in value;
  }
  var computed2 = (getterOrOptions, debugOptions) => {
    return computed(getterOrOptions, debugOptions, isInSSRComponentSetup);
  };
  var ssrContextKey = Symbol.for("v-scx");
  var useSSRContext = () => {
    {
      const ctx = inject(ssrContextKey);
      if (!ctx) {
        warn2(
          `Server rendering context not provided. Make sure to only call useSSRContext() conditionally in the server build.`
        );
      }
      return ctx;
    }
  };
  function isShallow2(value) {
    return !!(value && value["__v_isShallow"]);
  }
  function initCustomFormatter() {
    if (typeof window === "undefined") {
      return;
    }
    const vueStyle = { style: "color:#3ba776" };
    const numberStyle = { style: "color:#0b1bc9" };
    const stringStyle = { style: "color:#b62e24" };
    const keywordStyle = { style: "color:#9d288c" };
    const formatter = {
      header(obj) {
        if (!isObject(obj)) {
          return null;
        }
        if (obj.__isVue) {
          return ["div", vueStyle, `VueInstance`];
        } else if (isRef(obj)) {
          return [
            "div",
            {},
            ["span", vueStyle, genRefFlag(obj)],
            "<",
            formatValue(obj.value),
            `>`
          ];
        } else if (isReactive(obj)) {
          return [
            "div",
            {},
            ["span", vueStyle, isShallow2(obj) ? "ShallowReactive" : "Reactive"],
            "<",
            formatValue(obj),
            `>${isReadonly(obj) ? ` (readonly)` : ``}`
          ];
        } else if (isReadonly(obj)) {
          return [
            "div",
            {},
            ["span", vueStyle, isShallow2(obj) ? "ShallowReadonly" : "Readonly"],
            "<",
            formatValue(obj),
            ">"
          ];
        }
        return null;
      },
      hasBody(obj) {
        return obj && obj.__isVue;
      },
      body(obj) {
        if (obj && obj.__isVue) {
          return [
            "div",
            {},
            ...formatInstance(obj.$)
          ];
        }
      }
    };
    function formatInstance(instance) {
      const blocks = [];
      if (instance.type.props && instance.props) {
        blocks.push(createInstanceBlock("props", toRaw(instance.props)));
      }
      if (instance.setupState !== EMPTY_OBJ) {
        blocks.push(createInstanceBlock("setup", instance.setupState));
      }
      if (instance.data !== EMPTY_OBJ) {
        blocks.push(createInstanceBlock("data", toRaw(instance.data)));
      }
      const computed3 = extractKeys(instance, "computed");
      if (computed3) {
        blocks.push(createInstanceBlock("computed", computed3));
      }
      const injected = extractKeys(instance, "inject");
      if (injected) {
        blocks.push(createInstanceBlock("injected", injected));
      }
      blocks.push([
        "div",
        {},
        [
          "span",
          {
            style: keywordStyle.style + ";opacity:0.66"
          },
          "$ (internal): "
        ],
        ["object", { object: instance }]
      ]);
      return blocks;
    }
    function createInstanceBlock(type, target) {
      target = extend({}, target);
      if (!Object.keys(target).length) {
        return ["span", {}];
      }
      return [
        "div",
        { style: "line-height:1.25em;margin-bottom:0.6em" },
        [
          "div",
          {
            style: "color:#476582"
          },
          type
        ],
        [
          "div",
          {
            style: "padding-left:1.25em"
          },
          ...Object.keys(target).map((key) => {
            return [
              "div",
              {},
              ["span", keywordStyle, key + ": "],
              formatValue(target[key], false)
            ];
          })
        ]
      ];
    }
    function formatValue(v, asRaw = true) {
      if (typeof v === "number") {
        return ["span", numberStyle, v];
      } else if (typeof v === "string") {
        return ["span", stringStyle, JSON.stringify(v)];
      } else if (typeof v === "boolean") {
        return ["span", keywordStyle, v];
      } else if (isObject(v)) {
        return ["object", { object: asRaw ? toRaw(v) : v }];
      } else {
        return ["span", stringStyle, String(v)];
      }
    }
    function extractKeys(instance, type) {
      const Comp = instance.type;
      if (isFunction(Comp)) {
        return;
      }
      const extracted = {};
      for (const key in instance.ctx) {
        if (isKeyOfType(Comp, key, type)) {
          extracted[key] = instance.ctx[key];
        }
      }
      return extracted;
    }
    function isKeyOfType(Comp, key, type) {
      const opts = Comp[type];
      if (isArray(opts) && opts.includes(key) || isObject(opts) && key in opts) {
        return true;
      }
      if (Comp.extends && isKeyOfType(Comp.extends, key, type)) {
        return true;
      }
      if (Comp.mixins && Comp.mixins.some((m) => isKeyOfType(m, key, type))) {
        return true;
      }
    }
    function genRefFlag(v) {
      if (isShallow2(v)) {
        return `ShallowRef`;
      }
      if (v.effect) {
        return `ComputedRef`;
      }
      return `Ref`;
    }
    if (window.devtoolsFormatters) {
      window.devtoolsFormatters.push(formatter);
    } else {
      window.devtoolsFormatters = [formatter];
    }
  }

  // node_modules/vue/dist/vue.runtime.esm-bundler.js
  function initDev() {
    {
      initCustomFormatter();
    }
  }
  if (true) {
    initDev();
  }

  // node_modules/@vueuse/shared/index.mjs
  function toValue2(r) {
    return typeof r === "function" ? r() : unref(r);
  }
  var isClient = typeof window !== "undefined" && typeof document !== "undefined";
  var timestamp = () => +Date.now();
  var noop = () => {
  };
  function createFilterWrapper(filter, fn) {
    function wrapper(...args) {
      return new Promise((resolve, reject) => {
        Promise.resolve(filter(() => fn.apply(this, args), { fn, thisArg: this, args })).then(resolve).catch(reject);
      });
    }
    return wrapper;
  }
  var bypassFilter = (invoke) => {
    return invoke();
  };
  function throttleFilter(ms, trailing = true, leading = true, rejectOnCancel = false) {
    let lastExec = 0;
    let timer;
    let isLeading = true;
    let lastRejector = noop;
    let lastValue;
    const clear2 = () => {
      if (timer) {
        clearTimeout(timer);
        timer = void 0;
        lastRejector();
        lastRejector = noop;
      }
    };
    const filter = (_invoke) => {
      const duration = toValue2(ms);
      const elapsed = Date.now() - lastExec;
      const invoke = () => {
        return lastValue = _invoke();
      };
      clear2();
      if (duration <= 0) {
        lastExec = Date.now();
        return invoke();
      }
      if (elapsed > duration && (leading || !isLeading)) {
        lastExec = Date.now();
        invoke();
      } else if (trailing) {
        lastValue = new Promise((resolve, reject) => {
          lastRejector = rejectOnCancel ? reject : resolve;
          timer = setTimeout(() => {
            lastExec = Date.now();
            isLeading = true;
            resolve(invoke());
            clear2();
          }, Math.max(0, duration - elapsed));
        });
      }
      if (!leading && !timer)
        timer = setTimeout(() => isLeading = true, duration);
      isLeading = false;
      return lastValue;
    };
    return filter;
  }
  function pausableFilter(extendFilter = bypassFilter) {
    const isActive = ref(true);
    function pause() {
      isActive.value = false;
    }
    function resume() {
      isActive.value = true;
    }
    const eventFilter = (...args) => {
      if (isActive.value)
        extendFilter(...args);
    };
    return { isActive: readonly(isActive), pause, resume, eventFilter };
  }
  function cacheStringFunction2(fn) {
    const cache = /* @__PURE__ */ Object.create(null);
    return (str) => {
      const hit = cache[str];
      return hit || (cache[str] = fn(str));
    };
  }
  var hyphenateRE2 = /\B([A-Z])/g;
  var hyphenate2 = cacheStringFunction2((str) => str.replace(hyphenateRE2, "-$1").toLowerCase());
  var camelizeRE2 = /-(\w)/g;
  var camelize2 = cacheStringFunction2((str) => {
    return str.replace(camelizeRE2, (_, c) => c ? c.toUpperCase() : "");
  });
  function watchWithFilter(source, cb, options = {}) {
    const {
      eventFilter = bypassFilter,
      ...watchOptions
    } = options;
    return watch(
      source,
      createFilterWrapper(
        eventFilter,
        cb
      ),
      watchOptions
    );
  }
  function watchIgnorable(source, cb, options = {}) {
    const {
      eventFilter = bypassFilter,
      ...watchOptions
    } = options;
    const filteredCb = createFilterWrapper(
      eventFilter,
      cb
    );
    let ignoreUpdates;
    let ignorePrevAsyncUpdates;
    let stop2;
    if (watchOptions.flush === "sync") {
      const ignore = ref(false);
      ignorePrevAsyncUpdates = () => {
      };
      ignoreUpdates = (updater) => {
        ignore.value = true;
        updater();
        ignore.value = false;
      };
      stop2 = watch(
        source,
        (...args) => {
          if (!ignore.value)
            filteredCb(...args);
        },
        watchOptions
      );
    } else {
      const disposables = [];
      const ignoreCounter = ref(0);
      const syncCounter = ref(0);
      ignorePrevAsyncUpdates = () => {
        ignoreCounter.value = syncCounter.value;
      };
      disposables.push(
        watch(
          source,
          () => {
            syncCounter.value++;
          },
          { ...watchOptions, flush: "sync" }
        )
      );
      ignoreUpdates = (updater) => {
        const syncCounterPrev = syncCounter.value;
        updater();
        ignoreCounter.value += syncCounter.value - syncCounterPrev;
      };
      disposables.push(
        watch(
          source,
          (...args) => {
            const ignore = ignoreCounter.value > 0 && ignoreCounter.value === syncCounter.value;
            ignoreCounter.value = 0;
            syncCounter.value = 0;
            if (ignore)
              return;
            filteredCb(...args);
          },
          watchOptions
        )
      );
      stop2 = () => {
        disposables.forEach((fn) => fn());
      };
    }
    return { stop: stop2, ignoreUpdates, ignorePrevAsyncUpdates };
  }
  function watchThrottled(source, cb, options = {}) {
    const {
      throttle = 0,
      trailing = true,
      leading = true,
      ...watchOptions
    } = options;
    return watchWithFilter(
      source,
      cb,
      {
        ...watchOptions,
        eventFilter: throttleFilter(throttle, trailing, leading)
      }
    );
  }
  function whenever(source, cb, options) {
    return watch(
      source,
      (v, ov, onInvalidate) => {
        if (v)
          cb(v, ov, onInvalidate);
      },
      options
    );
  }

  // node_modules/@vueuse/core/index.mjs
  var defaultDocument = isClient ? window.document : void 0;
  var defaultNavigator = isClient ? window.navigator : void 0;
  var defaultLocation = isClient ? window.location : void 0;
  function cloneFnJSON(source) {
    return JSON.parse(JSON.stringify(source));
  }
  function fnBypass(v) {
    return v;
  }
  function fnSetSource(source, value) {
    return source.value = value;
  }
  function defaultDump(clone) {
    return clone ? typeof clone === "function" ? clone : cloneFnJSON : fnBypass;
  }
  function defaultParse(clone) {
    return clone ? typeof clone === "function" ? clone : cloneFnJSON : fnBypass;
  }
  function useManualRefHistory(source, options = {}) {
    const {
      clone = false,
      dump = defaultDump(clone),
      parse = defaultParse(clone),
      setSource = fnSetSource
    } = options;
    function _createHistoryRecord() {
      return markRaw({
        snapshot: dump(source.value),
        timestamp: timestamp()
      });
    }
    const last = ref(_createHistoryRecord());
    const undoStack = ref([]);
    const redoStack = ref([]);
    const _setSource = (record) => {
      setSource(source, parse(record.snapshot));
      last.value = record;
    };
    const commit = () => {
      undoStack.value.unshift(last.value);
      last.value = _createHistoryRecord();
      if (options.capacity && undoStack.value.length > options.capacity)
        undoStack.value.splice(options.capacity, Number.POSITIVE_INFINITY);
      if (redoStack.value.length)
        redoStack.value.splice(0, redoStack.value.length);
    };
    const clear2 = () => {
      undoStack.value.splice(0, undoStack.value.length);
      redoStack.value.splice(0, redoStack.value.length);
    };
    const undo = () => {
      const state = undoStack.value.shift();
      if (state) {
        redoStack.value.unshift(last.value);
        _setSource(state);
      }
    };
    const redo = () => {
      const state = redoStack.value.shift();
      if (state) {
        undoStack.value.unshift(last.value);
        _setSource(state);
      }
    };
    const reset = () => {
      _setSource(last.value);
    };
    const history = computed2(() => [last.value, ...undoStack.value]);
    const canUndo = computed2(() => undoStack.value.length > 0);
    const canRedo = computed2(() => redoStack.value.length > 0);
    return {
      source,
      undoStack,
      redoStack,
      last,
      history,
      canUndo,
      canRedo,
      clear: clear2,
      commit,
      reset,
      undo,
      redo
    };
  }
  function useRefHistory(source, options = {}) {
    const {
      deep = false,
      flush = "pre",
      eventFilter
    } = options;
    const {
      eventFilter: composedFilter,
      pause,
      resume: resumeTracking,
      isActive: isTracking
    } = pausableFilter(eventFilter);
    const {
      ignoreUpdates,
      ignorePrevAsyncUpdates,
      stop: stop2
    } = watchIgnorable(
      source,
      commit,
      { deep, flush, eventFilter: composedFilter }
    );
    function setSource(source2, value) {
      ignorePrevAsyncUpdates();
      ignoreUpdates(() => {
        source2.value = value;
      });
    }
    const manualHistory = useManualRefHistory(source, { ...options, clone: options.clone || deep, setSource });
    const { clear: clear2, commit: manualCommit } = manualHistory;
    function commit() {
      ignorePrevAsyncUpdates();
      manualCommit();
    }
    function resume(commitNow) {
      resumeTracking();
      if (commitNow)
        commit();
    }
    function batch(fn) {
      let canceled = false;
      const cancel = () => canceled = true;
      ignoreUpdates(() => {
        fn(cancel);
      });
      if (!canceled)
        commit();
    }
    function dispose() {
      stop2();
      clear2();
    }
    return {
      ...manualHistory,
      isTracking,
      pause,
      resume,
      commit,
      batch,
      dispose
    };
  }
  var DEFAULT_UNITS = [
    { max: 6e4, value: 1e3, name: "second" },
    { max: 276e4, value: 6e4, name: "minute" },
    { max: 72e6, value: 36e5, name: "hour" },
    { max: 5184e5, value: 864e5, name: "day" },
    { max: 24192e5, value: 6048e5, name: "week" },
    { max: 28512e6, value: 2592e6, name: "month" },
    { max: Number.POSITIVE_INFINITY, value: 31536e6, name: "year" }
  ];

  // src/composables/chrome/windows.ts
  function _useReadonlyChromeWindows() {
    const windows = ref([]);
    const loaded = ref(false);
    const lastCreated = ref(void 0);
    const lastRemoved = ref(void 0);
    if (typeof chrome.windows !== "undefined") {
      chrome.windows.getAll().then((queriedWindows) => {
        windows.value = queriedWindows.filter((window2) => window2.type === "normal");
        loaded.value = true;
        chrome.windows.onCreated.addListener((createdWindow) => {
          if (createdWindow.type !== "normal")
            return;
          lastCreated.value = createdWindow;
          windows.value = [...windows.value, createdWindow];
        });
        chrome.windows.onRemoved.addListener((removedWindowId) => {
          lastRemoved.value = removedWindowId;
          windows.value = windows.value.filter(
            (window2) => window2.id !== removedWindowId
          );
        });
      });
    } else {
      loaded.value = true;
    }
    return {
      items: readonly(windows),
      loaded: readonly(loaded),
      lastCreated: readonly(lastCreated),
      lastRemoved: readonly(lastRemoved)
    };
  }
  var readonlyChromeWindows;
  function useReadonlyChromeWindows() {
    if (!readonlyChromeWindows) {
      readonlyChromeWindows = _useReadonlyChromeWindows();
    }
    return readonlyChromeWindows;
  }

  // src/composables/chrome/util.ts
  var ignoreChromeRuntimeEvents = ref(false);

  // src/composables/chrome/tabs.ts
  function _useReadonlyChromeTabs() {
    const tabs = ref([]);
    const detachedTabs = ref([]);
    const loaded = ref(false);
    const lastCreated = ref(void 0);
    const lastUpdated = ref(void 0);
    const lastRemoved = ref(void 0);
    if (typeof chrome.tabs !== "undefined") {
      const chromeWindows = useReadonlyChromeWindows();
      whenever(chromeWindows.loaded, async () => {
        const queriedTabs = await Promise.all(
          chromeWindows.items.value.map(
            (window2) => chrome.tabs.query({ windowId: window2.id })
          )
        );
        tabs.value = queriedTabs.flat();
        loaded.value = true;
        chrome.tabs.onCreated.addListener((createdTab) => {
          if (ignoreChromeRuntimeEvents.value) {
            return;
          }
          lastCreated.value = createdTab;
          tabs.value = [...tabs.value, createdTab];
        });
        chrome.tabs.onRemoved.addListener((removedTabId) => {
          if (ignoreChromeRuntimeEvents.value) {
            return;
          }
          lastRemoved.value = removedTabId;
          tabs.value = tabs.value.filter((tab) => tab.id !== removedTabId);
        });
        chrome.tabs.onDetached.addListener((removedTabId) => {
          if (ignoreChromeRuntimeEvents.value) {
            return;
          }
          detachedTabs.value = [...detachedTabs.value, removedTabId];
        });
        chrome.tabs.onAttached.addListener(async (attachedTabId) => {
          if (ignoreChromeRuntimeEvents.value) {
            return;
          }
          detachedTabs.value = detachedTabs.value.filter(
            (tabId) => tabId !== attachedTabId
          );
        });
        chrome.tabs.onUpdated.addListener((tabId, changeInfo, updatedTab) => {
          if (ignoreChromeRuntimeEvents.value) {
            return;
          }
          lastUpdated.value = {
            changes: changeInfo,
            tab: updatedTab,
            oldTab: tabs.value.find((tab) => tab.id === tabId)
          };
          const index = tabs.value.findIndex((tab) => tab.id === updatedTab.id);
          tabs.value = [
            ...tabs.value.slice(0, index),
            updatedTab,
            ...tabs.value.slice(index + 1)
          ];
        });
      });
    } else {
      loaded.value = true;
    }
    return {
      items: readonly(tabs),
      detachedTabs: readonly(detachedTabs),
      loaded: readonly(loaded),
      lastCreated: readonly(lastCreated),
      lastUpdated: readonly(lastUpdated),
      lastRemoved: readonly(lastRemoved)
    };
  }
  var readonlyChromeTabs;
  function useReadonlyChromeTabs() {
    if (!readonlyChromeTabs) {
      readonlyChromeTabs = _useReadonlyChromeTabs();
    }
    return readonlyChromeTabs;
  }
  function useChromeTabsById() {
    const chromeTabs = useReadonlyChromeTabs();
    return computed2(() => Object.fromEntries(chromeTabs.items.value.map((tab) => [tab.id, tab])));
  }
  function useChromeTabsByWindowId() {
    const chromeTabs = useReadonlyChromeTabs();
    const chromeWindows = useReadonlyChromeWindows();
    return computed2(
      () => Object.fromEntries(
        chromeWindows.items.value.map((window2) => [
          window2.id,
          chromeTabs.items.value.filter((tab) => tab.windowId === window2.id)
        ])
      )
    );
  }

  // src/composables/chrome/tab-groups.ts
  function _useReadonlyChromeTabGroups() {
    const tabGroups = ref([]);
    const loaded = ref(false);
    const lastCreated = ref(void 0);
    const lastUpdated = ref(void 0);
    const lastRemoved = ref(void 0);
    if (typeof chrome.tabGroups !== "undefined") {
      const chromeWindows = useReadonlyChromeWindows();
      whenever(chromeWindows.loaded, async () => {
        const queriedTabGroups = await Promise.all(
          chromeWindows.items.value.map(
            (window2) => chrome.tabGroups.query({ windowId: window2.id })
          )
        );
        tabGroups.value = queriedTabGroups.flat();
        loaded.value = true;
        chrome.tabGroups.onCreated.addListener((createdTabGroup) => {
          if (ignoreChromeRuntimeEvents.value) {
            return;
          }
          lastCreated.value = createdTabGroup;
          tabGroups.value = [...tabGroups.value, createdTabGroup];
        });
        chrome.tabGroups.onRemoved.addListener((removedTabGroup) => {
          if (ignoreChromeRuntimeEvents.value) {
            return;
          }
          lastRemoved.value = removedTabGroup;
          tabGroups.value = tabGroups.value.filter(
            (Tab) => Tab.id !== removedTabGroup.id
          );
        });
        chrome.tabGroups.onUpdated.addListener((updatedTabGroup) => {
          if (ignoreChromeRuntimeEvents.value) {
            return;
          }
          lastUpdated.value = updatedTabGroup;
          const index = tabGroups.value.findIndex(
            (tabGroup) => tabGroup.id === updatedTabGroup.id
          );
          tabGroups.value = [
            ...tabGroups.value.slice(0, index),
            updatedTabGroup,
            ...tabGroups.value.slice(index + 1)
          ];
        });
      });
    } else {
      loaded.value = true;
    }
    return {
      items: readonly(tabGroups),
      loaded: readonly(loaded),
      lastCreated: readonly(lastCreated),
      lastUpdated: readonly(lastUpdated),
      lastRemoved: readonly(lastRemoved)
    };
  }
  var readonlyChromeTabGroups;
  function useReadonlyChromeTabGroups() {
    if (!readonlyChromeTabGroups) {
      readonlyChromeTabGroups = _useReadonlyChromeTabGroups();
    }
    return readonlyChromeTabGroups;
  }
  function useChromeTabGroupsByWindowId() {
    const chromeWindows = useReadonlyChromeWindows();
    const chromeTabGroups = useReadonlyChromeTabGroups();
    return computed2(
      () => Object.fromEntries(
        chromeWindows.items.value.map((window2) => [
          window2.id,
          chromeTabGroups.items.value.filter(
            (tabGroup) => tabGroup.windowId === window2.id
          )
        ])
      )
    );
  }

  // src/util/storage.ts
  async function readStorage(key, storage) {
    if (typeof chrome.storage === "undefined") {
      const result = window.localStorage.getItem(key);
      return result ? JSON.parse(result) : void 0;
    } else {
      return (await chrome.storage[storage].get([key]))?.[key];
    }
  }
  function watchStorage(key, callback, storage = "sync") {
    if (typeof chrome.storage === "undefined") {
      const handler = (event) => {
        if (event.storageArea !== window.localStorage)
          return;
        if (event.key !== key)
          return;
        if (event.oldValue === event.newValue)
          return;
        const oldValue = event.oldValue ? JSON.parse(event.oldValue) : void 0;
        const newValue = event.newValue ? JSON.parse(event.newValue) : void 0;
        callback(newValue, oldValue);
      };
      window.addEventListener("storage", handler);
      return () => window.removeEventListener("storage", handler);
    } else {
      const handler = (changes, area) => {
        if (area !== storage || !(key in changes))
          return;
        const { newValue, oldValue } = changes[key];
        if (JSON.stringify(newValue) === JSON.stringify(oldValue))
          return;
        callback(newValue, oldValue);
      };
      chrome.storage.onChanged.addListener(handler);
      return () => chrome.storage.onChanged.removeListener(handler);
    }
  }
  async function writeStorage(key, value, storage = "sync") {
    return await new Promise((resolve) => {
      if (typeof chrome.storage === "undefined") {
        const oldValue = window.localStorage.getItem(key);
        const newValue = JSON.stringify(value);
        window.localStorage.setItem(key, newValue);
        window.dispatchEvent(
          new StorageEvent("storage", {
            key,
            newValue,
            oldValue,
            storageArea: window.localStorage,
            url: window.location.href
          })
        );
        resolve();
      } else {
        chrome.storage[storage].set({ [key]: value }, () => resolve());
      }
    });
  }

  // src/composables/chrome/storage.ts
  var storageHandles = {
    sync: /* @__PURE__ */ new Map(),
    local: /* @__PURE__ */ new Map(),
    managed: /* @__PURE__ */ new Map(),
    session: /* @__PURE__ */ new Map()
  };
  function useStorage(key, fallback, {
    storage = "sync",
    throttle = 0,
    loadMapper,
    saveMapper
  } = {}) {
    const storageHandle = storageHandles[storage];
    if (!storageHandle.has(key)) {
      const loaded = ref(false);
      const data = ref(fallback);
      const changedFromStorage = tickResetRef(false);
      readStorage(key, storage).then((value) => {
        loaded.value = true;
        if (typeof loadMapper === "function") {
          value = loadMapper(value);
        }
        if (typeof value !== "undefined") {
          changedFromStorage.value = true;
          data.value = value;
        }
        watchStorage(
          key,
          (newValue) => {
            if (ignoreChromeRuntimeEvents.value) {
              return;
            }
            changedFromStorage.value = true;
            if (typeof loadMapper === "function") {
              newValue = loadMapper(newValue);
            }
            data.value = newValue;
          },
          storage
        );
      });
      const watcher = (newValue) => {
        if (changedFromStorage.value)
          return;
        newValue = toRawDeep(newValue);
        if (typeof saveMapper === "function") {
          newValue = saveMapper(newValue);
        }
        writeStorage(key, newValue, storage);
      };
      if (throttle > 0) {
        watchThrottled(data, watcher, { deep: true, throttle });
      } else {
        watch(data, watcher, { deep: true });
      }
      storageHandle.set(key, { loaded, data });
    }
    return storageHandle.get(key);
  }

  // src/composables/chrome/state.ts
  function useChromeState() {
    const windows = useReadonlyChromeWindows();
    const tabs = useReadonlyChromeTabs();
    const tabGroups = useReadonlyChromeTabGroups();
    const loaded = computed2(
      () => windows.loaded.value && tabs.loaded.value && tabGroups.loaded.value
    );
    return {
      loaded,
      windows,
      tabs,
      tabGroups,
      tabsById: useChromeTabsById(),
      tabsByWindowId: useChromeTabsByWindowId(),
      tabGroupsByWindowId: useChromeTabGroupsByWindowId()
    };
  }

  // src/composables/meta.ts
  function tickResetRef(initialValue) {
    const value = ref(initialValue);
    return computed2({
      get: () => value.value,
      set: (newValue) => {
        value.value = newValue;
        nextTick(() => {
          value.value = initialValue;
        });
      }
    });
  }
  function toRawDeep(value) {
    const rawValue = toRaw(value);
    if (typeof rawValue !== "object" || rawValue === null)
      return rawValue;
    if (Array.isArray(rawValue)) {
      return rawValue.map(toRawDeep);
    } else {
      return Object.fromEntries(
        Object.entries(rawValue).map(([key, value2]) => [
          key,
          toRawDeep(value2)
        ])
      );
    }
  }

  // src/util/base64.ts
  function b64ToUint6(nChr) {
    return nChr > 64 && nChr < 91 ? nChr - 65 : nChr > 96 && nChr < 123 ? nChr - 71 : nChr > 47 && nChr < 58 ? nChr + 4 : nChr === 43 ? 62 : nChr === 47 ? 63 : 0;
  }
  function decodeToArray(base64string, blockSize) {
    var sB64Enc = base64string.replace(/[^A-Za-z0-9\+\/]/g, ""), nInLen = sB64Enc.length, nOutLen = blockSize ? Math.ceil((nInLen * 3 + 1 >>> 2) / blockSize) * blockSize : nInLen * 3 + 1 >>> 2, aBytes = new Uint8Array(nOutLen);
    for (var nMod3, nMod4, nUint24 = 0, nOutIdx = 0, nInIdx = 0; nInIdx < nInLen; nInIdx++) {
      nMod4 = nInIdx & 3;
      nUint24 |= b64ToUint6(sB64Enc.charCodeAt(nInIdx)) << 18 - 6 * nMod4;
      if (nMod4 === 3 || nInLen - nInIdx === 1) {
        for (nMod3 = 0; nMod3 < 3 && nOutIdx < nOutLen; nMod3++, nOutIdx++) {
          aBytes[nOutIdx] = nUint24 >>> (16 >>> nMod3 & 24) & 255;
        }
        nUint24 = 0;
      }
    }
    return aBytes;
  }
  function uint6ToB64(nUint6) {
    return nUint6 < 26 ? nUint6 + 65 : nUint6 < 52 ? nUint6 + 71 : nUint6 < 62 ? nUint6 - 4 : nUint6 === 62 ? 43 : nUint6 === 63 ? 47 : 65;
  }
  function encodeFromArray(bytes) {
    var eqLen = (3 - bytes.length % 3) % 3, sB64Enc = "";
    for (var nMod3, nLen = bytes.length, nUint24 = 0, nIdx = 0; nIdx < nLen; nIdx++) {
      nMod3 = nIdx % 3;
      nUint24 |= bytes[nIdx] << (16 >>> nMod3 & 24);
      if (nMod3 === 2 || bytes.length - nIdx === 1) {
        sB64Enc += String.fromCharCode(
          uint6ToB64(nUint24 >>> 18 & 63),
          uint6ToB64(nUint24 >>> 12 & 63),
          uint6ToB64(nUint24 >>> 6 & 63),
          uint6ToB64(nUint24 & 63)
        );
        nUint24 = 0;
      }
    }
    return eqLen === 0 ? sB64Enc : sB64Enc.substring(0, sB64Enc.length - eqLen) + (eqLen === 1 ? "=" : "==");
  }

  // src/util/lzma.js
  var __4294967296 = 4294967296;
  var N1_longLit = [4294967295, -__4294967296];
  var MIN_VALUE = [0, -9223372036854776e3];
  var P0_longLit = [0, 0];
  var P1_longLit = [1, 0];
  function add2(a, b) {
    return create(a[0] + b[0], a[1] + b[1]);
  }
  function initDim(len) {
    var a = [];
    a[len - 1] = void 0;
    return a;
  }
  function and(a, b) {
    return makeFromBits(
      ~~Math.max(Math.min(a[1] / __4294967296, 2147483647), -2147483648) & ~~Math.max(Math.min(b[1] / __4294967296, 2147483647), -2147483648),
      lowBits_0(a) & lowBits_0(b)
    );
  }
  function compare(a, b) {
    var nega, negb;
    if (a[0] == b[0] && a[1] == b[1]) {
      return 0;
    }
    nega = a[1] < 0;
    negb = b[1] < 0;
    if (nega && !negb) {
      return -1;
    }
    if (!nega && negb) {
      return 1;
    }
    if (sub(a, b)[1] < 0) {
      return -1;
    }
    return 1;
  }
  function create(valueLow, valueHigh) {
    var diffHigh, diffLow;
    valueHigh %= 18446744073709552e3;
    valueLow %= 18446744073709552e3;
    diffHigh = valueHigh % __4294967296;
    diffLow = Math.floor(valueLow / __4294967296) * __4294967296;
    valueHigh = valueHigh - diffHigh + diffLow;
    valueLow = valueLow - diffLow + diffHigh;
    while (valueLow < 0) {
      valueLow += __4294967296;
      valueHigh -= __4294967296;
    }
    while (valueLow > 4294967295) {
      valueLow -= __4294967296;
      valueHigh += __4294967296;
    }
    valueHigh = valueHigh % 18446744073709552e3;
    while (valueHigh > 9223372032559809e3) {
      valueHigh -= 18446744073709552e3;
    }
    while (valueHigh < -9223372036854776e3) {
      valueHigh += 18446744073709552e3;
    }
    return [valueLow, valueHigh];
  }
  function eq(a, b) {
    return a[0] == b[0] && a[1] == b[1];
  }
  function fromInt(value) {
    if (value >= 0) {
      return [value, 0];
    } else {
      return [value + __4294967296, -__4294967296];
    }
  }
  function lowBits_0(a) {
    if (a[0] >= 2147483648) {
      return ~~Math.max(Math.min(a[0] - __4294967296, 2147483647), -2147483648);
    } else {
      return ~~Math.max(Math.min(a[0], 2147483647), -2147483648);
    }
  }
  function makeFromBits(highBits, lowBits) {
    var high, low;
    high = highBits * __4294967296;
    low = lowBits;
    if (lowBits < 0) {
      low += __4294967296;
    }
    return [low, high];
  }
  function pwrAsDouble(n) {
    if (n <= 30) {
      return 1 << n;
    } else {
      return pwrAsDouble(30) * pwrAsDouble(n - 30);
    }
  }
  function shl(a, n) {
    var diff, newHigh, newLow, twoToN;
    n &= 63;
    if (eq(a, MIN_VALUE)) {
      if (!n) {
        return a;
      }
      return P0_longLit;
    }
    if (a[1] < 0) {
      throw new Error("Neg");
    }
    twoToN = pwrAsDouble(n);
    newHigh = a[1] * twoToN % 18446744073709552e3;
    newLow = a[0] * twoToN;
    diff = newLow - newLow % __4294967296;
    newHigh += diff;
    newLow -= diff;
    if (newHigh >= 9223372036854776e3) {
      newHigh -= 18446744073709552e3;
    }
    return [newLow, newHigh];
  }
  function shr(a, n) {
    var shiftFact;
    n &= 63;
    shiftFact = pwrAsDouble(n);
    return create(Math.floor(a[0] / shiftFact), a[1] / shiftFact);
  }
  function shru(a, n) {
    var sr;
    n &= 63;
    sr = shr(a, n);
    if (a[1] < 0) {
      sr = add2(sr, shl([2, 0], 63 - n));
    }
    return sr;
  }
  function sub(a, b) {
    return create(a[0] - b[0], a[1] - b[1]);
  }
  function $ByteArrayInputStream(this$static, buf) {
    this$static.buf = buf;
    this$static.pos = 0;
    this$static.count = buf.length;
    return this$static;
  }
  function $read(this$static) {
    if (this$static.pos >= this$static.count)
      return -1;
    return this$static.buf[this$static.pos++] & 255;
  }
  function $read_0(this$static, buf, off, len) {
    if (this$static.pos >= this$static.count)
      return -1;
    len = Math.min(len, this$static.count - this$static.pos);
    arraycopy(this$static.buf, this$static.pos, buf, off, len);
    this$static.pos += len;
    return len;
  }
  function $ByteArrayOutputStream(this$static) {
    this$static.buf = initDim(32);
    this$static.count = 0;
    return this$static;
  }
  function $toByteArray(this$static) {
    var data = this$static.buf;
    data.length = this$static.count;
    return data;
  }
  function $write(this$static, b) {
    this$static.buf[this$static.count++] = b << 24 >> 24;
  }
  function $write_0(this$static, buf, off, len) {
    arraycopy(buf, off, this$static.buf, this$static.count, len);
    this$static.count += len;
  }
  function $getChars(this$static, srcBegin, srcEnd, dst, dstBegin) {
    var srcIdx;
    for (srcIdx = srcBegin; srcIdx < srcEnd; ++srcIdx) {
      dst[dstBegin++] = this$static.charCodeAt(srcIdx);
    }
  }
  function arraycopy(src, srcOfs, dest, destOfs, len) {
    for (var i = 0; i < len; ++i) {
      dest[destOfs + i] = src[srcOfs + i];
    }
  }
  function $configure(this$static, encoder) {
    $SetDictionarySize_0(encoder, 1 << this$static.s);
    encoder._numFastBytes = this$static.f;
    $SetMatchFinder(encoder, this$static.m);
    encoder._numLiteralPosStateBits = 0;
    encoder._numLiteralContextBits = 3;
    encoder._posStateBits = 2;
    encoder._posStateMask = 3;
  }
  function $init(this$static, input, output, length_0, mode, enableEndMark) {
    var encoder, i;
    if (compare(length_0, N1_longLit) < 0)
      throw new Error("invalid length " + length_0);
    this$static.length_0 = length_0;
    encoder = $Encoder({});
    $configure(mode, encoder);
    encoder._writeEndMark = enableEndMark;
    $WriteCoderProperties(encoder, output);
    for (i = 0; i < 64; i += 8)
      $write(output, lowBits_0(shr(length_0, i)) & 255);
    this$static.chunker = (encoder._needReleaseMFStream = 0, encoder._inStream = input, encoder._finished = 0, $Create_2(encoder), encoder._rangeEncoder.Stream = output, $Init_4(encoder), $FillDistancesPrices(encoder), $FillAlignPrices(encoder), encoder._lenEncoder._tableSize = encoder._numFastBytes + 1 - 2, $UpdateTables(encoder._lenEncoder, 1 << encoder._posStateBits), encoder._repMatchLenEncoder._tableSize = encoder._numFastBytes + 1 - 2, $UpdateTables(encoder._repMatchLenEncoder, 1 << encoder._posStateBits), encoder.nowPos64 = P0_longLit, void 0, $Chunker_0({}, encoder));
  }
  function $LZMAByteArrayCompressor(this$static, data, mode, enableEndMark) {
    this$static.output = $ByteArrayOutputStream({});
    $init(
      this$static,
      $ByteArrayInputStream({}, data),
      this$static.output,
      fromInt(data.length),
      mode,
      enableEndMark
    );
    return this$static;
  }
  function $init_0(this$static, input, output) {
    var decoder, hex_length = "", i, properties = [], r, tmp_length;
    for (i = 0; i < 5; ++i) {
      r = $read(input);
      if (r == -1)
        throw new Error("truncated input");
      properties[i] = r << 24 >> 24;
    }
    decoder = $Decoder({});
    if (!$SetDecoderProperties(decoder, properties)) {
      throw new Error("corrupted input");
    }
    for (i = 0; i < 64; i += 8) {
      r = $read(input);
      if (r == -1)
        throw new Error("truncated input");
      r = r.toString(16);
      if (r.length == 1)
        r = "0" + r;
      hex_length = r + "" + hex_length;
    }
    if (/^0+$|^f+$/i.test(hex_length)) {
      this$static.length_0 = N1_longLit;
    } else {
      tmp_length = parseInt(hex_length, 16);
      if (tmp_length > 4294967295) {
        this$static.length_0 = N1_longLit;
      } else {
        this$static.length_0 = fromInt(tmp_length);
      }
    }
    this$static.chunker = $CodeInChunks(
      decoder,
      input,
      output,
      this$static.length_0
    );
  }
  function $LZMAByteArrayDecompressor(this$static, data) {
    this$static.output = $ByteArrayOutputStream({});
    $init_0(this$static, $ByteArrayInputStream({}, data), this$static.output);
    return this$static;
  }
  function $Create_4(this$static, keepSizeBefore, keepSizeAfter, keepSizeReserv) {
    var blockSize;
    this$static._keepSizeBefore = keepSizeBefore;
    this$static._keepSizeAfter = keepSizeAfter;
    blockSize = keepSizeBefore + keepSizeAfter + keepSizeReserv;
    if (this$static._bufferBase == null || this$static._blockSize != blockSize) {
      this$static._bufferBase = null;
      this$static._blockSize = blockSize;
      this$static._bufferBase = initDim(this$static._blockSize);
    }
    this$static._pointerToLastSafePosition = this$static._blockSize - keepSizeAfter;
  }
  function $GetIndexByte(this$static, index) {
    return this$static._bufferBase[this$static._bufferOffset + this$static._pos + index];
  }
  function $GetMatchLen(this$static, index, distance, limit) {
    var i, pby;
    if (this$static._streamEndWasReached) {
      if (this$static._pos + index + limit > this$static._streamPos) {
        limit = this$static._streamPos - (this$static._pos + index);
      }
    }
    ++distance;
    pby = this$static._bufferOffset + this$static._pos + index;
    for (i = 0; i < limit && this$static._bufferBase[pby + i] == this$static._bufferBase[pby + i - distance]; ++i) {
    }
    return i;
  }
  function $GetNumAvailableBytes(this$static) {
    return this$static._streamPos - this$static._pos;
  }
  function $MoveBlock(this$static) {
    var i, numBytes, offset;
    offset = this$static._bufferOffset + this$static._pos - this$static._keepSizeBefore;
    if (offset > 0) {
      --offset;
    }
    numBytes = this$static._bufferOffset + this$static._streamPos - offset;
    for (i = 0; i < numBytes; ++i) {
      this$static._bufferBase[i] = this$static._bufferBase[offset + i];
    }
    this$static._bufferOffset -= offset;
  }
  function $MovePos_1(this$static) {
    var pointerToPostion;
    ++this$static._pos;
    if (this$static._pos > this$static._posLimit) {
      pointerToPostion = this$static._bufferOffset + this$static._pos;
      if (pointerToPostion > this$static._pointerToLastSafePosition) {
        $MoveBlock(this$static);
      }
      $ReadBlock(this$static);
    }
  }
  function $ReadBlock(this$static) {
    var numReadBytes, pointerToPostion, size2;
    if (this$static._streamEndWasReached)
      return;
    while (1) {
      size2 = -this$static._bufferOffset + this$static._blockSize - this$static._streamPos;
      if (!size2)
        return;
      numReadBytes = $read_0(
        this$static._stream,
        this$static._bufferBase,
        this$static._bufferOffset + this$static._streamPos,
        size2
      );
      if (numReadBytes == -1) {
        this$static._posLimit = this$static._streamPos;
        pointerToPostion = this$static._bufferOffset + this$static._posLimit;
        if (pointerToPostion > this$static._pointerToLastSafePosition) {
          this$static._posLimit = this$static._pointerToLastSafePosition - this$static._bufferOffset;
        }
        this$static._streamEndWasReached = 1;
        return;
      }
      this$static._streamPos += numReadBytes;
      if (this$static._streamPos >= this$static._pos + this$static._keepSizeAfter) {
        this$static._posLimit = this$static._streamPos - this$static._keepSizeAfter;
      }
    }
  }
  function $ReduceOffsets(this$static, subValue) {
    this$static._bufferOffset += subValue;
    this$static._posLimit -= subValue;
    this$static._pos -= subValue;
    this$static._streamPos -= subValue;
  }
  var CrcTable = function() {
    var i, j, r, CrcTable2 = [];
    for (i = 0; i < 256; ++i) {
      r = i;
      for (j = 0; j < 8; ++j)
        if ((r & 1) != 0) {
          r = r >>> 1 ^ -306674912;
        } else {
          r >>>= 1;
        }
      CrcTable2[i] = r;
    }
    return CrcTable2;
  }();
  function $Create_3(this$static, historySize, keepAddBufferBefore, matchMaxLen, keepAddBufferAfter) {
    var cyclicBufferSize, hs, windowReservSize;
    if (historySize < 1073741567) {
      this$static._cutValue = 16 + (matchMaxLen >> 1);
      windowReservSize = ~~((historySize + keepAddBufferBefore + matchMaxLen + keepAddBufferAfter) / 2) + 256;
      $Create_4(
        this$static,
        historySize + keepAddBufferBefore,
        matchMaxLen + keepAddBufferAfter,
        windowReservSize
      );
      this$static._matchMaxLen = matchMaxLen;
      cyclicBufferSize = historySize + 1;
      if (this$static._cyclicBufferSize != cyclicBufferSize) {
        this$static._son = initDim(
          (this$static._cyclicBufferSize = cyclicBufferSize) * 2
        );
      }
      hs = 65536;
      if (this$static.HASH_ARRAY) {
        hs = historySize - 1;
        hs |= hs >> 1;
        hs |= hs >> 2;
        hs |= hs >> 4;
        hs |= hs >> 8;
        hs >>= 1;
        hs |= 65535;
        if (hs > 16777216)
          hs >>= 1;
        this$static._hashMask = hs;
        ++hs;
        hs += this$static.kFixHashSize;
      }
      if (hs != this$static._hashSizeSum) {
        this$static._hash = initDim(this$static._hashSizeSum = hs);
      }
    }
  }
  function $GetMatches(this$static, distances) {
    var count, cur, curMatch, curMatch2, curMatch3, cyclicPos, delta, hash2Value, hash3Value, hashValue, len, len0, len1, lenLimit, matchMinPos, maxLen, offset, pby1, ptr0, ptr1, temp;
    if (this$static._pos + this$static._matchMaxLen <= this$static._streamPos) {
      lenLimit = this$static._matchMaxLen;
    } else {
      lenLimit = this$static._streamPos - this$static._pos;
      if (lenLimit < this$static.kMinMatchCheck) {
        $MovePos_0(this$static);
        return 0;
      }
    }
    offset = 0;
    matchMinPos = this$static._pos > this$static._cyclicBufferSize ? this$static._pos - this$static._cyclicBufferSize : 0;
    cur = this$static._bufferOffset + this$static._pos;
    maxLen = 1;
    hash2Value = 0;
    hash3Value = 0;
    if (this$static.HASH_ARRAY) {
      temp = CrcTable[this$static._bufferBase[cur] & 255] ^ this$static._bufferBase[cur + 1] & 255;
      hash2Value = temp & 1023;
      temp ^= (this$static._bufferBase[cur + 2] & 255) << 8;
      hash3Value = temp & 65535;
      hashValue = (temp ^ CrcTable[this$static._bufferBase[cur + 3] & 255] << 5) & this$static._hashMask;
    } else {
      hashValue = this$static._bufferBase[cur] & 255 ^ (this$static._bufferBase[cur + 1] & 255) << 8;
    }
    curMatch = this$static._hash[this$static.kFixHashSize + hashValue] || 0;
    if (this$static.HASH_ARRAY) {
      curMatch2 = this$static._hash[hash2Value] || 0;
      curMatch3 = this$static._hash[1024 + hash3Value] || 0;
      this$static._hash[hash2Value] = this$static._pos;
      this$static._hash[1024 + hash3Value] = this$static._pos;
      if (curMatch2 > matchMinPos) {
        if (this$static._bufferBase[this$static._bufferOffset + curMatch2] == this$static._bufferBase[cur]) {
          distances[offset++] = maxLen = 2;
          distances[offset++] = this$static._pos - curMatch2 - 1;
        }
      }
      if (curMatch3 > matchMinPos) {
        if (this$static._bufferBase[this$static._bufferOffset + curMatch3] == this$static._bufferBase[cur]) {
          if (curMatch3 == curMatch2) {
            offset -= 2;
          }
          distances[offset++] = maxLen = 3;
          distances[offset++] = this$static._pos - curMatch3 - 1;
          curMatch2 = curMatch3;
        }
      }
      if (offset != 0 && curMatch2 == curMatch) {
        offset -= 2;
        maxLen = 1;
      }
    }
    this$static._hash[this$static.kFixHashSize + hashValue] = this$static._pos;
    ptr0 = (this$static._cyclicBufferPos << 1) + 1;
    ptr1 = this$static._cyclicBufferPos << 1;
    len0 = len1 = this$static.kNumHashDirectBytes;
    if (this$static.kNumHashDirectBytes != 0) {
      if (curMatch > matchMinPos) {
        if (this$static._bufferBase[this$static._bufferOffset + curMatch + this$static.kNumHashDirectBytes] != this$static._bufferBase[cur + this$static.kNumHashDirectBytes]) {
          distances[offset++] = maxLen = this$static.kNumHashDirectBytes;
          distances[offset++] = this$static._pos - curMatch - 1;
        }
      }
    }
    count = this$static._cutValue;
    while (1) {
      if (curMatch <= matchMinPos || count-- == 0) {
        this$static._son[ptr0] = this$static._son[ptr1] = 0;
        break;
      }
      delta = this$static._pos - curMatch;
      cyclicPos = (delta <= this$static._cyclicBufferPos ? this$static._cyclicBufferPos - delta : this$static._cyclicBufferPos - delta + this$static._cyclicBufferSize) << 1;
      pby1 = this$static._bufferOffset + curMatch;
      len = len0 < len1 ? len0 : len1;
      if (this$static._bufferBase[pby1 + len] == this$static._bufferBase[cur + len]) {
        while (++len != lenLimit) {
          if (this$static._bufferBase[pby1 + len] != this$static._bufferBase[cur + len]) {
            break;
          }
        }
        if (maxLen < len) {
          distances[offset++] = maxLen = len;
          distances[offset++] = delta - 1;
          if (len == lenLimit) {
            this$static._son[ptr1] = this$static._son[cyclicPos];
            this$static._son[ptr0] = this$static._son[cyclicPos + 1];
            break;
          }
        }
      }
      if ((this$static._bufferBase[pby1 + len] & 255) < (this$static._bufferBase[cur + len] & 255)) {
        this$static._son[ptr1] = curMatch;
        ptr1 = cyclicPos + 1;
        curMatch = this$static._son[ptr1];
        len1 = len;
      } else {
        this$static._son[ptr0] = curMatch;
        ptr0 = cyclicPos;
        curMatch = this$static._son[ptr0];
        len0 = len;
      }
    }
    $MovePos_0(this$static);
    return offset;
  }
  function $Init_5(this$static) {
    this$static._bufferOffset = 0;
    this$static._pos = 0;
    this$static._streamPos = 0;
    this$static._streamEndWasReached = 0;
    $ReadBlock(this$static);
    this$static._cyclicBufferPos = 0;
    $ReduceOffsets(this$static, -1);
  }
  function $MovePos_0(this$static) {
    var subValue;
    if (++this$static._cyclicBufferPos >= this$static._cyclicBufferSize) {
      this$static._cyclicBufferPos = 0;
    }
    $MovePos_1(this$static);
    if (this$static._pos == 1073741823) {
      subValue = this$static._pos - this$static._cyclicBufferSize;
      $NormalizeLinks(
        this$static._son,
        this$static._cyclicBufferSize * 2,
        subValue
      );
      $NormalizeLinks(this$static._hash, this$static._hashSizeSum, subValue);
      $ReduceOffsets(this$static, subValue);
    }
  }
  function $NormalizeLinks(items, numItems, subValue) {
    var i, value;
    for (i = 0; i < numItems; ++i) {
      value = items[i] || 0;
      if (value <= subValue) {
        value = 0;
      } else {
        value -= subValue;
      }
      items[i] = value;
    }
  }
  function $SetType(this$static, numHashBytes) {
    this$static.HASH_ARRAY = numHashBytes > 2;
    if (this$static.HASH_ARRAY) {
      this$static.kNumHashDirectBytes = 0;
      this$static.kMinMatchCheck = 4;
      this$static.kFixHashSize = 66560;
    } else {
      this$static.kNumHashDirectBytes = 2;
      this$static.kMinMatchCheck = 3;
      this$static.kFixHashSize = 0;
    }
  }
  function $Skip(this$static, num) {
    var count, cur, curMatch, cyclicPos, delta, hash2Value, hash3Value, hashValue, len, len0, len1, lenLimit, matchMinPos, pby1, ptr0, ptr1, temp;
    do {
      if (this$static._pos + this$static._matchMaxLen <= this$static._streamPos) {
        lenLimit = this$static._matchMaxLen;
      } else {
        lenLimit = this$static._streamPos - this$static._pos;
        if (lenLimit < this$static.kMinMatchCheck) {
          $MovePos_0(this$static);
          continue;
        }
      }
      matchMinPos = this$static._pos > this$static._cyclicBufferSize ? this$static._pos - this$static._cyclicBufferSize : 0;
      cur = this$static._bufferOffset + this$static._pos;
      if (this$static.HASH_ARRAY) {
        temp = CrcTable[this$static._bufferBase[cur] & 255] ^ this$static._bufferBase[cur + 1] & 255;
        hash2Value = temp & 1023;
        this$static._hash[hash2Value] = this$static._pos;
        temp ^= (this$static._bufferBase[cur + 2] & 255) << 8;
        hash3Value = temp & 65535;
        this$static._hash[1024 + hash3Value] = this$static._pos;
        hashValue = (temp ^ CrcTable[this$static._bufferBase[cur + 3] & 255] << 5) & this$static._hashMask;
      } else {
        hashValue = this$static._bufferBase[cur] & 255 ^ (this$static._bufferBase[cur + 1] & 255) << 8;
      }
      curMatch = this$static._hash[this$static.kFixHashSize + hashValue];
      this$static._hash[this$static.kFixHashSize + hashValue] = this$static._pos;
      ptr0 = (this$static._cyclicBufferPos << 1) + 1;
      ptr1 = this$static._cyclicBufferPos << 1;
      len0 = len1 = this$static.kNumHashDirectBytes;
      count = this$static._cutValue;
      while (1) {
        if (curMatch <= matchMinPos || count-- == 0) {
          this$static._son[ptr0] = this$static._son[ptr1] = 0;
          break;
        }
        delta = this$static._pos - curMatch;
        cyclicPos = (delta <= this$static._cyclicBufferPos ? this$static._cyclicBufferPos - delta : this$static._cyclicBufferPos - delta + this$static._cyclicBufferSize) << 1;
        pby1 = this$static._bufferOffset + curMatch;
        len = len0 < len1 ? len0 : len1;
        if (this$static._bufferBase[pby1 + len] == this$static._bufferBase[cur + len]) {
          while (++len != lenLimit) {
            if (this$static._bufferBase[pby1 + len] != this$static._bufferBase[cur + len]) {
              break;
            }
          }
          if (len == lenLimit) {
            this$static._son[ptr1] = this$static._son[cyclicPos];
            this$static._son[ptr0] = this$static._son[cyclicPos + 1];
            break;
          }
        }
        if ((this$static._bufferBase[pby1 + len] & 255) < (this$static._bufferBase[cur + len] & 255)) {
          this$static._son[ptr1] = curMatch;
          ptr1 = cyclicPos + 1;
          curMatch = this$static._son[ptr1];
          len1 = len;
        } else {
          this$static._son[ptr0] = curMatch;
          ptr0 = cyclicPos;
          curMatch = this$static._son[ptr0];
          len0 = len;
        }
      }
      $MovePos_0(this$static);
    } while (--num != 0);
  }
  function $CopyBlock(this$static, distance, len) {
    var pos = this$static._pos - distance - 1;
    if (pos < 0) {
      pos += this$static._windowSize;
    }
    for (; len != 0; --len) {
      if (pos >= this$static._windowSize) {
        pos = 0;
      }
      this$static._buffer[this$static._pos++] = this$static._buffer[pos++];
      if (this$static._pos >= this$static._windowSize) {
        $Flush_0(this$static);
      }
    }
  }
  function $Create_5(this$static, windowSize) {
    if (this$static._buffer == null || this$static._windowSize != windowSize) {
      this$static._buffer = initDim(windowSize);
    }
    this$static._windowSize = windowSize;
    this$static._pos = 0;
    this$static._streamPos = 0;
  }
  function $Flush_0(this$static) {
    var size2 = this$static._pos - this$static._streamPos;
    if (!size2) {
      return;
    }
    $write_0(
      this$static._stream,
      this$static._buffer,
      this$static._streamPos,
      size2
    );
    if (this$static._pos >= this$static._windowSize) {
      this$static._pos = 0;
    }
    this$static._streamPos = this$static._pos;
  }
  function $GetByte(this$static, distance) {
    var pos = this$static._pos - distance - 1;
    if (pos < 0) {
      pos += this$static._windowSize;
    }
    return this$static._buffer[pos];
  }
  function $PutByte(this$static, b) {
    this$static._buffer[this$static._pos++] = b;
    if (this$static._pos >= this$static._windowSize) {
      $Flush_0(this$static);
    }
  }
  function $ReleaseStream(this$static) {
    $Flush_0(this$static);
    this$static._stream = null;
  }
  function GetLenToPosState(len) {
    len -= 2;
    if (len < 4) {
      return len;
    }
    return 3;
  }
  function StateUpdateChar(index) {
    if (index < 4) {
      return 0;
    }
    if (index < 10) {
      return index - 3;
    }
    return index - 6;
  }
  function $Chunker_0(this$static, encoder) {
    this$static.encoder = encoder;
    this$static.decoder = null;
    this$static.alive = 1;
    return this$static;
  }
  function $Chunker(this$static, decoder) {
    this$static.decoder = decoder;
    this$static.encoder = null;
    this$static.alive = 1;
    return this$static;
  }
  function $processChunk(this$static) {
    if (!this$static.alive) {
      throw new Error("bad state");
    }
    if (this$static.encoder) {
      $processEncoderChunk(this$static);
    } else {
      $processDecoderChunk(this$static);
    }
    return this$static.alive;
  }
  function $processDecoderChunk(this$static) {
    var result = $CodeOneChunk(this$static.decoder);
    if (result == -1) {
      throw new Error("corrupted input");
    }
    this$static.inBytesProcessed = N1_longLit;
    this$static.outBytesProcessed = this$static.decoder.nowPos64;
    if (result || compare(this$static.decoder.outSize, P0_longLit) >= 0 && compare(this$static.decoder.nowPos64, this$static.decoder.outSize) >= 0) {
      $Flush_0(this$static.decoder.m_OutWindow);
      $ReleaseStream(this$static.decoder.m_OutWindow);
      this$static.decoder.m_RangeDecoder.Stream = null;
      this$static.alive = 0;
    }
  }
  function $processEncoderChunk(this$static) {
    $CodeOneBlock(
      this$static.encoder,
      this$static.encoder.processedInSize,
      this$static.encoder.processedOutSize,
      this$static.encoder.finished
    );
    this$static.inBytesProcessed = this$static.encoder.processedInSize[0];
    if (this$static.encoder.finished[0]) {
      $ReleaseStreams(this$static.encoder);
      this$static.alive = 0;
    }
  }
  function $CodeInChunks(this$static, inStream, outStream, outSize) {
    this$static.m_RangeDecoder.Stream = inStream;
    $ReleaseStream(this$static.m_OutWindow);
    this$static.m_OutWindow._stream = outStream;
    $Init_1(this$static);
    this$static.state = 0;
    this$static.rep0 = 0;
    this$static.rep1 = 0;
    this$static.rep2 = 0;
    this$static.rep3 = 0;
    this$static.outSize = outSize;
    this$static.nowPos64 = P0_longLit;
    this$static.prevByte = 0;
    return $Chunker({}, this$static);
  }
  function $CodeOneChunk(this$static) {
    var decoder2, distance, len, numDirectBits, posSlot, posState;
    posState = lowBits_0(this$static.nowPos64) & this$static.m_PosStateMask;
    if (!$DecodeBit(
      this$static.m_RangeDecoder,
      this$static.m_IsMatchDecoders,
      (this$static.state << 4) + posState
    )) {
      decoder2 = $GetDecoder(
        this$static.m_LiteralDecoder,
        lowBits_0(this$static.nowPos64),
        this$static.prevByte
      );
      if (this$static.state < 7) {
        this$static.prevByte = $DecodeNormal(decoder2, this$static.m_RangeDecoder);
      } else {
        this$static.prevByte = $DecodeWithMatchByte(
          decoder2,
          this$static.m_RangeDecoder,
          $GetByte(this$static.m_OutWindow, this$static.rep0)
        );
      }
      $PutByte(this$static.m_OutWindow, this$static.prevByte);
      this$static.state = StateUpdateChar(this$static.state);
      this$static.nowPos64 = add2(this$static.nowPos64, P1_longLit);
    } else {
      if ($DecodeBit(
        this$static.m_RangeDecoder,
        this$static.m_IsRepDecoders,
        this$static.state
      )) {
        len = 0;
        if (!$DecodeBit(
          this$static.m_RangeDecoder,
          this$static.m_IsRepG0Decoders,
          this$static.state
        )) {
          if (!$DecodeBit(
            this$static.m_RangeDecoder,
            this$static.m_IsRep0LongDecoders,
            (this$static.state << 4) + posState
          )) {
            this$static.state = this$static.state < 7 ? 9 : 11;
            len = 1;
          }
        } else {
          if (!$DecodeBit(
            this$static.m_RangeDecoder,
            this$static.m_IsRepG1Decoders,
            this$static.state
          )) {
            distance = this$static.rep1;
          } else {
            if (!$DecodeBit(
              this$static.m_RangeDecoder,
              this$static.m_IsRepG2Decoders,
              this$static.state
            )) {
              distance = this$static.rep2;
            } else {
              distance = this$static.rep3;
              this$static.rep3 = this$static.rep2;
            }
            this$static.rep2 = this$static.rep1;
          }
          this$static.rep1 = this$static.rep0;
          this$static.rep0 = distance;
        }
        if (!len) {
          len = $Decode(
            this$static.m_RepLenDecoder,
            this$static.m_RangeDecoder,
            posState
          ) + 2;
          this$static.state = this$static.state < 7 ? 8 : 11;
        }
      } else {
        this$static.rep3 = this$static.rep2;
        this$static.rep2 = this$static.rep1;
        this$static.rep1 = this$static.rep0;
        len = 2 + $Decode(this$static.m_LenDecoder, this$static.m_RangeDecoder, posState);
        this$static.state = this$static.state < 7 ? 7 : 10;
        posSlot = $Decode_0(
          this$static.m_PosSlotDecoder[GetLenToPosState(len)],
          this$static.m_RangeDecoder
        );
        if (posSlot >= 4) {
          numDirectBits = (posSlot >> 1) - 1;
          this$static.rep0 = (2 | posSlot & 1) << numDirectBits;
          if (posSlot < 14) {
            this$static.rep0 += ReverseDecode(
              this$static.m_PosDecoders,
              this$static.rep0 - posSlot - 1,
              this$static.m_RangeDecoder,
              numDirectBits
            );
          } else {
            this$static.rep0 += $DecodeDirectBits(this$static.m_RangeDecoder, numDirectBits - 4) << 4;
            this$static.rep0 += $ReverseDecode(
              this$static.m_PosAlignDecoder,
              this$static.m_RangeDecoder
            );
            if (this$static.rep0 < 0) {
              if (this$static.rep0 == -1) {
                return 1;
              }
              return -1;
            }
          }
        } else
          this$static.rep0 = posSlot;
      }
      if (compare(fromInt(this$static.rep0), this$static.nowPos64) >= 0 || this$static.rep0 >= this$static.m_DictionarySizeCheck) {
        return -1;
      }
      $CopyBlock(this$static.m_OutWindow, this$static.rep0, len);
      this$static.nowPos64 = add2(this$static.nowPos64, fromInt(len));
      this$static.prevByte = $GetByte(this$static.m_OutWindow, 0);
    }
    return 0;
  }
  function $Decoder(this$static) {
    this$static.m_OutWindow = {};
    this$static.m_RangeDecoder = {};
    this$static.m_IsMatchDecoders = initDim(192);
    this$static.m_IsRepDecoders = initDim(12);
    this$static.m_IsRepG0Decoders = initDim(12);
    this$static.m_IsRepG1Decoders = initDim(12);
    this$static.m_IsRepG2Decoders = initDim(12);
    this$static.m_IsRep0LongDecoders = initDim(192);
    this$static.m_PosSlotDecoder = initDim(4);
    this$static.m_PosDecoders = initDim(114);
    this$static.m_PosAlignDecoder = $BitTreeDecoder({}, 4);
    this$static.m_LenDecoder = $Decoder$LenDecoder({});
    this$static.m_RepLenDecoder = $Decoder$LenDecoder({});
    this$static.m_LiteralDecoder = {};
    for (var i = 0; i < 4; ++i) {
      this$static.m_PosSlotDecoder[i] = $BitTreeDecoder({}, 6);
    }
    return this$static;
  }
  function $Init_1(this$static) {
    this$static.m_OutWindow._streamPos = 0;
    this$static.m_OutWindow._pos = 0;
    InitBitModels(this$static.m_IsMatchDecoders);
    InitBitModels(this$static.m_IsRep0LongDecoders);
    InitBitModels(this$static.m_IsRepDecoders);
    InitBitModels(this$static.m_IsRepG0Decoders);
    InitBitModels(this$static.m_IsRepG1Decoders);
    InitBitModels(this$static.m_IsRepG2Decoders);
    InitBitModels(this$static.m_PosDecoders);
    $Init_0(this$static.m_LiteralDecoder);
    for (var i = 0; i < 4; ++i) {
      InitBitModels(this$static.m_PosSlotDecoder[i].Models);
    }
    $Init(this$static.m_LenDecoder);
    $Init(this$static.m_RepLenDecoder);
    InitBitModels(this$static.m_PosAlignDecoder.Models);
    $Init_8(this$static.m_RangeDecoder);
  }
  function $SetDecoderProperties(this$static, properties) {
    var dictionarySize, i, lc, lp, pb, remainder, val;
    if (properties.length < 5)
      return 0;
    val = properties[0] & 255;
    lc = val % 9;
    remainder = ~~(val / 9);
    lp = remainder % 5;
    pb = ~~(remainder / 5);
    dictionarySize = 0;
    for (i = 0; i < 4; ++i) {
      dictionarySize += (properties[1 + i] & 255) << i * 8;
    }
    if (dictionarySize > 99999999 || !$SetLcLpPb(this$static, lc, lp, pb)) {
      return 0;
    }
    return $SetDictionarySize(this$static, dictionarySize);
  }
  function $SetDictionarySize(this$static, dictionarySize) {
    if (dictionarySize < 0) {
      return 0;
    }
    if (this$static.m_DictionarySize != dictionarySize) {
      this$static.m_DictionarySize = dictionarySize;
      this$static.m_DictionarySizeCheck = Math.max(
        this$static.m_DictionarySize,
        1
      );
      $Create_5(
        this$static.m_OutWindow,
        Math.max(this$static.m_DictionarySizeCheck, 4096)
      );
    }
    return 1;
  }
  function $SetLcLpPb(this$static, lc, lp, pb) {
    if (lc > 8 || lp > 4 || pb > 4) {
      return 0;
    }
    $Create_0(this$static.m_LiteralDecoder, lp, lc);
    var numPosStates = 1 << pb;
    $Create(this$static.m_LenDecoder, numPosStates);
    $Create(this$static.m_RepLenDecoder, numPosStates);
    this$static.m_PosStateMask = numPosStates - 1;
    return 1;
  }
  function $Create(this$static, numPosStates) {
    for (; this$static.m_NumPosStates < numPosStates; ++this$static.m_NumPosStates) {
      this$static.m_LowCoder[this$static.m_NumPosStates] = $BitTreeDecoder({}, 3);
      this$static.m_MidCoder[this$static.m_NumPosStates] = $BitTreeDecoder({}, 3);
    }
  }
  function $Decode(this$static, rangeDecoder, posState) {
    if (!$DecodeBit(rangeDecoder, this$static.m_Choice, 0)) {
      return $Decode_0(this$static.m_LowCoder[posState], rangeDecoder);
    }
    var symbol = 8;
    if (!$DecodeBit(rangeDecoder, this$static.m_Choice, 1)) {
      symbol += $Decode_0(this$static.m_MidCoder[posState], rangeDecoder);
    } else {
      symbol += 8 + $Decode_0(this$static.m_HighCoder, rangeDecoder);
    }
    return symbol;
  }
  function $Decoder$LenDecoder(this$static) {
    this$static.m_Choice = initDim(2);
    this$static.m_LowCoder = initDim(16);
    this$static.m_MidCoder = initDim(16);
    this$static.m_HighCoder = $BitTreeDecoder({}, 8);
    this$static.m_NumPosStates = 0;
    return this$static;
  }
  function $Init(this$static) {
    InitBitModels(this$static.m_Choice);
    for (var posState = 0; posState < this$static.m_NumPosStates; ++posState) {
      InitBitModels(this$static.m_LowCoder[posState].Models);
      InitBitModels(this$static.m_MidCoder[posState].Models);
    }
    InitBitModels(this$static.m_HighCoder.Models);
  }
  function $Create_0(this$static, numPosBits, numPrevBits) {
    var i, numStates;
    if (this$static.m_Coders != null && this$static.m_NumPrevBits == numPrevBits && this$static.m_NumPosBits == numPosBits)
      return;
    this$static.m_NumPosBits = numPosBits;
    this$static.m_PosMask = (1 << numPosBits) - 1;
    this$static.m_NumPrevBits = numPrevBits;
    numStates = 1 << this$static.m_NumPrevBits + this$static.m_NumPosBits;
    this$static.m_Coders = initDim(numStates);
    for (i = 0; i < numStates; ++i)
      this$static.m_Coders[i] = $Decoder$LiteralDecoder$Decoder2({});
  }
  function $GetDecoder(this$static, pos, prevByte) {
    return this$static.m_Coders[((pos & this$static.m_PosMask) << this$static.m_NumPrevBits) + ((prevByte & 255) >>> 8 - this$static.m_NumPrevBits)];
  }
  function $Init_0(this$static) {
    var i, numStates;
    numStates = 1 << this$static.m_NumPrevBits + this$static.m_NumPosBits;
    for (i = 0; i < numStates; ++i) {
      InitBitModels(this$static.m_Coders[i].m_Decoders);
    }
  }
  function $DecodeNormal(this$static, rangeDecoder) {
    var symbol = 1;
    do {
      symbol = symbol << 1 | $DecodeBit(rangeDecoder, this$static.m_Decoders, symbol);
    } while (symbol < 256);
    return symbol << 24 >> 24;
  }
  function $DecodeWithMatchByte(this$static, rangeDecoder, matchByte) {
    var bit, matchBit, symbol = 1;
    do {
      matchBit = matchByte >> 7 & 1;
      matchByte <<= 1;
      bit = $DecodeBit(
        rangeDecoder,
        this$static.m_Decoders,
        (1 + matchBit << 8) + symbol
      );
      symbol = symbol << 1 | bit;
      if (matchBit != bit) {
        while (symbol < 256) {
          symbol = symbol << 1 | $DecodeBit(rangeDecoder, this$static.m_Decoders, symbol);
        }
        break;
      }
    } while (symbol < 256);
    return symbol << 24 >> 24;
  }
  function $Decoder$LiteralDecoder$Decoder2(this$static) {
    this$static.m_Decoders = initDim(768);
    return this$static;
  }
  var g_FastPos = function() {
    var j, k, slotFast, c = 2, g_FastPos2 = [0, 1];
    for (slotFast = 2; slotFast < 22; ++slotFast) {
      k = 1 << (slotFast >> 1) - 1;
      for (j = 0; j < k; ++j, ++c)
        g_FastPos2[c] = slotFast << 24 >> 24;
    }
    return g_FastPos2;
  }();
  function $Backward(this$static, cur) {
    var backCur, backMem, posMem, posPrev;
    this$static._optimumEndIndex = cur;
    posMem = this$static._optimum[cur].PosPrev;
    backMem = this$static._optimum[cur].BackPrev;
    do {
      if (this$static._optimum[cur].Prev1IsChar) {
        $MakeAsChar(this$static._optimum[posMem]);
        this$static._optimum[posMem].PosPrev = posMem - 1;
        if (this$static._optimum[cur].Prev2) {
          this$static._optimum[posMem - 1].Prev1IsChar = 0;
          this$static._optimum[posMem - 1].PosPrev = this$static._optimum[cur].PosPrev2;
          this$static._optimum[posMem - 1].BackPrev = this$static._optimum[cur].BackPrev2;
        }
      }
      posPrev = posMem;
      backCur = backMem;
      backMem = this$static._optimum[posPrev].BackPrev;
      posMem = this$static._optimum[posPrev].PosPrev;
      this$static._optimum[posPrev].BackPrev = backCur;
      this$static._optimum[posPrev].PosPrev = cur;
      cur = posPrev;
    } while (cur > 0);
    this$static.backRes = this$static._optimum[0].BackPrev;
    this$static._optimumCurrentIndex = this$static._optimum[0].PosPrev;
    return this$static._optimumCurrentIndex;
  }
  function $BaseInit(this$static) {
    this$static._state = 0;
    this$static._previousByte = 0;
    for (var i = 0; i < 4; ++i) {
      this$static._repDistances[i] = 0;
    }
  }
  function $CodeOneBlock(this$static, inSize, outSize, finished) {
    var baseVal, complexState, curByte, distance, footerBits, i, len, lenToPosState, matchByte, pos, posReduced, posSlot, posState, progressPosValuePrev, subCoder;
    inSize[0] = P0_longLit;
    outSize[0] = P0_longLit;
    finished[0] = 1;
    if (this$static._inStream) {
      this$static._matchFinder._stream = this$static._inStream;
      $Init_5(this$static._matchFinder);
      this$static._needReleaseMFStream = 1;
      this$static._inStream = null;
    }
    if (this$static._finished) {
      return;
    }
    this$static._finished = 1;
    progressPosValuePrev = this$static.nowPos64;
    if (eq(this$static.nowPos64, P0_longLit)) {
      if (!$GetNumAvailableBytes(this$static._matchFinder)) {
        $Flush(this$static, lowBits_0(this$static.nowPos64));
        return;
      }
      $ReadMatchDistances(this$static);
      posState = lowBits_0(this$static.nowPos64) & this$static._posStateMask;
      $Encode_3(
        this$static._rangeEncoder,
        this$static._isMatch,
        (this$static._state << 4) + posState,
        0
      );
      this$static._state = StateUpdateChar(this$static._state);
      curByte = $GetIndexByte(
        this$static._matchFinder,
        -this$static._additionalOffset
      );
      $Encode_1(
        $GetSubCoder(
          this$static._literalEncoder,
          lowBits_0(this$static.nowPos64),
          this$static._previousByte
        ),
        this$static._rangeEncoder,
        curByte
      );
      this$static._previousByte = curByte;
      --this$static._additionalOffset;
      this$static.nowPos64 = add2(this$static.nowPos64, P1_longLit);
    }
    if (!$GetNumAvailableBytes(this$static._matchFinder)) {
      $Flush(this$static, lowBits_0(this$static.nowPos64));
      return;
    }
    while (1) {
      len = $GetOptimum(this$static, lowBits_0(this$static.nowPos64));
      pos = this$static.backRes;
      posState = lowBits_0(this$static.nowPos64) & this$static._posStateMask;
      complexState = (this$static._state << 4) + posState;
      if (len == 1 && pos == -1) {
        $Encode_3(
          this$static._rangeEncoder,
          this$static._isMatch,
          complexState,
          0
        );
        curByte = $GetIndexByte(
          this$static._matchFinder,
          -this$static._additionalOffset
        );
        subCoder = $GetSubCoder(
          this$static._literalEncoder,
          lowBits_0(this$static.nowPos64),
          this$static._previousByte
        );
        if (this$static._state < 7) {
          $Encode_1(subCoder, this$static._rangeEncoder, curByte);
        } else {
          matchByte = $GetIndexByte(
            this$static._matchFinder,
            -this$static._repDistances[0] - 1 - this$static._additionalOffset
          );
          $EncodeMatched(subCoder, this$static._rangeEncoder, matchByte, curByte);
        }
        this$static._previousByte = curByte;
        this$static._state = StateUpdateChar(this$static._state);
      } else {
        $Encode_3(
          this$static._rangeEncoder,
          this$static._isMatch,
          complexState,
          1
        );
        if (pos < 4) {
          $Encode_3(
            this$static._rangeEncoder,
            this$static._isRep,
            this$static._state,
            1
          );
          if (!pos) {
            $Encode_3(
              this$static._rangeEncoder,
              this$static._isRepG0,
              this$static._state,
              0
            );
            if (len == 1) {
              $Encode_3(
                this$static._rangeEncoder,
                this$static._isRep0Long,
                complexState,
                0
              );
            } else {
              $Encode_3(
                this$static._rangeEncoder,
                this$static._isRep0Long,
                complexState,
                1
              );
            }
          } else {
            $Encode_3(
              this$static._rangeEncoder,
              this$static._isRepG0,
              this$static._state,
              1
            );
            if (pos == 1) {
              $Encode_3(
                this$static._rangeEncoder,
                this$static._isRepG1,
                this$static._state,
                0
              );
            } else {
              $Encode_3(
                this$static._rangeEncoder,
                this$static._isRepG1,
                this$static._state,
                1
              );
              $Encode_3(
                this$static._rangeEncoder,
                this$static._isRepG2,
                this$static._state,
                pos - 2
              );
            }
          }
          if (len == 1) {
            this$static._state = this$static._state < 7 ? 9 : 11;
          } else {
            $Encode_0(
              this$static._repMatchLenEncoder,
              this$static._rangeEncoder,
              len - 2,
              posState
            );
            this$static._state = this$static._state < 7 ? 8 : 11;
          }
          distance = this$static._repDistances[pos];
          if (pos != 0) {
            for (i = pos; i >= 1; --i) {
              this$static._repDistances[i] = this$static._repDistances[i - 1];
            }
            this$static._repDistances[0] = distance;
          }
        } else {
          $Encode_3(
            this$static._rangeEncoder,
            this$static._isRep,
            this$static._state,
            0
          );
          this$static._state = this$static._state < 7 ? 7 : 10;
          $Encode_0(
            this$static._lenEncoder,
            this$static._rangeEncoder,
            len - 2,
            posState
          );
          pos -= 4;
          posSlot = GetPosSlot(pos);
          lenToPosState = GetLenToPosState(len);
          $Encode_2(
            this$static._posSlotEncoder[lenToPosState],
            this$static._rangeEncoder,
            posSlot
          );
          if (posSlot >= 4) {
            footerBits = (posSlot >> 1) - 1;
            baseVal = (2 | posSlot & 1) << footerBits;
            posReduced = pos - baseVal;
            if (posSlot < 14) {
              ReverseEncode(
                this$static._posEncoders,
                baseVal - posSlot - 1,
                this$static._rangeEncoder,
                footerBits,
                posReduced
              );
            } else {
              $EncodeDirectBits(
                this$static._rangeEncoder,
                posReduced >> 4,
                footerBits - 4
              );
              $ReverseEncode(
                this$static._posAlignEncoder,
                this$static._rangeEncoder,
                posReduced & 15
              );
              ++this$static._alignPriceCount;
            }
          }
          distance = pos;
          for (i = 3; i >= 1; --i) {
            this$static._repDistances[i] = this$static._repDistances[i - 1];
          }
          this$static._repDistances[0] = distance;
          ++this$static._matchPriceCount;
        }
        this$static._previousByte = $GetIndexByte(
          this$static._matchFinder,
          len - 1 - this$static._additionalOffset
        );
      }
      this$static._additionalOffset -= len;
      this$static.nowPos64 = add2(this$static.nowPos64, fromInt(len));
      if (!this$static._additionalOffset) {
        if (this$static._matchPriceCount >= 128) {
          $FillDistancesPrices(this$static);
        }
        if (this$static._alignPriceCount >= 16) {
          $FillAlignPrices(this$static);
        }
        inSize[0] = this$static.nowPos64;
        outSize[0] = $GetProcessedSizeAdd(this$static._rangeEncoder);
        if (!$GetNumAvailableBytes(this$static._matchFinder)) {
          $Flush(this$static, lowBits_0(this$static.nowPos64));
          return;
        }
        if (compare(sub(this$static.nowPos64, progressPosValuePrev), [4096, 0]) >= 0) {
          this$static._finished = 0;
          finished[0] = 0;
          return;
        }
      }
    }
  }
  function $Create_2(this$static) {
    var bt, numHashBytes;
    if (!this$static._matchFinder) {
      bt = {};
      numHashBytes = 4;
      if (!this$static._matchFinderType) {
        numHashBytes = 2;
      }
      $SetType(bt, numHashBytes);
      this$static._matchFinder = bt;
    }
    $Create_1(
      this$static._literalEncoder,
      this$static._numLiteralPosStateBits,
      this$static._numLiteralContextBits
    );
    if (this$static._dictionarySize == this$static._dictionarySizePrev && this$static._numFastBytesPrev == this$static._numFastBytes) {
      return;
    }
    $Create_3(
      this$static._matchFinder,
      this$static._dictionarySize,
      4096,
      this$static._numFastBytes,
      274
    );
    this$static._dictionarySizePrev = this$static._dictionarySize;
    this$static._numFastBytesPrev = this$static._numFastBytes;
  }
  function $Encoder(this$static) {
    var i;
    this$static._repDistances = initDim(4);
    this$static._optimum = [];
    this$static._rangeEncoder = {};
    this$static._isMatch = initDim(192);
    this$static._isRep = initDim(12);
    this$static._isRepG0 = initDim(12);
    this$static._isRepG1 = initDim(12);
    this$static._isRepG2 = initDim(12);
    this$static._isRep0Long = initDim(192);
    this$static._posSlotEncoder = [];
    this$static._posEncoders = initDim(114);
    this$static._posAlignEncoder = $BitTreeEncoder({}, 4);
    this$static._lenEncoder = $Encoder$LenPriceTableEncoder({});
    this$static._repMatchLenEncoder = $Encoder$LenPriceTableEncoder({});
    this$static._literalEncoder = {};
    this$static._matchDistances = [];
    this$static._posSlotPrices = [];
    this$static._distancesPrices = [];
    this$static._alignPrices = initDim(16);
    this$static.reps = initDim(4);
    this$static.repLens = initDim(4);
    this$static.processedInSize = [P0_longLit];
    this$static.processedOutSize = [P0_longLit];
    this$static.finished = [0];
    this$static.properties = initDim(5);
    this$static.tempPrices = initDim(128);
    this$static._longestMatchLength = 0;
    this$static._matchFinderType = 1;
    this$static._numDistancePairs = 0;
    this$static._numFastBytesPrev = -1;
    this$static.backRes = 0;
    for (i = 0; i < 4096; ++i) {
      this$static._optimum[i] = {};
    }
    for (i = 0; i < 4; ++i) {
      this$static._posSlotEncoder[i] = $BitTreeEncoder({}, 6);
    }
    return this$static;
  }
  function $FillAlignPrices(this$static) {
    for (var i = 0; i < 16; ++i) {
      this$static._alignPrices[i] = $ReverseGetPrice(
        this$static._posAlignEncoder,
        i
      );
    }
    this$static._alignPriceCount = 0;
  }
  function $FillDistancesPrices(this$static) {
    var baseVal, encoder, footerBits, i, lenToPosState, posSlot, st, st2;
    for (i = 4; i < 128; ++i) {
      posSlot = GetPosSlot(i);
      footerBits = (posSlot >> 1) - 1;
      baseVal = (2 | posSlot & 1) << footerBits;
      this$static.tempPrices[i] = ReverseGetPrice(
        this$static._posEncoders,
        baseVal - posSlot - 1,
        footerBits,
        i - baseVal
      );
    }
    for (lenToPosState = 0; lenToPosState < 4; ++lenToPosState) {
      encoder = this$static._posSlotEncoder[lenToPosState];
      st = lenToPosState << 6;
      for (posSlot = 0; posSlot < this$static._distTableSize; ++posSlot) {
        this$static._posSlotPrices[st + posSlot] = $GetPrice_1(encoder, posSlot);
      }
      for (posSlot = 14; posSlot < this$static._distTableSize; ++posSlot) {
        this$static._posSlotPrices[st + posSlot] += (posSlot >> 1) - 1 - 4 << 6;
      }
      st2 = lenToPosState * 128;
      for (i = 0; i < 4; ++i) {
        this$static._distancesPrices[st2 + i] = this$static._posSlotPrices[st + i];
      }
      for (; i < 128; ++i) {
        this$static._distancesPrices[st2 + i] = this$static._posSlotPrices[st + GetPosSlot(i)] + this$static.tempPrices[i];
      }
    }
    this$static._matchPriceCount = 0;
  }
  function $Flush(this$static, nowPos) {
    $ReleaseMFStream(this$static);
    $WriteEndMarker(this$static, nowPos & this$static._posStateMask);
    for (var i = 0; i < 5; ++i) {
      $ShiftLow(this$static._rangeEncoder);
    }
  }
  function $GetOptimum(this$static, position) {
    var cur, curAnd1Price, curAndLenCharPrice, curAndLenPrice, curBack, curPrice, currentByte, distance, i, len, lenEnd, lenMain, lenRes, lenTest, lenTest2, lenTestTemp, matchByte, matchPrice, newLen, nextIsChar, nextMatchPrice, nextOptimum, nextRepMatchPrice, normalMatchPrice, numAvailableBytes, numAvailableBytesFull, numDistancePairs, offs, offset, opt, optimum, pos, posPrev, posState, posStateNext, price_4, repIndex, repLen, repMatchPrice, repMaxIndex, shortRepPrice, startLen, state, state2, t, price, price_0, price_1, price_2, price_3;
    if (this$static._optimumEndIndex != this$static._optimumCurrentIndex) {
      lenRes = this$static._optimum[this$static._optimumCurrentIndex].PosPrev - this$static._optimumCurrentIndex;
      this$static.backRes = this$static._optimum[this$static._optimumCurrentIndex].BackPrev;
      this$static._optimumCurrentIndex = this$static._optimum[this$static._optimumCurrentIndex].PosPrev;
      return lenRes;
    }
    this$static._optimumCurrentIndex = this$static._optimumEndIndex = 0;
    if (this$static._longestMatchWasFound) {
      lenMain = this$static._longestMatchLength;
      this$static._longestMatchWasFound = 0;
    } else {
      lenMain = $ReadMatchDistances(this$static);
    }
    numDistancePairs = this$static._numDistancePairs;
    numAvailableBytes = $GetNumAvailableBytes(this$static._matchFinder) + 1;
    if (numAvailableBytes < 2) {
      this$static.backRes = -1;
      return 1;
    }
    if (numAvailableBytes > 273) {
      numAvailableBytes = 273;
    }
    repMaxIndex = 0;
    for (i = 0; i < 4; ++i) {
      this$static.reps[i] = this$static._repDistances[i];
      this$static.repLens[i] = $GetMatchLen(
        this$static._matchFinder,
        -1,
        this$static.reps[i],
        273
      );
      if (this$static.repLens[i] > this$static.repLens[repMaxIndex]) {
        repMaxIndex = i;
      }
    }
    if (this$static.repLens[repMaxIndex] >= this$static._numFastBytes) {
      this$static.backRes = repMaxIndex;
      lenRes = this$static.repLens[repMaxIndex];
      $MovePos(this$static, lenRes - 1);
      return lenRes;
    }
    if (lenMain >= this$static._numFastBytes) {
      this$static.backRes = this$static._matchDistances[numDistancePairs - 1] + 4;
      $MovePos(this$static, lenMain - 1);
      return lenMain;
    }
    currentByte = $GetIndexByte(this$static._matchFinder, -1);
    matchByte = $GetIndexByte(
      this$static._matchFinder,
      -this$static._repDistances[0] - 1 - 1
    );
    if (lenMain < 2 && currentByte != matchByte && this$static.repLens[repMaxIndex] < 2) {
      this$static.backRes = -1;
      return 1;
    }
    this$static._optimum[0].State = this$static._state;
    posState = position & this$static._posStateMask;
    this$static._optimum[1].Price = ProbPrices[this$static._isMatch[(this$static._state << 4) + posState] >>> 2] + $GetPrice_0(
      $GetSubCoder(
        this$static._literalEncoder,
        position,
        this$static._previousByte
      ),
      this$static._state >= 7,
      matchByte,
      currentByte
    );
    $MakeAsChar(this$static._optimum[1]);
    matchPrice = ProbPrices[2048 - this$static._isMatch[(this$static._state << 4) + posState] >>> 2];
    repMatchPrice = matchPrice + ProbPrices[2048 - this$static._isRep[this$static._state] >>> 2];
    if (matchByte == currentByte) {
      shortRepPrice = repMatchPrice + $GetRepLen1Price(this$static, this$static._state, posState);
      if (shortRepPrice < this$static._optimum[1].Price) {
        this$static._optimum[1].Price = shortRepPrice;
        $MakeAsShortRep(this$static._optimum[1]);
      }
    }
    lenEnd = lenMain >= this$static.repLens[repMaxIndex] ? lenMain : this$static.repLens[repMaxIndex];
    if (lenEnd < 2) {
      this$static.backRes = this$static._optimum[1].BackPrev;
      return 1;
    }
    this$static._optimum[1].PosPrev = 0;
    this$static._optimum[0].Backs0 = this$static.reps[0];
    this$static._optimum[0].Backs1 = this$static.reps[1];
    this$static._optimum[0].Backs2 = this$static.reps[2];
    this$static._optimum[0].Backs3 = this$static.reps[3];
    len = lenEnd;
    do {
      this$static._optimum[len--].Price = 268435455;
    } while (len >= 2);
    for (i = 0; i < 4; ++i) {
      repLen = this$static.repLens[i];
      if (repLen < 2) {
        continue;
      }
      price_4 = repMatchPrice + $GetPureRepPrice(this$static, i, this$static._state, posState);
      do {
        curAndLenPrice = price_4 + $GetPrice(this$static._repMatchLenEncoder, repLen - 2, posState);
        optimum = this$static._optimum[repLen];
        if (curAndLenPrice < optimum.Price) {
          optimum.Price = curAndLenPrice;
          optimum.PosPrev = 0;
          optimum.BackPrev = i;
          optimum.Prev1IsChar = 0;
        }
      } while (--repLen >= 2);
    }
    normalMatchPrice = matchPrice + ProbPrices[this$static._isRep[this$static._state] >>> 2];
    len = this$static.repLens[0] >= 2 ? this$static.repLens[0] + 1 : 2;
    if (len <= lenMain) {
      offs = 0;
      while (len > this$static._matchDistances[offs]) {
        offs += 2;
      }
      for (; ; ++len) {
        distance = this$static._matchDistances[offs + 1];
        curAndLenPrice = normalMatchPrice + $GetPosLenPrice(this$static, distance, len, posState);
        optimum = this$static._optimum[len];
        if (curAndLenPrice < optimum.Price) {
          optimum.Price = curAndLenPrice;
          optimum.PosPrev = 0;
          optimum.BackPrev = distance + 4;
          optimum.Prev1IsChar = 0;
        }
        if (len == this$static._matchDistances[offs]) {
          offs += 2;
          if (offs == numDistancePairs) {
            break;
          }
        }
      }
    }
    cur = 0;
    while (1) {
      ++cur;
      if (cur == lenEnd) {
        return $Backward(this$static, cur);
      }
      newLen = $ReadMatchDistances(this$static);
      numDistancePairs = this$static._numDistancePairs;
      if (newLen >= this$static._numFastBytes) {
        this$static._longestMatchLength = newLen;
        this$static._longestMatchWasFound = 1;
        return $Backward(this$static, cur);
      }
      ++position;
      posPrev = this$static._optimum[cur].PosPrev;
      if (this$static._optimum[cur].Prev1IsChar) {
        --posPrev;
        if (this$static._optimum[cur].Prev2) {
          state = this$static._optimum[this$static._optimum[cur].PosPrev2].State;
          if (this$static._optimum[cur].BackPrev2 < 4) {
            state = state < 7 ? 8 : 11;
          } else {
            state = state < 7 ? 7 : 10;
          }
        } else {
          state = this$static._optimum[posPrev].State;
        }
        state = StateUpdateChar(state);
      } else {
        state = this$static._optimum[posPrev].State;
      }
      if (posPrev == cur - 1) {
        if (!this$static._optimum[cur].BackPrev) {
          state = state < 7 ? 9 : 11;
        } else {
          state = StateUpdateChar(state);
        }
      } else {
        if (this$static._optimum[cur].Prev1IsChar && this$static._optimum[cur].Prev2) {
          posPrev = this$static._optimum[cur].PosPrev2;
          pos = this$static._optimum[cur].BackPrev2;
          state = state < 7 ? 8 : 11;
        } else {
          pos = this$static._optimum[cur].BackPrev;
          if (pos < 4) {
            state = state < 7 ? 8 : 11;
          } else {
            state = state < 7 ? 7 : 10;
          }
        }
        opt = this$static._optimum[posPrev];
        if (pos < 4) {
          if (!pos) {
            this$static.reps[0] = opt.Backs0;
            this$static.reps[1] = opt.Backs1;
            this$static.reps[2] = opt.Backs2;
            this$static.reps[3] = opt.Backs3;
          } else if (pos == 1) {
            this$static.reps[0] = opt.Backs1;
            this$static.reps[1] = opt.Backs0;
            this$static.reps[2] = opt.Backs2;
            this$static.reps[3] = opt.Backs3;
          } else if (pos == 2) {
            this$static.reps[0] = opt.Backs2;
            this$static.reps[1] = opt.Backs0;
            this$static.reps[2] = opt.Backs1;
            this$static.reps[3] = opt.Backs3;
          } else {
            this$static.reps[0] = opt.Backs3;
            this$static.reps[1] = opt.Backs0;
            this$static.reps[2] = opt.Backs1;
            this$static.reps[3] = opt.Backs2;
          }
        } else {
          this$static.reps[0] = pos - 4;
          this$static.reps[1] = opt.Backs0;
          this$static.reps[2] = opt.Backs1;
          this$static.reps[3] = opt.Backs2;
        }
      }
      this$static._optimum[cur].State = state;
      this$static._optimum[cur].Backs0 = this$static.reps[0];
      this$static._optimum[cur].Backs1 = this$static.reps[1];
      this$static._optimum[cur].Backs2 = this$static.reps[2];
      this$static._optimum[cur].Backs3 = this$static.reps[3];
      curPrice = this$static._optimum[cur].Price;
      currentByte = $GetIndexByte(this$static._matchFinder, -1);
      matchByte = $GetIndexByte(
        this$static._matchFinder,
        -this$static.reps[0] - 1 - 1
      );
      posState = position & this$static._posStateMask;
      curAnd1Price = curPrice + ProbPrices[this$static._isMatch[(state << 4) + posState] >>> 2] + $GetPrice_0(
        $GetSubCoder(
          this$static._literalEncoder,
          position,
          $GetIndexByte(this$static._matchFinder, -2)
        ),
        state >= 7,
        matchByte,
        currentByte
      );
      nextOptimum = this$static._optimum[cur + 1];
      nextIsChar = 0;
      if (curAnd1Price < nextOptimum.Price) {
        nextOptimum.Price = curAnd1Price;
        nextOptimum.PosPrev = cur;
        nextOptimum.BackPrev = -1;
        nextOptimum.Prev1IsChar = 0;
        nextIsChar = 1;
      }
      matchPrice = curPrice + ProbPrices[2048 - this$static._isMatch[(state << 4) + posState] >>> 2];
      repMatchPrice = matchPrice + ProbPrices[2048 - this$static._isRep[state] >>> 2];
      if (matchByte == currentByte && !(nextOptimum.PosPrev < cur && !nextOptimum.BackPrev)) {
        shortRepPrice = repMatchPrice + (ProbPrices[this$static._isRepG0[state] >>> 2] + ProbPrices[this$static._isRep0Long[(state << 4) + posState] >>> 2]);
        if (shortRepPrice <= nextOptimum.Price) {
          nextOptimum.Price = shortRepPrice;
          nextOptimum.PosPrev = cur;
          nextOptimum.BackPrev = 0;
          nextOptimum.Prev1IsChar = 0;
          nextIsChar = 1;
        }
      }
      numAvailableBytesFull = $GetNumAvailableBytes(this$static._matchFinder) + 1;
      numAvailableBytesFull = 4095 - cur < numAvailableBytesFull ? 4095 - cur : numAvailableBytesFull;
      numAvailableBytes = numAvailableBytesFull;
      if (numAvailableBytes < 2) {
        continue;
      }
      if (numAvailableBytes > this$static._numFastBytes) {
        numAvailableBytes = this$static._numFastBytes;
      }
      if (!nextIsChar && matchByte != currentByte) {
        t = Math.min(numAvailableBytesFull - 1, this$static._numFastBytes);
        lenTest2 = $GetMatchLen(
          this$static._matchFinder,
          0,
          this$static.reps[0],
          t
        );
        if (lenTest2 >= 2) {
          state2 = StateUpdateChar(state);
          posStateNext = position + 1 & this$static._posStateMask;
          nextRepMatchPrice = curAnd1Price + ProbPrices[2048 - this$static._isMatch[(state2 << 4) + posStateNext] >>> 2] + ProbPrices[2048 - this$static._isRep[state2] >>> 2];
          offset = cur + 1 + lenTest2;
          while (lenEnd < offset) {
            this$static._optimum[++lenEnd].Price = 268435455;
          }
          curAndLenPrice = nextRepMatchPrice + (price = $GetPrice(
            this$static._repMatchLenEncoder,
            lenTest2 - 2,
            posStateNext
          ), price + $GetPureRepPrice(this$static, 0, state2, posStateNext));
          optimum = this$static._optimum[offset];
          if (curAndLenPrice < optimum.Price) {
            optimum.Price = curAndLenPrice;
            optimum.PosPrev = cur + 1;
            optimum.BackPrev = 0;
            optimum.Prev1IsChar = 1;
            optimum.Prev2 = 0;
          }
        }
      }
      startLen = 2;
      for (repIndex = 0; repIndex < 4; ++repIndex) {
        lenTest = $GetMatchLen(
          this$static._matchFinder,
          -1,
          this$static.reps[repIndex],
          numAvailableBytes
        );
        if (lenTest < 2) {
          continue;
        }
        lenTestTemp = lenTest;
        do {
          while (lenEnd < cur + lenTest) {
            this$static._optimum[++lenEnd].Price = 268435455;
          }
          curAndLenPrice = repMatchPrice + (price_0 = $GetPrice(
            this$static._repMatchLenEncoder,
            lenTest - 2,
            posState
          ), price_0 + $GetPureRepPrice(this$static, repIndex, state, posState));
          optimum = this$static._optimum[cur + lenTest];
          if (curAndLenPrice < optimum.Price) {
            optimum.Price = curAndLenPrice;
            optimum.PosPrev = cur;
            optimum.BackPrev = repIndex;
            optimum.Prev1IsChar = 0;
          }
        } while (--lenTest >= 2);
        lenTest = lenTestTemp;
        if (!repIndex) {
          startLen = lenTest + 1;
        }
        if (lenTest < numAvailableBytesFull) {
          t = Math.min(
            numAvailableBytesFull - 1 - lenTest,
            this$static._numFastBytes
          );
          lenTest2 = $GetMatchLen(
            this$static._matchFinder,
            lenTest,
            this$static.reps[repIndex],
            t
          );
          if (lenTest2 >= 2) {
            state2 = state < 7 ? 8 : 11;
            posStateNext = position + lenTest & this$static._posStateMask;
            curAndLenCharPrice = repMatchPrice + (price_1 = $GetPrice(
              this$static._repMatchLenEncoder,
              lenTest - 2,
              posState
            ), price_1 + $GetPureRepPrice(this$static, repIndex, state, posState)) + ProbPrices[this$static._isMatch[(state2 << 4) + posStateNext] >>> 2] + $GetPrice_0(
              $GetSubCoder(
                this$static._literalEncoder,
                position + lenTest,
                $GetIndexByte(this$static._matchFinder, lenTest - 1 - 1)
              ),
              1,
              $GetIndexByte(
                this$static._matchFinder,
                lenTest - 1 - (this$static.reps[repIndex] + 1)
              ),
              $GetIndexByte(this$static._matchFinder, lenTest - 1)
            );
            state2 = StateUpdateChar(state2);
            posStateNext = position + lenTest + 1 & this$static._posStateMask;
            nextMatchPrice = curAndLenCharPrice + ProbPrices[2048 - this$static._isMatch[(state2 << 4) + posStateNext] >>> 2];
            nextRepMatchPrice = nextMatchPrice + ProbPrices[2048 - this$static._isRep[state2] >>> 2];
            offset = lenTest + 1 + lenTest2;
            while (lenEnd < cur + offset) {
              this$static._optimum[++lenEnd].Price = 268435455;
            }
            curAndLenPrice = nextRepMatchPrice + (price_2 = $GetPrice(
              this$static._repMatchLenEncoder,
              lenTest2 - 2,
              posStateNext
            ), price_2 + $GetPureRepPrice(this$static, 0, state2, posStateNext));
            optimum = this$static._optimum[cur + offset];
            if (curAndLenPrice < optimum.Price) {
              optimum.Price = curAndLenPrice;
              optimum.PosPrev = cur + lenTest + 1;
              optimum.BackPrev = 0;
              optimum.Prev1IsChar = 1;
              optimum.Prev2 = 1;
              optimum.PosPrev2 = cur;
              optimum.BackPrev2 = repIndex;
            }
          }
        }
      }
      if (newLen > numAvailableBytes) {
        newLen = numAvailableBytes;
        for (numDistancePairs = 0; newLen > this$static._matchDistances[numDistancePairs]; numDistancePairs += 2) {
        }
        this$static._matchDistances[numDistancePairs] = newLen;
        numDistancePairs += 2;
      }
      if (newLen >= startLen) {
        normalMatchPrice = matchPrice + ProbPrices[this$static._isRep[state] >>> 2];
        while (lenEnd < cur + newLen) {
          this$static._optimum[++lenEnd].Price = 268435455;
        }
        offs = 0;
        while (startLen > this$static._matchDistances[offs]) {
          offs += 2;
        }
        for (lenTest = startLen; ; ++lenTest) {
          curBack = this$static._matchDistances[offs + 1];
          curAndLenPrice = normalMatchPrice + $GetPosLenPrice(this$static, curBack, lenTest, posState);
          optimum = this$static._optimum[cur + lenTest];
          if (curAndLenPrice < optimum.Price) {
            optimum.Price = curAndLenPrice;
            optimum.PosPrev = cur;
            optimum.BackPrev = curBack + 4;
            optimum.Prev1IsChar = 0;
          }
          if (lenTest == this$static._matchDistances[offs]) {
            if (lenTest < numAvailableBytesFull) {
              t = Math.min(
                numAvailableBytesFull - 1 - lenTest,
                this$static._numFastBytes
              );
              lenTest2 = $GetMatchLen(
                this$static._matchFinder,
                lenTest,
                curBack,
                t
              );
              if (lenTest2 >= 2) {
                state2 = state < 7 ? 7 : 10;
                posStateNext = position + lenTest & this$static._posStateMask;
                curAndLenCharPrice = curAndLenPrice + ProbPrices[this$static._isMatch[(state2 << 4) + posStateNext] >>> 2] + $GetPrice_0(
                  $GetSubCoder(
                    this$static._literalEncoder,
                    position + lenTest,
                    $GetIndexByte(this$static._matchFinder, lenTest - 1 - 1)
                  ),
                  1,
                  $GetIndexByte(
                    this$static._matchFinder,
                    lenTest - (curBack + 1) - 1
                  ),
                  $GetIndexByte(this$static._matchFinder, lenTest - 1)
                );
                state2 = StateUpdateChar(state2);
                posStateNext = position + lenTest + 1 & this$static._posStateMask;
                nextMatchPrice = curAndLenCharPrice + ProbPrices[2048 - this$static._isMatch[(state2 << 4) + posStateNext] >>> 2];
                nextRepMatchPrice = nextMatchPrice + ProbPrices[2048 - this$static._isRep[state2] >>> 2];
                offset = lenTest + 1 + lenTest2;
                while (lenEnd < cur + offset) {
                  this$static._optimum[++lenEnd].Price = 268435455;
                }
                curAndLenPrice = nextRepMatchPrice + (price_3 = $GetPrice(
                  this$static._repMatchLenEncoder,
                  lenTest2 - 2,
                  posStateNext
                ), price_3 + $GetPureRepPrice(this$static, 0, state2, posStateNext));
                optimum = this$static._optimum[cur + offset];
                if (curAndLenPrice < optimum.Price) {
                  optimum.Price = curAndLenPrice;
                  optimum.PosPrev = cur + lenTest + 1;
                  optimum.BackPrev = 0;
                  optimum.Prev1IsChar = 1;
                  optimum.Prev2 = 1;
                  optimum.PosPrev2 = cur;
                  optimum.BackPrev2 = curBack + 4;
                }
              }
            }
            offs += 2;
            if (offs == numDistancePairs)
              break;
          }
        }
      }
    }
  }
  function $GetPosLenPrice(this$static, pos, len, posState) {
    var price, lenToPosState = GetLenToPosState(len);
    if (pos < 128) {
      price = this$static._distancesPrices[lenToPosState * 128 + pos];
    } else {
      price = this$static._posSlotPrices[(lenToPosState << 6) + GetPosSlot2(pos)] + this$static._alignPrices[pos & 15];
    }
    return price + $GetPrice(this$static._lenEncoder, len - 2, posState);
  }
  function $GetPureRepPrice(this$static, repIndex, state, posState) {
    var price;
    if (!repIndex) {
      price = ProbPrices[this$static._isRepG0[state] >>> 2];
      price += ProbPrices[2048 - this$static._isRep0Long[(state << 4) + posState] >>> 2];
    } else {
      price = ProbPrices[2048 - this$static._isRepG0[state] >>> 2];
      if (repIndex == 1) {
        price += ProbPrices[this$static._isRepG1[state] >>> 2];
      } else {
        price += ProbPrices[2048 - this$static._isRepG1[state] >>> 2];
        price += GetPrice(this$static._isRepG2[state], repIndex - 2);
      }
    }
    return price;
  }
  function $GetRepLen1Price(this$static, state, posState) {
    return ProbPrices[this$static._isRepG0[state] >>> 2] + ProbPrices[this$static._isRep0Long[(state << 4) + posState] >>> 2];
  }
  function $Init_4(this$static) {
    $BaseInit(this$static);
    $Init_9(this$static._rangeEncoder);
    InitBitModels(this$static._isMatch);
    InitBitModels(this$static._isRep0Long);
    InitBitModels(this$static._isRep);
    InitBitModels(this$static._isRepG0);
    InitBitModels(this$static._isRepG1);
    InitBitModels(this$static._isRepG2);
    InitBitModels(this$static._posEncoders);
    $Init_3(this$static._literalEncoder);
    for (var i = 0; i < 4; ++i) {
      InitBitModels(this$static._posSlotEncoder[i].Models);
    }
    $Init_2(this$static._lenEncoder, 1 << this$static._posStateBits);
    $Init_2(this$static._repMatchLenEncoder, 1 << this$static._posStateBits);
    InitBitModels(this$static._posAlignEncoder.Models);
    this$static._longestMatchWasFound = 0;
    this$static._optimumEndIndex = 0;
    this$static._optimumCurrentIndex = 0;
    this$static._additionalOffset = 0;
  }
  function $MovePos(this$static, num) {
    if (num > 0) {
      $Skip(this$static._matchFinder, num);
      this$static._additionalOffset += num;
    }
  }
  function $ReadMatchDistances(this$static) {
    var lenRes = 0;
    this$static._numDistancePairs = $GetMatches(
      this$static._matchFinder,
      this$static._matchDistances
    );
    if (this$static._numDistancePairs > 0) {
      lenRes = this$static._matchDistances[this$static._numDistancePairs - 2];
      if (lenRes == this$static._numFastBytes)
        lenRes += $GetMatchLen(
          this$static._matchFinder,
          lenRes - 1,
          this$static._matchDistances[this$static._numDistancePairs - 1],
          273 - lenRes
        );
    }
    ++this$static._additionalOffset;
    return lenRes;
  }
  function $ReleaseMFStream(this$static) {
    if (this$static._matchFinder && this$static._needReleaseMFStream) {
      this$static._matchFinder._stream = null;
      this$static._needReleaseMFStream = 0;
    }
  }
  function $ReleaseStreams(this$static) {
    $ReleaseMFStream(this$static);
    this$static._rangeEncoder.Stream = null;
  }
  function $SetDictionarySize_0(this$static, dictionarySize) {
    this$static._dictionarySize = dictionarySize;
    for (var dicLogSize = 0; dictionarySize > 1 << dicLogSize; ++dicLogSize) {
    }
    this$static._distTableSize = dicLogSize * 2;
  }
  function $SetMatchFinder(this$static, matchFinderIndex) {
    var matchFinderIndexPrev = this$static._matchFinderType;
    this$static._matchFinderType = matchFinderIndex;
    if (this$static._matchFinder && matchFinderIndexPrev != this$static._matchFinderType) {
      this$static._dictionarySizePrev = -1;
      this$static._matchFinder = null;
    }
  }
  function $WriteCoderProperties(this$static, outStream) {
    this$static.properties[0] = (this$static._posStateBits * 5 + this$static._numLiteralPosStateBits) * 9 + this$static._numLiteralContextBits << 24 >> 24;
    for (var i = 0; i < 4; ++i) {
      this$static.properties[1 + i] = this$static._dictionarySize >> 8 * i << 24 >> 24;
    }
    $write_0(outStream, this$static.properties, 0, 5);
  }
  function $WriteEndMarker(this$static, posState) {
    if (!this$static._writeEndMark) {
      return;
    }
    $Encode_3(
      this$static._rangeEncoder,
      this$static._isMatch,
      (this$static._state << 4) + posState,
      1
    );
    $Encode_3(
      this$static._rangeEncoder,
      this$static._isRep,
      this$static._state,
      0
    );
    this$static._state = this$static._state < 7 ? 7 : 10;
    $Encode_0(this$static._lenEncoder, this$static._rangeEncoder, 0, posState);
    var lenToPosState = GetLenToPosState(2);
    $Encode_2(
      this$static._posSlotEncoder[lenToPosState],
      this$static._rangeEncoder,
      63
    );
    $EncodeDirectBits(this$static._rangeEncoder, 67108863, 26);
    $ReverseEncode(this$static._posAlignEncoder, this$static._rangeEncoder, 15);
  }
  function GetPosSlot(pos) {
    if (pos < 2048) {
      return g_FastPos[pos];
    }
    if (pos < 2097152) {
      return g_FastPos[pos >> 10] + 20;
    }
    return g_FastPos[pos >> 20] + 40;
  }
  function GetPosSlot2(pos) {
    if (pos < 131072) {
      return g_FastPos[pos >> 6] + 12;
    }
    if (pos < 134217728) {
      return g_FastPos[pos >> 16] + 32;
    }
    return g_FastPos[pos >> 26] + 52;
  }
  function $Encode(this$static, rangeEncoder, symbol, posState) {
    if (symbol < 8) {
      $Encode_3(rangeEncoder, this$static._choice, 0, 0);
      $Encode_2(this$static._lowCoder[posState], rangeEncoder, symbol);
    } else {
      symbol -= 8;
      $Encode_3(rangeEncoder, this$static._choice, 0, 1);
      if (symbol < 8) {
        $Encode_3(rangeEncoder, this$static._choice, 1, 0);
        $Encode_2(this$static._midCoder[posState], rangeEncoder, symbol);
      } else {
        $Encode_3(rangeEncoder, this$static._choice, 1, 1);
        $Encode_2(this$static._highCoder, rangeEncoder, symbol - 8);
      }
    }
  }
  function $Encoder$LenEncoder(this$static) {
    this$static._choice = initDim(2);
    this$static._lowCoder = initDim(16);
    this$static._midCoder = initDim(16);
    this$static._highCoder = $BitTreeEncoder({}, 8);
    for (var posState = 0; posState < 16; ++posState) {
      this$static._lowCoder[posState] = $BitTreeEncoder({}, 3);
      this$static._midCoder[posState] = $BitTreeEncoder({}, 3);
    }
    return this$static;
  }
  function $Init_2(this$static, numPosStates) {
    InitBitModels(this$static._choice);
    for (var posState = 0; posState < numPosStates; ++posState) {
      InitBitModels(this$static._lowCoder[posState].Models);
      InitBitModels(this$static._midCoder[posState].Models);
    }
    InitBitModels(this$static._highCoder.Models);
  }
  function $SetPrices(this$static, posState, numSymbols, prices, st) {
    var a0, a1, b0, b1, i;
    a0 = ProbPrices[this$static._choice[0] >>> 2];
    a1 = ProbPrices[2048 - this$static._choice[0] >>> 2];
    b0 = a1 + ProbPrices[this$static._choice[1] >>> 2];
    b1 = a1 + ProbPrices[2048 - this$static._choice[1] >>> 2];
    i = 0;
    for (i = 0; i < 8; ++i) {
      if (i >= numSymbols)
        return;
      prices[st + i] = a0 + $GetPrice_1(this$static._lowCoder[posState], i);
    }
    for (; i < 16; ++i) {
      if (i >= numSymbols)
        return;
      prices[st + i] = b0 + $GetPrice_1(this$static._midCoder[posState], i - 8);
    }
    for (; i < numSymbols; ++i) {
      prices[st + i] = b1 + $GetPrice_1(this$static._highCoder, i - 8 - 8);
    }
  }
  function $Encode_0(this$static, rangeEncoder, symbol, posState) {
    $Encode(this$static, rangeEncoder, symbol, posState);
    if (--this$static._counters[posState] == 0) {
      $SetPrices(
        this$static,
        posState,
        this$static._tableSize,
        this$static._prices,
        posState * 272
      );
      this$static._counters[posState] = this$static._tableSize;
    }
  }
  function $Encoder$LenPriceTableEncoder(this$static) {
    $Encoder$LenEncoder(this$static);
    this$static._prices = [];
    this$static._counters = [];
    return this$static;
  }
  function $GetPrice(this$static, symbol, posState) {
    return this$static._prices[posState * 272 + symbol];
  }
  function $UpdateTables(this$static, numPosStates) {
    for (var posState = 0; posState < numPosStates; ++posState) {
      $SetPrices(
        this$static,
        posState,
        this$static._tableSize,
        this$static._prices,
        posState * 272
      );
      this$static._counters[posState] = this$static._tableSize;
    }
  }
  function $Create_1(this$static, numPosBits, numPrevBits) {
    var i, numStates;
    if (this$static.m_Coders != null && this$static.m_NumPrevBits == numPrevBits && this$static.m_NumPosBits == numPosBits) {
      return;
    }
    this$static.m_NumPosBits = numPosBits;
    this$static.m_PosMask = (1 << numPosBits) - 1;
    this$static.m_NumPrevBits = numPrevBits;
    numStates = 1 << this$static.m_NumPrevBits + this$static.m_NumPosBits;
    this$static.m_Coders = initDim(numStates);
    for (i = 0; i < numStates; ++i) {
      this$static.m_Coders[i] = $Encoder$LiteralEncoder$Encoder2({});
    }
  }
  function $GetSubCoder(this$static, pos, prevByte) {
    return this$static.m_Coders[((pos & this$static.m_PosMask) << this$static.m_NumPrevBits) + ((prevByte & 255) >>> 8 - this$static.m_NumPrevBits)];
  }
  function $Init_3(this$static) {
    var i, numStates = 1 << this$static.m_NumPrevBits + this$static.m_NumPosBits;
    for (i = 0; i < numStates; ++i) {
      InitBitModels(this$static.m_Coders[i].m_Encoders);
    }
  }
  function $Encode_1(this$static, rangeEncoder, symbol) {
    var bit, i, context = 1;
    for (i = 7; i >= 0; --i) {
      bit = symbol >> i & 1;
      $Encode_3(rangeEncoder, this$static.m_Encoders, context, bit);
      context = context << 1 | bit;
    }
  }
  function $EncodeMatched(this$static, rangeEncoder, matchByte, symbol) {
    var bit, i, matchBit, state, same = 1, context = 1;
    for (i = 7; i >= 0; --i) {
      bit = symbol >> i & 1;
      state = context;
      if (same) {
        matchBit = matchByte >> i & 1;
        state += 1 + matchBit << 8;
        same = matchBit == bit;
      }
      $Encode_3(rangeEncoder, this$static.m_Encoders, state, bit);
      context = context << 1 | bit;
    }
  }
  function $Encoder$LiteralEncoder$Encoder2(this$static) {
    this$static.m_Encoders = initDim(768);
    return this$static;
  }
  function $GetPrice_0(this$static, matchMode, matchByte, symbol) {
    var bit, context = 1, i = 7, matchBit, price = 0;
    if (matchMode) {
      for (; i >= 0; --i) {
        matchBit = matchByte >> i & 1;
        bit = symbol >> i & 1;
        price += GetPrice(
          this$static.m_Encoders[(1 + matchBit << 8) + context],
          bit
        );
        context = context << 1 | bit;
        if (matchBit != bit) {
          --i;
          break;
        }
      }
    }
    for (; i >= 0; --i) {
      bit = symbol >> i & 1;
      price += GetPrice(this$static.m_Encoders[context], bit);
      context = context << 1 | bit;
    }
    return price;
  }
  function $MakeAsChar(this$static) {
    this$static.BackPrev = -1;
    this$static.Prev1IsChar = 0;
  }
  function $MakeAsShortRep(this$static) {
    this$static.BackPrev = 0;
    this$static.Prev1IsChar = 0;
  }
  function $BitTreeDecoder(this$static, numBitLevels) {
    this$static.NumBitLevels = numBitLevels;
    this$static.Models = initDim(1 << numBitLevels);
    return this$static;
  }
  function $Decode_0(this$static, rangeDecoder) {
    var bitIndex, m = 1;
    for (bitIndex = this$static.NumBitLevels; bitIndex != 0; --bitIndex) {
      m = (m << 1) + $DecodeBit(rangeDecoder, this$static.Models, m);
    }
    return m - (1 << this$static.NumBitLevels);
  }
  function $ReverseDecode(this$static, rangeDecoder) {
    var bit, bitIndex, m = 1, symbol = 0;
    for (bitIndex = 0; bitIndex < this$static.NumBitLevels; ++bitIndex) {
      bit = $DecodeBit(rangeDecoder, this$static.Models, m);
      m <<= 1;
      m += bit;
      symbol |= bit << bitIndex;
    }
    return symbol;
  }
  function ReverseDecode(Models, startIndex, rangeDecoder, NumBitLevels) {
    var bit, bitIndex, m = 1, symbol = 0;
    for (bitIndex = 0; bitIndex < NumBitLevels; ++bitIndex) {
      bit = $DecodeBit(rangeDecoder, Models, startIndex + m);
      m <<= 1;
      m += bit;
      symbol |= bit << bitIndex;
    }
    return symbol;
  }
  function $BitTreeEncoder(this$static, numBitLevels) {
    this$static.NumBitLevels = numBitLevels;
    this$static.Models = initDim(1 << numBitLevels);
    return this$static;
  }
  function $Encode_2(this$static, rangeEncoder, symbol) {
    var bit, bitIndex, m = 1;
    for (bitIndex = this$static.NumBitLevels; bitIndex != 0; ) {
      --bitIndex;
      bit = symbol >>> bitIndex & 1;
      $Encode_3(rangeEncoder, this$static.Models, m, bit);
      m = m << 1 | bit;
    }
  }
  function $GetPrice_1(this$static, symbol) {
    var bit, bitIndex, m = 1, price = 0;
    for (bitIndex = this$static.NumBitLevels; bitIndex != 0; ) {
      --bitIndex;
      bit = symbol >>> bitIndex & 1;
      price += GetPrice(this$static.Models[m], bit);
      m = (m << 1) + bit;
    }
    return price;
  }
  function $ReverseEncode(this$static, rangeEncoder, symbol) {
    var bit, i, m = 1;
    for (i = 0; i < this$static.NumBitLevels; ++i) {
      bit = symbol & 1;
      $Encode_3(rangeEncoder, this$static.Models, m, bit);
      m = m << 1 | bit;
      symbol >>= 1;
    }
  }
  function $ReverseGetPrice(this$static, symbol) {
    var bit, i, m = 1, price = 0;
    for (i = this$static.NumBitLevels; i != 0; --i) {
      bit = symbol & 1;
      symbol >>>= 1;
      price += GetPrice(this$static.Models[m], bit);
      m = m << 1 | bit;
    }
    return price;
  }
  function ReverseEncode(Models, startIndex, rangeEncoder, NumBitLevels, symbol) {
    var bit, i, m = 1;
    for (i = 0; i < NumBitLevels; ++i) {
      bit = symbol & 1;
      $Encode_3(rangeEncoder, Models, startIndex + m, bit);
      m = m << 1 | bit;
      symbol >>= 1;
    }
  }
  function ReverseGetPrice(Models, startIndex, NumBitLevels, symbol) {
    var bit, i, m = 1, price = 0;
    for (i = NumBitLevels; i != 0; --i) {
      bit = symbol & 1;
      symbol >>>= 1;
      price += ProbPrices[((Models[startIndex + m] - bit ^ -bit) & 2047) >>> 2];
      m = m << 1 | bit;
    }
    return price;
  }
  function $DecodeBit(this$static, probs, index) {
    var newBound, prob = probs[index];
    newBound = (this$static.Range >>> 11) * prob;
    if ((this$static.Code ^ -2147483648) < (newBound ^ -2147483648)) {
      this$static.Range = newBound;
      probs[index] = prob + (2048 - prob >>> 5) << 16 >> 16;
      if (!(this$static.Range & -16777216)) {
        this$static.Code = this$static.Code << 8 | $read(this$static.Stream);
        this$static.Range <<= 8;
      }
      return 0;
    } else {
      this$static.Range -= newBound;
      this$static.Code -= newBound;
      probs[index] = prob - (prob >>> 5) << 16 >> 16;
      if (!(this$static.Range & -16777216)) {
        this$static.Code = this$static.Code << 8 | $read(this$static.Stream);
        this$static.Range <<= 8;
      }
      return 1;
    }
  }
  function $DecodeDirectBits(this$static, numTotalBits) {
    var i, t, result = 0;
    for (i = numTotalBits; i != 0; --i) {
      this$static.Range >>>= 1;
      t = this$static.Code - this$static.Range >>> 31;
      this$static.Code -= this$static.Range & t - 1;
      result = result << 1 | 1 - t;
      if (!(this$static.Range & -16777216)) {
        this$static.Code = this$static.Code << 8 | $read(this$static.Stream);
        this$static.Range <<= 8;
      }
    }
    return result;
  }
  function $Init_8(this$static) {
    this$static.Code = 0;
    this$static.Range = -1;
    for (var i = 0; i < 5; ++i) {
      this$static.Code = this$static.Code << 8 | $read(this$static.Stream);
    }
  }
  function InitBitModels(probs) {
    for (var i = probs.length - 1; i >= 0; --i) {
      probs[i] = 1024;
    }
  }
  var ProbPrices = function() {
    var end, i, j, start, ProbPrices2 = [];
    for (i = 8; i >= 0; --i) {
      start = 1 << 9 - i - 1;
      end = 1 << 9 - i;
      for (j = start; j < end; ++j) {
        ProbPrices2[j] = (i << 6) + (end - j << 6 >>> 9 - i - 1);
      }
    }
    return ProbPrices2;
  }();
  function $Encode_3(this$static, probs, index, symbol) {
    var newBound, prob = probs[index];
    newBound = (this$static.Range >>> 11) * prob;
    if (!symbol) {
      this$static.Range = newBound;
      probs[index] = prob + (2048 - prob >>> 5) << 16 >> 16;
    } else {
      this$static.Low = add2(
        this$static.Low,
        and(fromInt(newBound), [4294967295, 0])
      );
      this$static.Range -= newBound;
      probs[index] = prob - (prob >>> 5) << 16 >> 16;
    }
    if (!(this$static.Range & -16777216)) {
      this$static.Range <<= 8;
      $ShiftLow(this$static);
    }
  }
  function $EncodeDirectBits(this$static, v, numTotalBits) {
    for (var i = numTotalBits - 1; i >= 0; --i) {
      this$static.Range >>>= 1;
      if ((v >>> i & 1) == 1) {
        this$static.Low = add2(this$static.Low, fromInt(this$static.Range));
      }
      if (!(this$static.Range & -16777216)) {
        this$static.Range <<= 8;
        $ShiftLow(this$static);
      }
    }
  }
  function $GetProcessedSizeAdd(this$static) {
    return add2(
      add2(fromInt(this$static._cacheSize), this$static._position),
      [4, 0]
    );
  }
  function $Init_9(this$static) {
    this$static._position = P0_longLit;
    this$static.Low = P0_longLit;
    this$static.Range = -1;
    this$static._cacheSize = 1;
    this$static._cache = 0;
  }
  function $ShiftLow(this$static) {
    var temp, LowHi = lowBits_0(shru(this$static.Low, 32));
    if (LowHi != 0 || compare(this$static.Low, [4278190080, 0]) < 0) {
      this$static._position = add2(
        this$static._position,
        fromInt(this$static._cacheSize)
      );
      temp = this$static._cache;
      do {
        $write(this$static.Stream, temp + LowHi);
        temp = 255;
      } while (--this$static._cacheSize != 0);
      this$static._cache = lowBits_0(this$static.Low) >>> 24;
    }
    ++this$static._cacheSize;
    this$static.Low = shl(and(this$static.Low, [16777215, 0]), 8);
  }
  function GetPrice(Prob, symbol) {
    return ProbPrices[((Prob - symbol ^ -symbol) & 2047) >>> 2];
  }
  function decode(utf) {
    var i = 0, j = 0, x, y, z, l = utf.length, buf = [], charCodes = [];
    for (; i < l; ++i, ++j) {
      x = utf[i] & 255;
      if (!(x & 128)) {
        if (!x) {
          return utf;
        }
        charCodes[j] = x;
      } else if ((x & 224) == 192) {
        if (i + 1 >= l) {
          return utf;
        }
        y = utf[++i] & 255;
        if ((y & 192) != 128) {
          return utf;
        }
        charCodes[j] = (x & 31) << 6 | y & 63;
      } else if ((x & 240) == 224) {
        if (i + 2 >= l) {
          return utf;
        }
        y = utf[++i] & 255;
        if ((y & 192) != 128) {
          return utf;
        }
        z = utf[++i] & 255;
        if ((z & 192) != 128) {
          return utf;
        }
        charCodes[j] = (x & 15) << 12 | (y & 63) << 6 | z & 63;
      } else {
        return utf;
      }
      if (j == 16383) {
        buf.push(String.fromCharCode.apply(String, charCodes));
        j = -1;
      }
    }
    if (j > 0) {
      charCodes.length = j;
      buf.push(String.fromCharCode.apply(String, charCodes));
    }
    return buf.join("");
  }
  function encode(s) {
    var ch, chars = [], data, elen = 0, i, l = s.length;
    if (typeof s == "object") {
      return s;
    } else {
      $getChars(s, 0, l, chars, 0);
    }
    for (i = 0; i < l; ++i) {
      ch = chars[i];
      if (ch >= 1 && ch <= 127) {
        ++elen;
      } else if (!ch || ch >= 128 && ch <= 2047) {
        elen += 2;
      } else {
        elen += 3;
      }
    }
    data = [];
    elen = 0;
    for (i = 0; i < l; ++i) {
      ch = chars[i];
      if (ch >= 1 && ch <= 127) {
        data[elen++] = ch << 24 >> 24;
      } else if (!ch || ch >= 128 && ch <= 2047) {
        data[elen++] = (192 | ch >> 6 & 31) << 24 >> 24;
        data[elen++] = (128 | ch & 63) << 24 >> 24;
      } else {
        data[elen++] = (224 | ch >> 12 & 15) << 24 >> 24;
        data[elen++] = (128 | ch >> 6 & 63) << 24 >> 24;
        data[elen++] = (128 | ch & 63) << 24 >> 24;
      }
    }
    return data;
  }
  var modes = [
    { s: 16, f: 64, m: 0 },
    { s: 20, f: 64, m: 0 },
    { s: 19, f: 64, m: 1 },
    { s: 20, f: 64, m: 1 },
    { s: 21, f: 128, m: 1 },
    { s: 22, f: 128, m: 1 },
    { s: 23, f: 128, m: 1 },
    { s: 24, f: 255, m: 1 },
    { s: 25, f: 255, m: 1 }
  ];
  function get_mode_obj(mode) {
    return modes[mode - 1] || modes[6];
  }
  function compress(value, { mode = 7, enableEndMark = true } = {}) {
    var this$static = {};
    this$static.c = $LZMAByteArrayCompressor(
      {},
      encode(value),
      get_mode_obj(mode),
      enableEndMark
    );
    while ($processChunk(this$static.c.chunker))
      ;
    return $toByteArray(this$static.c.output);
  }
  function compressBase64(string, { mode = 7, enableEndMark = true } = {}) {
    const compressedString = compress(string, { mode, enableEndMark });
    const compressedBytes = new Uint8Array(compressedString);
    return encodeFromArray(compressedBytes);
  }
  function decompress(bytes) {
    var this$static = {};
    this$static.d = $LZMAByteArrayDecompressor({}, bytes);
    while ($processChunk(this$static.d.chunker))
      ;
    return decode($toByteArray(this$static.d.output));
  }
  function decompressBase64(string) {
    return decompress(new Int8Array(decodeToArray(string)));
  }

  // src/composables/use-group-configurations.ts
  function useGroupConfigurations() {
    return useStorage("groups", [], {
      saveMapper(groups) {
        if (typeof chrome.storage === "undefined")
          return groups;
        return compressBase64(JSON.stringify(groups));
      },
      loadMapper(storedGroups) {
        if (typeof storedGroups === "string" && /^[{[]/.test(storedGroups)) {
          storedGroups = JSON.parse(storedGroups);
        }
        if (typeof storedGroups === "string") {
          storedGroups = JSON.parse(decompressBase64(storedGroups));
        }
        if (!Array.isArray(storedGroups))
          return [];
        for (const group of storedGroups) {
          if (!("options" in group)) {
            group.options = { strict: false, merge: false };
          }
          if (!("merge" in group.options)) {
            group.options.merge = false;
          }
        }
        return storedGroups;
      }
    });
  }

  // src/util/helpers.ts
  var matcherPattern = "^(?:(?<simpleScheme>[a-z][a-z0-9+.\\-]*)(?<!https?|ftp|\\*)://(?<simplePath>.*)|(?:(?<scheme>https?|ftp|\\*)://)?(?<host>\\*|(?:(?:[^@:\\/]+(?::[^@:\\/]+)?@)?(?:[^:\\/]+|\\[[0-9a-f:]+\\]))(?::[0-9]+)?)(?:/(?<path>.*))?)$";
  function sanitizeRegex(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  var isExtensionWorker = typeof globalThis?.chrome?.runtime !== "undefined";

  // src/util/conflict-manager.ts
  var conflictMarker = " <conflict:%s>";
  var conflictPattern = conflictMarker.split("%s").map(sanitizeRegex).join("[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}");
  var conflictRegex = new RegExp(conflictPattern + "$");
  function generateMarker() {
    return conflictMarker.split("%s").join(crypto.randomUUID());
  }
  function hasMarker(title) {
    return conflictRegex.test(title);
  }
  function withoutMarker(title) {
    return title.replace(conflictRegex, "");
  }
  function withMarker(title, { recreate = false } = {}) {
    if (hasMarker(title)) {
      if (recreate) {
        return withMarker(withoutMarker(title));
      } else {
        return title;
      }
    } else {
      return `${title}${generateMarker()}`;
    }
  }

  // src/util/group-configurations.ts
  async function saveGroupConfigurations(groups) {
    const groupsCopy = JSON.parse(
      JSON.stringify(toRawDeep(groups))
    );
    for (const group of groupsCopy) {
      if (!hasMarker(group.title))
        continue;
      const titleWithoutConflictMarker = withoutMarker(
        group.title
      );
      if (groupsCopy.some((group2) => group2.title === titleWithoutConflictMarker))
        continue;
      group.title = titleWithoutConflictMarker;
    }
    const shouldCompress = typeof chrome.storage !== "undefined";
    const saveableGroupsCopy = shouldCompress ? compressBase64(JSON.stringify(groupsCopy)) : groupsCopy;
    return await writeStorage("groups", saveableGroupsCopy, "sync");
  }
  function createGroupConfigurationMatcher(group) {
    return (tabGroup) => tabGroup.title === group.title && tabGroup.color === group.color;
  }

  // node_modules/monomitter/index.js
  function monomitter() {
    const callbacks = /* @__PURE__ */ new Set();
    return [
      (...args) => callbacks.forEach((callback) => callback(...args)),
      (callback) => {
        callbacks.add(callback);
        return () => callbacks.delete(callback);
      },
      () => callbacks.clear()
    ];
  }
  var monomitter_default = monomitter;

  // src/util/queue-until-resolve.ts
  function queueUntilResolve(initialPromise = Promise.reject()) {
    const list = [initialPromise];
    const [publishNewPromise, subscribeNewPromise] = monomitter_default();
    function push(newPromise) {
      list.push(newPromise);
      publishNewPromise();
    }
    function resolveList() {
      const firstItem = list.shift();
      return firstItem.catch(() => {
        if (list.length === 0) {
          return new Promise((resolve) => {
            const unsubscribe = subscribeNewPromise(() => {
              unsubscribe();
              resolve(resolveList());
            });
          });
        } else {
          return resolveList();
        }
      }).then((result) => {
        if (list.length === 0)
          return result;
        return resolveList();
      });
    }
    return { push, promise: resolveList() };
  }

  // src/util/group-creation-tracker.ts
  var GroupCreationTracker = class {
    #groupsInTheMaking = /* @__PURE__ */ new Map();
    constructor() {
      const chromeWindows = useReadonlyChromeWindows();
      watch(chromeWindows.lastRemoved, (removedWindowId) => {
        this.#groupsInTheMaking.delete(removedWindowId);
      });
    }
    #getOrCreateWindowMap(windowId) {
      if (!this.#groupsInTheMaking.has(windowId)) {
        this.#groupsInTheMaking.set(windowId, /* @__PURE__ */ new Map());
      }
      return this.#groupsInTheMaking.get(windowId);
    }
    isCreating(windowId, group) {
      return this.#groupsInTheMaking.get(windowId)?.has(group.id) ?? false;
    }
    getCreationPromise(windowId, group) {
      if (this.isCreating(windowId, group)) {
        return this.#groupsInTheMaking.get(windowId).get(group.id).promise;
      }
      throw new Error(
        "Cannot get group creation Promise for a group that is not currently being created."
      );
    }
    queueGroupCreation(windowId, group, creationPromise) {
      if (this.isCreating(windowId, group)) {
        this.#groupsInTheMaking.get(windowId).get(group.id).push(creationPromise);
      } else {
        const map2 = this.#getOrCreateWindowMap(windowId);
        const queue2 = queueUntilResolve(creationPromise);
        map2.set(group.id, queue2);
        queue2.promise.then(() => {
          map2.delete(group.id);
        });
      }
    }
  };

  // src/util/matcher-regex.ts
  function generateMatcherRegex(matcher) {
    function generatePatternString(string, asteriskReplacement) {
      return string.split("*").map(sanitizeRegex).join(asteriskReplacement);
    }
    const matcherPatternRegex = new RegExp(matcherPattern);
    const result = matcher.match(matcherPatternRegex);
    if (!result) {
      throw new Error("Invalid matcher: " + matcher);
    }
    if (matcher === "*")
      return /^.*$/;
    const { scheme, host, path, simpleScheme, simplePath } = result.groups ?? {};
    const schemePattern = simpleScheme ? simpleScheme : typeof scheme === "string" ? generatePatternString(scheme, "https?") : "https?";
    let hostPattern;
    if (simpleScheme) {
      hostPattern = "";
    } else if (typeof host === "string") {
      if (host === "*") {
        hostPattern = "[^/]+";
      } else if (host.startsWith("*.") && host.indexOf("*", 2) === -1) {
        hostPattern = generatePatternString(`*${host.slice(2)}`, "(?:[^/]+\\.)?");
      } else if (host.includes("*")) {
        const parts = host.split("*");
        const escapedParts = parts.map(sanitizeRegex);
        hostPattern = escapedParts.join("[^./]+");
      } else {
        hostPattern = sanitizeRegex(host);
      }
      if (!/:[0-9]+$/.test(host)) {
        hostPattern += "(?::[0-9]+)?";
      }
    } else {
      hostPattern = "[^/]+";
    }
    let pathPattern;
    if (simplePath) {
      pathPattern = generatePatternString(simplePath, ".*");
    } else if (typeof path === "string") {
      pathPattern = `(?:/${generatePatternString(path, ".*")})?`;
    } else {
      pathPattern = "(?:/.*)?";
    }
    return new RegExp(`^${schemePattern}://${hostPattern}${pathPattern}$`);
  }

  // src/util/when.ts
  var defaultPredicate = (value) => Boolean(value);
  function when(container, predicate = defaultPredicate) {
    return new Promise((resolve) => {
      const stop2 = watch(
        container,
        (value) => {
          if (predicate(value)) {
            nextTick(() => {
              stop2();
            });
            resolve();
          }
        },
        { deep: true, immediate: true }
      );
    });
  }

  // src/background.ts
  ignoreChromeRuntimeEvents.value = true;
  var groupConfigurations = useGroupConfigurations();
  var chromeState = useChromeState();
  var augmentedGroupConfigurations = computed2(
    () => groupConfigurations.data.value.map((group) => ({
      ...group,
      matchers: group.matchers.flatMap((matcher) => {
        try {
          return generateMatcherRegex(matcher);
        } catch {
          return [];
        }
      })
    }))
  );
  var chromeTabsByGroupConfiguration = computed2(() => {
    const tabsByGroups = /* @__PURE__ */ new Map();
    const tabs = chromeState.tabs.items.value;
    for (const tab of tabs) {
      const group = getGroupConfigurationForTab(tab);
      if (!group)
        continue;
      if (tabsByGroups.has(group)) {
        tabsByGroups.get(group).push(tab);
      } else {
        const groupTabs = [tab];
        tabsByGroups.set(group, groupTabs);
      }
    }
    return tabsByGroups;
  });
  var chromeTabsByWindowIdAndGroupConfiguration = computed2(
    () => Object.entries(chromeState.tabsByWindowId.value).map(
      ([windowId, tabs]) => {
        const tabsByGroups = /* @__PURE__ */ new Map();
        for (const tab of tabs) {
          const group = getGroupConfigurationForTab(tab);
          if (!group)
            continue;
          if (tabsByGroups.has(group)) {
            tabsByGroups.get(group).push(tab);
          } else {
            const groupTabs = [tab];
            tabsByGroups.set(group, groupTabs);
          }
        }
        return { windowId: Number(windowId), tabsByGroups };
      }
    )
  );
  Object.assign(self, { chromeState });
  function getGroupConfigurationForTab(tab) {
    if (tab.pinned) {
      console.debug("Tab %o (%o) pinned, ignore.", tab.title, tab.id);
      return;
    }
    if (!tab.url) {
      console.debug("Tab %o (%o) has no URL, ignore.", tab.title, tab.id);
      return;
    }
    let groupIndex = 0;
    for (const group of augmentedGroupConfigurations.value) {
      for (const matcher of group.matchers) {
        if (matcher.test(tab.url))
          return groupConfigurations.data.value[groupIndex];
      }
      groupIndex++;
    }
    return;
  }
  var groupCreationTracker = new GroupCreationTracker();
  async function assignTabsToGroup(tabs, group) {
    if (tabs.length === 0)
      return;
    const windowId = tabs[0].windowId;
    const tabGroupPredicate = createGroupConfigurationMatcher(group);
    const targetTabGroupInSameWindow = chromeState.tabGroupsByWindowId.value[windowId]?.find(tabGroupPredicate);
    const targetTabGroup = chromeState.tabGroups.items.value.find(tabGroupPredicate);
    let shouldMerge = false;
    if (group.options.merge) {
      const sourceWindow = chromeState.windows.items.value.find(
        (window2) => window2.id === windowId
      );
      const targetWindow = chromeState.windows.items.value.find(
        (window2) => window2.id === targetTabGroup?.windowId
      );
      const canMerge = sourceWindow?.incognito === targetWindow?.incognito;
      shouldMerge = canMerge;
    }
    const tabGroup = shouldMerge ? targetTabGroup : targetTabGroupInSameWindow;
    const tabGroupId = tabGroup?.id;
    console.debug(
      "Assigning %o tabs to group %o (%o / %o)...",
      tabs.length,
      tabGroupId,
      group.title,
      group.color
    );
    const attemptGroupAssignment = async ({ waitable = true } = {}) => {
      const tabIds = tabs.flatMap((tab) => tab.id ?? []);
      const windowId2 = (await chrome.tabs.get(tabs[0].id)).windowId;
      let tabGroupId2 = shouldMerge ? chromeState.tabGroups.items.value.find(tabGroupPredicate)?.id : chromeState.tabGroupsByWindowId.value[windowId2]?.find(tabGroupPredicate)?.id;
      try {
        if (waitable && groupCreationTracker.isCreating(windowId2, group)) {
          tabGroupId2 = await groupCreationTracker.getCreationPromise(
            windowId2,
            group
          );
        }
        if (!tabGroupId2) {
          console.debug("Attempt assignment to new group in window %o", windowId2);
          const tabCreationPromise = chrome.tabs.group({
            tabIds,
            createProperties: { windowId: windowId2 }
          });
          groupCreationTracker.queueGroupCreation(
            windowId2,
            group,
            tabCreationPromise
          );
          const newGroupId = await tabCreationPromise;
          await chrome.tabGroups.update(newGroupId, {
            title: group.title,
            color: group.color
          });
        } else {
          const currentWindow = await chrome.windows.getCurrent();
          const currentWindowId = currentWindow?.id;
          const currentTab = (await chrome.tabs.query({ active: true, windowId: currentWindowId }))?.[0];
          const currentTabId = currentTab?.id;
          console.debug("Attempt assignment to existing group %o", tabGroupId2);
          await chrome.tabs.group({
            tabIds,
            groupId: tabGroupId2
          });
          if (currentTabId && tabIds.includes(currentTabId)) {
            const targetWindowId = chromeState.tabGroups.items.value.find(
              (tabGroup2) => tabGroup2.id === tabGroupId2
            )?.windowId;
            if (targetWindowId && currentWindowId !== targetWindowId) {
              chrome.windows.update(targetWindowId, {
                focused: true
              });
              chrome.tabs.update(currentTabId, {
                active: true
              });
            }
          }
        }
        tabIds.forEach((tabId) => draggingTabs.delete(tabId));
        console.debug("Assignment successful");
        return tabGroupId2;
      } catch (error) {
        if (error == "Error: Tabs cannot be edited right now (user may be dragging a tab).") {
          tabIds.forEach((tabId) => draggingTabs.add(tabId));
          console.debug(
            "Tab is being dragged, cannot assign it to a group, poll for dragging to be done..."
          );
          setTimeout(() => {
            const result = attemptGroupAssignment({ waitable: false });
            groupCreationTracker.queueGroupCreation(
              windowId2,
              group,
              result.then((id) => {
                if (typeof id === "number")
                  return id;
                throw new Error("Tab group assignment failed");
              })
            );
          }, 50);
        } else {
          console.error("Could not group tabs:", error);
        }
      }
    };
    await attemptGroupAssignment();
  }
  async function ungroupAppropriateTabs(tabs) {
    for (const tab of tabs) {
      if (tab.groupId !== chrome.tabGroups.TAB_GROUP_ID_NONE) {
        const assignedGroup = chromeState.tabGroups.items.value.find(
          (tabGroup) => tabGroup.id === tab.groupId
        );
        if (!assignedGroup)
          continue;
        for (const groupConfiguration of augmentedGroupConfigurations.value) {
          const matchesGroupConfiguration = createGroupConfigurationMatcher(groupConfiguration);
          if (matchesGroupConfiguration(assignedGroup)) {
            if (groupConfiguration.options.strict) {
              console.debug(
                "Unassigning tab %o (%o) from group %o (%o / %o)...",
                tab.title,
                tab.id,
                tab.groupId,
                groupConfiguration.title,
                groupConfiguration.color
              );
              await chrome.tabs.ungroup(tab.id);
            }
          }
        }
      }
    }
  }
  async function groupAllAppropriateTabs() {
    const assignedTabIds = /* @__PURE__ */ new Set();
    for (const {
      tabsByGroups
    } of chromeTabsByWindowIdAndGroupConfiguration.value) {
      for (const [group, tabs] of tabsByGroups) {
        for (const tab of tabs) {
          assignedTabIds.add(tab.id);
        }
        await assignTabsToGroup(tabs, group);
      }
    }
    const tabsToUnassign = [];
    for (const tab of chromeState.tabs.items.value) {
      if (assignedTabIds.has(tab.id))
        continue;
      tabsToUnassign.push(tab);
    }
    if (tabsToUnassign.length > 0) {
      await ungroupAppropriateTabs(tabsToUnassign);
    }
  }
  var justLoadedGroupConfigurations = tickResetRef(false);
  var stopWatchingGroupConfigurationsLoaded = watch(
    groupConfigurations.loaded,
    (isLoaded) => {
      if (isLoaded) {
        stopWatchingGroupConfigurationsLoaded();
        justLoadedGroupConfigurations.value = true;
      }
    }
  );
  var programmaticallyUpdatingTabGroups = ref(false);
  var draggingTabs = /* @__PURE__ */ new Set();
  watch(
    augmentedGroupConfigurations,
    async (newGroups, oldGroups) => {
      if (!groupConfigurations.loaded.value || justLoadedGroupConfigurations.value)
        return;
      const addedGroupConfigurations = newGroups.filter(
        ({ id }) => !oldGroups.some((oldGroup) => oldGroup.id === id)
      );
      const deletedGroupConfigurations = oldGroups.filter(
        ({ id }) => !newGroups.some((newGroup) => newGroup.id === id)
      );
      const superficiallyChangedGroupConfigurations = newGroups.filter(
        (newGroup) => {
          const oldGroup = oldGroups.find(
            (oldGroup2) => oldGroup2.id === newGroup.id
          );
          if (!oldGroup)
            return false;
          return oldGroup.title !== newGroup.title || oldGroup.color !== newGroup.color;
        }
      );
      const deeplyChangedGroupConfigurations = newGroups.filter((newGroup) => {
        const oldGroup = oldGroups.find((oldGroup2) => oldGroup2.id === newGroup.id);
        if (!oldGroup)
          return false;
        if (oldGroups.indexOf(oldGroup) !== newGroups.indexOf(newGroup))
          return true;
        if (oldGroup.options.strict !== newGroup.options.strict)
          return true;
        if (oldGroup.options.merge !== newGroup.options.merge)
          return true;
        if (oldGroup.matchers.length !== newGroup.matchers.length)
          return true;
        const sortedOldMatchers = [...oldGroup.matchers].sort();
        const sortedNewMatchers = [...newGroup.matchers].sort();
        for (let i = 0; i < oldGroup.matchers.length; i++) {
          if (sortedOldMatchers[i].source !== sortedNewMatchers[i].source)
            return true;
        }
        return false;
      });
      if (addedGroupConfigurations.length > 0) {
        console.debug("Added tab group configurations:", addedGroupConfigurations);
      }
      if (superficiallyChangedGroupConfigurations.length > 0) {
        console.debug(
          "Superficially changed tab group configurations:",
          superficiallyChangedGroupConfigurations
        );
        for (const newGroup of newGroups) {
          if (!superficiallyChangedGroupConfigurations.includes(newGroup))
            continue;
          const oldGroup = oldGroups.find(
            (oldGroup2) => oldGroup2.id === newGroup.id
          );
          programmaticallyUpdatingTabGroups.value = true;
          for (const tabGroup of chromeState.tabGroups.items.value) {
            if (tabGroup.title === oldGroup.title && tabGroup.color === oldGroup.color) {
              await chrome.tabGroups.update(tabGroup.id, {
                title: newGroup.title,
                color: newGroup.color
              });
              await when(
                chromeState.tabGroups.items,
                (tabGroups) => tabGroups.some(
                  (stateTabGroup) => stateTabGroup.id === tabGroup.id && stateTabGroup.title === newGroup.title && stateTabGroup.color === newGroup.color
                )
              );
            }
          }
          programmaticallyUpdatingTabGroups.value = false;
        }
      }
      if (deeplyChangedGroupConfigurations.length > 0) {
        console.debug(
          "Deeply changed tab group configurations:",
          deeplyChangedGroupConfigurations
        );
      }
      if (deletedGroupConfigurations.length > 0) {
        console.debug(
          "Deleted tab group configurations:",
          deletedGroupConfigurations
        );
        const groupsToDelete = chromeState.tabGroups.items.value.filter(
          (tabGroup) => deletedGroupConfigurations.some(
            (groupConfiguration) => groupConfiguration.title === tabGroup.title && groupConfiguration.color === tabGroup.color
          )
        );
        console.debug("Tab groups to delete: %o", groupsToDelete);
        for (const groupToDelete of groupsToDelete) {
          const tabsToUngroup = chromeState.tabs.items.value.filter(
            (tab) => tab.groupId === groupToDelete.id
          );
          chrome.tabs.ungroup(tabsToUngroup.flatMap((tab) => tab.id ?? []));
        }
      }
      if (addedGroupConfigurations.length > 0 || deeplyChangedGroupConfigurations.length > 0) {
        console.debug("\u2747\uFE0F Added groups or changed matchers, reassign tabs.");
        await groupAllAppropriateTabs();
      }
    },
    { immediate: true }
  );
  var tabGroupsHistory = useRefHistory(chromeState.tabGroups.items, {
    capacity: 2
  });
  var removedTabGroups = useRefHistory(chromeState.tabGroups.lastRemoved, {
    capacity: 10
  });
  watch(chromeState.tabGroups.lastUpdated, async (tabGroup) => {
    if (!tabGroup)
      return;
    if (programmaticallyUpdatingTabGroups.value)
      return;
    const oldTabGroup = tabGroupsHistory.history.value[0].snapshot.find(
      (stateTabGroup) => stateTabGroup.id === tabGroup.id
    );
    if (!oldTabGroup)
      return;
    if (oldTabGroup.title === tabGroup.title && oldTabGroup.color === tabGroup.color)
      return;
    const matchesOldGroup = createGroupConfigurationMatcher(oldTabGroup);
    const matchesNewGroup = createGroupConfigurationMatcher(tabGroup);
    if (groupConfigurations.data.value.some(matchesOldGroup)) {
      const groupsCopy = JSON.parse(
        JSON.stringify(groupConfigurations.data.value)
      );
      const conflictingItem = groupsCopy.find(matchesNewGroup);
      let unconflictingTitle;
      if (conflictingItem) {
        unconflictingTitle = withMarker(tabGroup.title);
        conflictingItem.title = unconflictingTitle;
      }
      const updatedGroupItem = groupsCopy.find(matchesOldGroup);
      updatedGroupItem.title = tabGroup.title ?? "";
      updatedGroupItem.color = tabGroup.color;
      saveGroupConfigurations(groupsCopy);
      if (conflictingItem) {
        programmaticallyUpdatingTabGroups.value = true;
        await when(
          chromeState.tabGroups.lastUpdated,
          (updatedTabGroup) => updatedTabGroup.id === tabGroup.id && updatedTabGroup.title === unconflictingTitle
        );
        await chrome.tabGroups.update(tabGroup.id, {
          title: tabGroup.title
        });
        await when(
          chromeState.tabGroups.lastUpdated,
          (updatedTabGroup) => updatedTabGroup.id === tabGroup.id && updatedTabGroup.title === tabGroup.title
        );
        programmaticallyUpdatingTabGroups.value = false;
      }
    }
  });
  chrome.runtime.onUpdateAvailable.addListener(() => {
    chrome.runtime.reload();
  });
  chrome.runtime.onMessage.addListener((message) => {
    if (message === "reload") {
      chrome.runtime.reload();
    }
  });
  when(groupConfigurations.loaded).then(async () => {
    console.debug("Waiting for extension state to initialize...");
    await when(chromeState.tabs.loaded);
    console.debug(
      "Extension state initialized, grouping all appropriate tabs now..."
    );
    await groupAllAppropriateTabs();
    console.debug(
      "Initial grouping done, begin listening to chrome runtime events..."
    );
    ignoreChromeRuntimeEvents.value = false;
    watch(chromeState.tabs.lastUpdated, async (update) => {
      if (!update)
        return;
      if (chromeState.tabs.detachedTabs.value.includes(update.tab.id))
        return;
      if (draggingTabs.has(update.tab.id))
        return;
      const removedFromTabGroup = update.changes.groupId === chrome.tabGroups.TAB_GROUP_ID_NONE;
      if (!update.changes.url && !removedFromTabGroup)
        return;
      if (removedFromTabGroup) {
        console.debug(
          "Removed tab %o (%o) from tab group %o. Looking up the group now...",
          update.tab.title,
          update.tab.id,
          update.oldTab?.groupId
        );
        try {
          await chrome.tabGroups.get(update.oldTab.groupId);
          console.debug("Group found, it still exists.");
        } catch {
          console.debug(
            "Group of removed tab no longer found. Waiting for extension state to reflect the removal..."
          );
          await when(
            removedTabGroups.history,
            (history) => history.some((item) => item.snapshot?.id === update.oldTab?.groupId)
          );
          console.debug("Reflected tab group removal in extension state");
        }
      }
      if (!chromeState.tabsById.value[update.tab.id])
        return;
      console.debug(
        "Reassigning tab %o (%o) due to change %o",
        update.tab.title,
        update.tab.id,
        update.changes
      );
      const updatedTab = await chrome.tabs.get(update.tab.id);
      let assignedAny = false;
      for (const [group, tabs] of chromeTabsByGroupConfiguration.value) {
        if (!tabs.some((tab) => tab.id === updatedTab.id))
          continue;
        assignedAny = true;
        await assignTabsToGroup([updatedTab], group);
      }
      if (!assignedAny) {
        ungroupAppropriateTabs([updatedTab]);
      }
    });
  });
  chrome.action.onClicked.addListener(() => {
    console.debug("Trigger extension action");
    chrome.runtime.openOptionsPage();
  });
})();
